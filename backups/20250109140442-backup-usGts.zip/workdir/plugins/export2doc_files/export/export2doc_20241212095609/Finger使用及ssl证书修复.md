---
title: Finger使用及ssl证书修复
id: 6391654a-0751-48eb-861c-000431d8c51e
date: 2024-02-19 15:30:51
auther: yrl
cover: 
excerpt: Finger使用及ssl证书修复 使用Finger的时候发现阿里云的https链接ssl证书失效，导致原有的sdk请求https报错，遂修改sdk代码，关闭ssl证书验证。 Finger简介 Finger是一个可以识别并恢复函数符号的工具，是阿里云·云安全技术实验室开发的二进制程序函数符号识别引擎，
permalink: /archives/fingershi-yong-ji-sslzheng-shu-xiu-fu
categories:
 - ida
tags: 
 - finger
---

## Finger使用及ssl证书修复

使用Finger的时候发现阿里云的https链接ssl证书失效，导致原有的sdk请求https报错，遂修改sdk代码，关闭ssl证书验证。

## Finger简介

Finger是一个可以识别并恢复函数符号的工具，是阿里云·云安全技术实验室开发的二进制程序函数符号识别引擎，旨在帮助安全研究人员识别给定二进制文件中未知的库函数。

Finger提供单一恢复、批量恢复两种方式访问​​Finger功能符号识别引擎的核心API。基于阿里云大数据海量样本符号文件，提取符号特征进行匹配，对大多数常见的三方库能够恢复符号表。

## 环境

现在，Finger 支持 python 2.7 和 python 3，并且需要 IDA 版本 >= 7.0。

## 安装

python 版本必须与您的 IDAPython 版本相同
```bash
pip install finger_sdk
```
安装finger python SDK后，您可以查看finger/exampls/recognize.py以获取更多信息。

[下载finger_plugin.py](https://github.com/aliyunav/Finger/blob/master/finger_plugin.py)，将plugin/finger_plugin.py 复制到您的IDA_PATH/plugins 路径。

## ssl修复

手动修改your_ida_python_path/Lib/site-packages/finger_sdk/client.py，如下：

```bash
diff --git a/client.py b/client_patch.py
index e1d4456..5d78045 100644
--- a/client.py
+++ b/client_patch.py
@@ -3,6 +3,8 @@ import base64
 import hashlib
 import platform
 import requests
+import urllib3
+import certifi
 
 
 class Client(object):
@@ -85,10 +87,17 @@ class Client(object):
         else:
             msg, func_id = self.gen_msg_py2(content)
         try:
-            self.session = requests.Session()
-            res = self.session.post(self.url, data=msg, headers=self.headers, timeout=self.timeout)
-            if res:
-                symbol_dict[func_id] = self.get_func_symbol(res.text)
+            # Old implementation method
+            # self.session = requests.Session()
+            # res = self.session.post(self.url, data=msg, headers=self.headers, timeout=self.timeout,verify=False)
+            # if res:
+            #     symbol_dict[func_id] = self.get_func_symbol(res.text)
+            
+            # New implementation method, removing SSL authentication
+            http = urllib3.PoolManager(cert_reqs='CERT_NONE', ca_certs=certifi.where())
+            res = http.request('POST', self.url, body=msg, headers=self.headers, timeout=self.timeout)
+            if res.status == 200:
+                symbol_dict[func_id] = self.get_func_symbol(res.data.decode('utf-8'))
         except Exception as e:
             raise RuntimeError("upload function failed")
         return func_id, symbol_dict

```

重启ida即可生效。

## 测试是否生效

```python
import urllib3
import certifi

msg = '{"extmsg": ["bWV0YXBj", "TFNC", "NjQ=", "RUxG", ""], "ins_bytes": ["8w8e+g==", "SIHs2AAAAA==", "SYn6", "SIl0JCg=", "SIlUJDA=", "SIlMJDg=", "TIlEJEA=", "TIlMJEg=", "hMA=", "dDc=", "DylEJFA=", "DylMJGA=", "DylUJHA=", "DymcJIAAAAA=", "DymkJJAAAAA=", "DymsJKAAAAA=", "Dym0JLAAAAA=", "Dym8JMAAAAA=", "ZEiLBCUoAAAA", "SIlEJBg=", "McA=", "SIs998sLAA==", "SIni", "Mck=", "SI2EJOAAAAA=", "TInW", "xwQkCAAAAA==", "SIlEJAg=", "SI1EJCA=", "x0QkBDAAAAA=", "SIlEJBA=", "6HQwAAA=", "SItUJBg=", "ZEgrFCUoAAAA", "dQg=", "SIHE2AAAAA==", "ww==", "6Ed1BAA="], "ins_str": ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""], "func_name": "sub_40BA80", "md5": "6cd1d54bffad77a8650e45e99b346a2f"}'
url = 'https://sec-lab.aliyun.com/finger/recognize/'
http = urllib3.PoolManager(cert_reqs='CERT_NONE', ca_certs=certifi.where())
encoded_data = msg
res = http.request('POST', url, body=encoded_data, timeout=5)
print(res.data)
```
忽略警告，可以看到识别出为printf函数
```bash
InsecureRequestWarning: Unverified HTTPS request is being made to host 'sec-lab.aliyun.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#ssl-warnings
  warnings.warn(
b'{"func_name": "sub_40BA80", "func_symbol": "printf"}'
```

根据sdk实现方式，可以看出这个api接收一个json数据，数据是由idc获取

- extmsg：文件属性：架构、大小端、文件位数（32/64）、文件类型等
- ins_bytes：汇编特征，汇编指令码
- ins_str：汇编特征，汇编指令中的字符
- func_name：无符号/有符号的函数名称

数据是base64加密过的，解密即可看到原始信息

返回一个json数据：

- func_name：原函数名称
- func_symbol：恢复后函数名称


## 使用

Finger IDA插件支持单一功能、选择功能、全功能识别。您可以识别菜单栏、反汇编窗口和函数窗口中的函数符号。

- 可以选择函数起始地址，右键选择Finger -> Recognize funtion
- 可以在函数窗口批量选择函数后，右键选择Finger -> Recognize funtion
- 可以在导航栏Finger -> Recognize all funtion/Recognize funtion

成功识别的函数符号将在反汇编窗口和函数窗口中以**绿色**突出显示

## 体验评价

用起来比较方便，对于普遍通用的第三方库的符号恢复比较好，对于一些特殊的库，恢复有局限性，有些简单的函数无法识别正确（如getpid）需要自己对函数额外判断一下（尽信书不如无书）。大文件识别需要比较久的时间，且无法中断

相对于rizzo等其他工具需要有类似的分析样本文件生成rizzo signature文件方便了不少，但需要知道程序使用了哪些库函数，在此基础上才能很好的使用。

## 多线程改进

[Finger-Multi-threading](https://github.com/Holit/Finger-Multi-threading/blob/master/finger_plugin_complete.py)

替换原有的finger_plugin.py即可，可以实现多线程恢复，节省时间，不会一致刷窗口