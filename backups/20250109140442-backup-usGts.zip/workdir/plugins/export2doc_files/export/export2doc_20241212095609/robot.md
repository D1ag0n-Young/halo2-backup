---
title: robot
id: cad5b74b-3629-4830-ad88-9cf508fa0524
date: 2024-05-09 09:38:41
auther: yrl
cover: 
excerpt: 666
permalink: /archives/robot
categories:
tags: 
---

666