---
title: Html跳转其他链接方法
id: 97
date: 2024-01-09 20:09:11
auther: yrl
cover: 
excerpt: Html+JS实现跳转可以实现倒计时跳转的过程&lt;!DOCTYPE html&gt;&lt;html&gt;&lt;head&gt;&lt;meta charset=&quot;UTF-8&quot;&gt;&lt;title&gt;Insert title here&lt;/title&gt;
permalink: /archives/html%E8%B7%B3%E8%BD%AC%E5%85%B6%E4%BB%96%E9%93%BE%E6%8E%A5%E6%96%B9%E6%B3%95
categories:
 - html
tags: 
---

# Html+JS实现跳转
可以实现倒计时跳转的过程
```html
<!DOCTYPE html>
<html>
<head>
<meta content="zh-CN" http-equiv="Content-Language">
<meta CONTENT="text/html; charset=gb2312" HTTP-EQUIV="Content-Type">
<title>Insert title here</title>
<script type="text/javascript">
    window.onload = function(){
        var time = 5;
        var secondEle = document.getElementById("second");
        var timer = setInterval(function(){
            secondEle.innerHTML = time;
            time--;
            if(time==0){
                clearInterval(timer);
                location.href="http://www.baidu.com";
            }
                
        },1000);
    }
</script>
</head>
<body>
    恭喜你，注册成功，<span style="color:red" id="second">5</span>秒钟后跳转，如不跳转点击<a href="http://www.baidu.com">这里</a>!
</body>
```

# Html实现跳转
```html
<html>-
<head>
    <meta content="zh-CN" http-equiv="Content-Language">
    <meta CONTENT="text/html; charset=gb2312" HTTP-EQUIV="Content-Type">
    <meta content="2;url=http://www.baidu.com" http-equiv="refresh">
</head>
<body>
</body>
</html>
```
