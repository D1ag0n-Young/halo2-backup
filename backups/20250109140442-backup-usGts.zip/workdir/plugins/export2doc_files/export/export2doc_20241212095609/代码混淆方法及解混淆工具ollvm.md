---
title: 代码混淆方法及解混淆工具（ollvm/goron）
id: 100
date: 2024-01-09 20:09:11
auther: yrl
cover: 
excerpt: ollvm加混淆goron间接跳转及间接调用混淆另一个基于 llvm 的混淆器。下载git clone https//github.com/amimo/goron.git -b llvm-7.1.0编译cd goronmkdir buildcd buildcmake -DCMAKE_BUILD_T
permalink: /archives/%E4%BB%A3%E7%A0%81%E6%B7%B7%E6%B7%86%E6%96%B9%E6%B3%95%E5%8F%8A%E8%A7%A3%E6%B7%B7%E6%B7%86%E5%B7%A5%E5%85%B7ollvm
categories:
 - llvm
 - 混淆
tags: 
 - llvm
---

# LLVM Obfuscator加混淆
## 下载依赖( linux)
需要安装gcc、g++、ninja、cmake等工具，一般linux系统会自带，如果没有，则使用apt安装即可，命令如下:
`sudo apt install–y gcc g++ cmake ninja-build`
## 下载LLVM源代码
使用如下所示git命令:

`git clone https://github.com/llvm/llvm-project.git`
同样地，也可以到去[下载](https://github.com/llvm/llvm-project/releases)相应代码。
## 编译LLVM(linux)
```
mkdir build
cd build
cmake -G Ninja -DCMAKE_BUILD_TYPE=RELEASE -DLLVM_TARGETS_TO_BUILD="X86" -DLLVM_ENABLE_PROJECTS="clang"  -DLLVM_OPTIMIZED_TABLEGEN=ON ../llvm

```
接下来运行编译命令:
```
ninja
```
## 安装LLVM (可不安装)
编译完成后，执行安装命令即可:
```
sudo ninja build
```
## 测试

```c++
#include <iostream>

int main(int argc, const char ** argv) {
    std::cout << "Hello Clang World!" << std::endl;
}
```
编译：`pathtoclang/clang main.c -o main`

[LLVM编译](https://blog.csdn.net/weixin_45644430/article/details/124538057)
[LLVM](https://github.com/llvm/llvm-project)

# goron间接跳转及间接调用混淆

另一个基于 llvm 的混淆器。
当前支持特性：

- 混淆过程间相关
- 间接跳转,并加密跳转目标(-mllvm -irobf-indbr)
- 间接函数调用,并加密目标函数地址(-mllvm -irobf-icall)
- 间接全局变量引用,并加密变量地址(-mllvm -irobf-indgv)
- 字符串(c string)加密功能(-mllvm -irobf-cse)
- 过程相关控制流平坦混淆(-mllvm -irobf-cff)

## 下载
`git clone https://github.com/amimo/goron.git -b llvm-7.1.0`
## 编译
```
cd goron
mkdir build
cd build
cmake -DCMAKE_BUILD_TYPE=Release -DLLVM_ENABLE_ASSERTIONS=ON -DLLVM_ENABLE_PROJECTS=clang -G "Unix Makefiles" ../llvm
make -j12
```
## 使用

跟ollvm类似，可通过编译选项开启不同的vm。如启用直接重定向
```bash
$ path_to_the/build/bin/clang -mllvm -irobf-icall -mllvm --irobf-indbr test.c
```
[goron](https://github.com/amimo/goron)

# 间接跳转,并加密跳转目标（-mllvm -irobf-indbr）原理

clang编译器将判断跳转语句相关的跳转地址全部做了加密运算（+/-一个固定值）后记录到一个全局变量数组中，判断条件由数组的下标决定跳转到哪个地址，实际运行的时候会自动计算跳转到真实地址。
```
                 push    rbp
.text:0000000000401131                 mov     rbp, rsp
.text:0000000000401134                 sub     rsp, 20h
.text:0000000000401138                 mov     [rbp+var_4], 9E668E0Ah
.text:000000000040113F                 mov     eax, [rbp+var_4]
.text:0000000000401142                 mov     [rbp+var_C], 0
.text:0000000000401149                 mov     [rbp+var_10], edi
.text:000000000040114C                 mov     [rbp+var_18], rsi
.text:0000000000401150                 mov     edi, [rbp+var_10]
.text:0000000000401153                 sub     edi, 1
.text:0000000000401156                 setz    cl                                                       <--通过setz cl来区分跳转到哪一个分支
.text:0000000000401159                 movzx   edx, cl
.text:000000000040115C                 mov     esi, edx
.text:000000000040115E                 mov     rsi, _Lmain_IndirectBrTargets[rsi*8] <--加密的地址
.text:0000000000401166                 mov     edx, 0EE2377CEh
.text:000000000040116B                 sub     edx, eax                                           <--和硬编码的值做运算后得到真实地址
.text:000000000040116D                 movsxd  r8, edx
.text:0000000000401170                 add     rsi, r8
.text:0000000000401173                 mov     [rbp+var_1C], eax
.text:0000000000401176                 mov     [rbp+var_20], edi
.text:0000000000401179                 jmp     rsi                                                    <--jmp实现跳转
.text:0000000000401179 main            endp
.text:0000000000401179
.text:000000000040117B ; ---------------------------------------------------------------------------
.text:000000000040117B                 mov     rax, offset IntValues
.text:0000000000401185                 mov     rcx, rax
.text:0000000000401188                 add     rcx, 10h
.text:000000000040118C                 mov     edx, [rbp-1Ch]
.text:000000000040118F                 sub     edx, 0B8DBFC60h
.text:0000000000401195                 mov     [rbp-8], edx
.text:0000000000401198                 lea     rdi, [rbp-8]
.text:000000000040119C                 mov     rsi, rax
.text:000000000040119F                 mov     rdx, rcx
.text:00000000004011A2                 call    compare_structure
.text:00000000004011A7                 jmp     loc_4011D8
.text:00000000004011AC ; ---------------------------------------------------------------------------
.text:00000000004011AC                 mov     rax, offset IntValues
.text:00000000004011B6                 mov     rcx, rax
.text:00000000004011B9                 add     rcx, 10h
.text:00000000004011BD                 mov     edx, [rbp-1Ch]
.text:00000000004011C0                 sub     edx, 0B8DBFC60h
.text:00000000004011C6                 mov     [rbp-8], edx
.text:00000000004011C9                 lea     rdi, [rbp-8]
.text:00000000004011CD                 mov     rsi, rcx
.text:00000000004011D0                 mov     rdx, rax
.text:00000000004011D3                 call    compare_structure
.text:00000000004011D8
```
`_Lmain_IndirectBrTargets`如下:
```
.data:0000000000404018 _Lmain_IndirectBrTargets dq 0FFFFFFFFB08327E8h
.data:0000000000404018                                         ; DATA XREF: main+2E↑r
.data:0000000000404020                 dq 0FFFFFFFFB08327B7h
.data:0000000000404028 _Lcompare_structure_IndirectBrTargets dq 781337F9h
.data:0000000000404028                                         ; DATA XREF: compare_structure+2D↑r
.data:0000000000404030                 dq 78133822h
```
所以当setz cl的值为0时，esi = 0，rsi =0x0FFFFFFFFB08327E8，所以最后 jmp rsi会跳转到0x0FFFFFFFFB08327E8h + （0x0EE2377CE-0x9E668E0A&0xffffffff = 0x4011ac
同理如果cl=1，rsi =0x0FFFFFFFFB08327B7，所以最后 jmp rsi会跳转到0x所以最后 jmp rsi会跳转到0x0FFFFFFFFB08327B7 + （0x0EE2377CE-0x9E668E0A&0xffffffff = 0x4011b7 

另外，如果还有调用其他函数，则会将其它函数的第一个参数增加一个固定值，这个固定值用于这个函数中判断跳转语句地址的加密计算，原来的参数往后顺移。

## 去混淆

目前没有通用的去混淆工具，可通过调试去获取真实地址，理解逻辑；也可以手动patch还原程序逻辑（比较复杂），patch示例：
```
.text:0000000000401130 ; __unwind {
.text:0000000000401130                 push    rbp
.text:0000000000401131                 mov     rbp, rsp
.text:0000000000401134                 sub     rsp, 20h
.text:0000000000401138                 mov     [rbp+var_4], 9E668E0Ah
.text:000000000040113F                 mov     eax, [rbp+var_4]
.text:0000000000401142                 mov     [rbp+var_C], 0
.text:0000000000401149                 mov     [rbp+var_10], edi
.text:000000000040114C                 mov     [rbp+var_18], rsi
.text:0000000000401150                 mov     edi, [rbp+var_10]
.text:0000000000401153                 sub     edi, 1
.text:0000000000401156                 setz    cl
.text:0000000000401159                 movzx   edx, cl
.text:000000000040115C                 mov     esi, edx
.text:000000000040115E                 mov     rsi, _Lmain_IndirectBrTargets[rsi*8]
.text:0000000000401166                 mov     edx, 0EE2377CEh
.text:000000000040116B                 sub     edx, eax
.text:000000000040116D                 movsxd  r8, edx
.text:0000000000401170                 add     rsi, r8
.text:0000000000401173                 mov     [rbp+var_1C], eax
.text:0000000000401176                 mov     [rbp+var_20], edi
.text:0000000000401179                 jmp     rsi
.text:0000000000401179 main            endp
.text:000000000040117B
.text:000000000040117B loc_40117B:                             ; CODE XREF: main+2C↑j
.text:000000000040117B                 mov     rax, offset IntValues
.text:0000000000401185                 mov     rcx, rax
.text:0000000000401188                 add     rcx, 10h
.text:000000000040118C                 mov     edx, [rbp+var_1C]
.text:000000000040118F                 sub     edx, 0B8DBFC60h
.text:0000000000401195                 mov     [rbp+var_8], edx
.text:0000000000401198                 lea     rdi, [rbp+var_8]
.text:000000000040119C                 mov     rsi, rax
.text:000000000040119F                 mov     rdx, rcx
.text:00000000004011A2                 call    compare_structure
.text:00000000004011A7                 jmp     loc_4011D8
```
去除前：
```
int __cdecl main(int argc, const char **argv, const char **envp)
{
  int result; // eax

  __asm { jmp     rsi }
  return result;
}
```
patch后：
```
.text:0000000000401130                 push    rbp
.text:0000000000401131                 mov     rbp, rsp
.text:0000000000401134                 sub     rsp, 20h
.text:0000000000401138                 nop                     ; Keypatch filled range [0x401138:0x401148] (17 bytes), replaced:
.text:0000000000401138                                         ;   mov [rbp+var_4], 9E668E0Ah
.text:0000000000401138                                         ;   mov eax, [rbp+var_4]
.text:0000000000401138                                         ;   mov [rbp+var_C], 0
.text:0000000000401139                 nop
.text:000000000040113A                 nop
.text:000000000040113B                 nop
..............
..............
.text:0000000000401147                 nop
.text:0000000000401148                 nop
.text:0000000000401149                 mov     [rbp+var_10], edi
.text:000000000040114C                 mov     [rbp+var_18], rsi
.text:0000000000401150                 mov     edi, [rbp+var_10]
.text:0000000000401153                 sub     edi, 1
.text:0000000000401156                 setz    cl
.text:0000000000401159                 cmp     cl, 1           ; Keypatch modified this from:
.text:0000000000401159                                         ;   movzx edx, cl
.text:000000000040115C                 jz      short loc_40117B ; Keypatch modified this from:
.text:000000000040115C                                         ;   mov esi, edx
.text:000000000040115E                 jmp     short loc_4011AC 
.text:0000000000401160 ; ---------------------------------------------------------------------------
.text:0000000000401160                 nop                     ; Keypatch filled range [0x401160:0x40117A] (27 bytes), replaced:
.text:0000000000401160    
....
.text:000000000040117A                 nop
.text:000000000040117B
.text:000000000040117B loc_40117B:                             ; CODE XREF: main+2C↑j
.text:000000000040117B                 mov     rax, offset IntValues
.text:0000000000401185                 mov     rcx, rax
.text:0000000000401188                 add     rcx, 10h
.text:000000000040118C                 mov     edx, [rbp+var_1C]
.text:000000000040118F                 sub     edx, 0B8DBFC60h
.text:0000000000401195                 mov     [rbp+var_8], edx
.text:0000000000401198                 lea     rdi, [rbp+var_8]
.text:000000000040119C                 mov     rsi, rax
.text:000000000040119F                 mov     rdx, rcx
.text:00000000004011A2                 call    compare_structure
.text:00000000004011A7                 jmp     loc_4011D8
```
反编译后：
```c
int __cdecl main(int argc, const char **argv, const char **envp)
{
  int v4; // [rsp+4h] [rbp-1Ch]
  int v5; // [rsp+18h] [rbp-8h] BYREF

  v5 = v4 + 1193542560;
  if ( argc == 1 )
    compare_structure(&v5, &IntValues, (char *)&IntValues + 16);
  else
    compare_structure(&v5, (char *)&IntValues + 16, &IntValues);
  return 0;
}
```
patch后伪代码已经出来了，patch方法就是提前计算好跳转目标地址，将jmp rsi这类语句还原回跳转语句。
# ollvm解混淆IDA插件-D810

D-810 是一个 IDA Pro 插件，可用于在反编译时通过修改 IDA Pro 微码对代码进行反混淆。
## 安装

Python 3.7 及更高版本仅支持 IDA v7.5 或更高版本（因为我们需要微码 Python API）
将此存储库复制到.idapro/plugins
我们建议安装 Z3 以使用 D-810 的多项功能：
`pip3 install z3-solver`
## 使用
1. 使用Ctrl-Shift-D快捷方式加载插件，您应该会看到此配置 GUI
![image-1666748711802](/upload/2022/10/image-1666748711802.png)
1. 选择或创建您的项目配置
	1. 如果您不确定在这里做什么，请选择default_instruction_only.json。
1. 点击Start按钮启用反混淆
1. 反编译一个混淆函数，代码应该被简化（希望如此）
1. 当您想禁用反混淆时，只需单击Stop按钮。
## 详情参考
[D810](https://github.com/joydo/d810)

# ollvm - Deobfuscation

## Flat_control_flow
**Description**
基于SnowGirls的deflat，利用angr框架实现去除控制流平坦化，详细内容请参考利用符号执行去除控制流平坦化 。

脚本仅依赖于angr框架，测试使用的angr版本为8.19.4.5

**Usage**
`0x400530` 是函数`check_password()`的地址。
```
(angr-dev) <path>/deflat/flat_control_flow$ python3 deflat.py -f samples/bin/check_passwd_x8664_flat --addr 0x400530
*******************relevant blocks************************
prologue: 0x400530
main_dispatcher: 0x400554
pre_dispatcher: 0x40099b
retn: 0x40098f
relevant_blocks: ['0x40086a', '0x40080d', '0x4008ee', '0x40094f', '0x40084e', '0x400819', '0x400886', '0x40095b', '0x4007ec', '0x40092e', '0x4008a9', '0x4008cc', '0x40091b', '0x40097c', '0x400837']
*******************symbolic execution*********************
-------------------dse 0x40086a---------------------
-------------------dse 0x40080d---------------------
-------------------dse 0x4008ee---------------------
-------------------dse 0x40094f---------------------
-------------------dse 0x40084e---------------------
-------------------dse 0x400819---------------------
-------------------dse 0x400886---------------------
-------------------dse 0x40095b---------------------
-------------------dse 0x4007ec---------------------
-------------------dse 0x40092e---------------------
-------------------dse 0x4008a9---------------------
-------------------dse 0x4008cc---------------------
-------------------dse 0x40091b---------------------
-------------------dse 0x40097c---------------------
-------------------dse 0x400837---------------------
-------------------dse 0x400530---------------------
************************flow******************************
0x40084e:  ['0x40086a', '0x40095b']
0x40086a:  ['0x400886', '0x40094f']
0x400530:  ['0x4007ec']
0x4008a9:  ['0x4008cc', '0x40094f']
0x400886:  ['0x4008a9', '0x40094f']
0x4007ec:  ['0x400819', '0x40080d']
0x40091b:  ['0x40098f']
0x40080d:  ['0x40084e']
0x40092e:  ['0x40094f']
0x4008ee:  ['0x40091b', '0x40092e']
0x400819:  ['0x400837']
0x40094f:  ['0x40097c']
0x40095b:  ['0x40097c']
0x40097c:  ['0x40098f']
0x400837:  ['0x4007ec']
0x4008cc:  ['0x4008ee', '0x40094f']
0x40098f:  []
************************patch*****************************
Successful! The recovered file: check_passwd_flat_recovered
```
## Bogus_control_flow
** Description**
利用angr框架去除虚假的控制流，详细内容请参考Deobfuscation: recovering an OLLVM-protected program 。

原文的主要思路是在进行符号执行时，对约束条件进行"精简"，通过将`x * (x + 1) % 2 `替换为0，使得`(y < 10 || x * (x + 1) % 2 == 0)`恒成立，从而获取正确的基本块，避免死循环。

在使用angr框架解决该问题时，也可以按照上述思路进行。另外一种思路是直接将x或y的值设为0，同样可以使得上面的约束恒成立。在默认条件下，x和y的值会被初始化为0，无需手动进行设置。也就是说，可以直接利用符号执行来解决，而不会遇到死循环的问题。

通过符号执行，获取所有执行过的基本块之后，再进行patch去除冗余的基本块即可。

	对控制流进行精简后，通过F5查看伪代码，与源码基本一致。另外，可以在此基础上对控制流进行进一步精简，比如去除冗余的指令等。

**Usage**
`0x080483e0 `是函数`target_function()`的地址。
```
(angr-dev) <path>/deflat/bogus_control_flow$ python3 debogus.py -f samples/bin/target_x86_bogus --addr 0x80483e0
*******************symbolic execution*********************
executed blocks:  ['0x8048686', '0x804868b', '0x8048991', '0x8048592', '0x8048914', '0x8048715', '0x8048897', '0x8048720', '0x8048725', '0x80484ab', '0x804862c', '0x804842e', '0x80484b6', '0x80484bb', '0x80487bb', '0x80487c0', '0x80486c7', '0x8048950', '0x8048551', '0x80488d3', '0x8048955', '0x8048556', '0x8048856', '0x80489d8', '0x80488d8', '0x804885b', '0x80483e0', '0x80485e0', '0x8048761', '0x80485eb', '0x80485f0', '0x80484f7', '0x80487fc']
************************patch******************************
Successful! The recovered file: ./target_bogus_recovered
```
**Description**
## Supported Arch
目前，脚本仅在以下架构的程序上进行测试:
- x86系列:x86, x86_64
- arm系列:arm(armv7), arm64/aarch64(armv8)

## 参考详情
[deflat](https://github.com/cq674350529/deflat)