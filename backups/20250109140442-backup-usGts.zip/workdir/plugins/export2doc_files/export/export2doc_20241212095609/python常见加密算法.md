---
title: python常见加密算法
id: 106
date: 2024-01-09 20:09:11
auther: yrl
cover: 
excerpt: tea算法teafrom ctypes import *def encrypt(v, k)    v0, v1 = c_uint32(v[0]), c_uint32(v[1])    delta = 0x9e3779b9     k0, k1, k2, k3 = k[0], k[1], k[2],
permalink: /archives/python-chang-jian-jia-mi-suan-fa
categories:
 - useful
 - python
tags: 
 - 密码
---

# tea算法

## tea

```python
from ctypes import *


def encrypt(v, k):
    v0, v1 = c_uint32(v[0]), c_uint32(v[1])
    delta = 0x9e3779b9 
    k0, k1, k2, k3 = k[0], k[1], k[2], k[3]

    total = c_uint32(0)
    for i in range(32):
        total.value += delta 
        v0.value += ((v1.value<<4) + k0) ^ (v1.value + total.value) ^ ((v1.value>>5) + k1)  
        v1.value += ((v0.value<<4) + k2) ^ (v0.value + total.value) ^ ((v0.value>>5) + k3)

    return v0.value, v1.value 


def decrypt(v, k):
    v0, v1 = c_uint32(v[0]), c_uint32(v[1])
    delta = 0x9e3779b9 
    k0, k1, k2, k3 = k[0], k[1], k[2], k[3]

    total = c_uint32(delta * 32)
    for i in range(32):                       
        v1.value -= ((v0.value<<4) + k2) ^ (v0.value + total.value) ^ ((v0.value>>5) + k3) 
        v0.value -= ((v1.value<<4) + k0) ^ (v1.value + total.value) ^ ((v1.value>>5) + k1)  
        total.value -= delta

    return v0.value, v1.value   
  
def tostring(v):
    v1 = []
    for i in range(len(v)):
        tmpstr = ''
        for j in range(4):
            tmpstr += chr(v[i]>>(8*j) &0xff)
        v1.append(tmpstr) 
    return ''.join(v1) 

# test
if __name__ == "__main__":
    # 待加密的明文，两个32位整型，即64bit的明文数据
    value = [0x12345678, 0x78563412]
    # 四个key，每个是32bit，即密钥长度为128bit
    key = [0x1, 0x2, 0x3, 0x4]
  
    print("Data is : ", hex(value[0]), hex(value[1]))  
    res = encrypt(value, key)
    print("Encrypted data is : ", tostring(res))
    res = decrypt(res, key)
    print("Decrypted data is : ", tostring(res))
"""
Data is :  0x12345678 0x78563412
Encrypted data is :  0x9a65a69a 0x67ed00f6
Decrypted data is :  0x12345678 0x78563412
"""

```

## xtea

```python
from ctypes import * 


def encrypt(v, key):   
    v0, v1 = c_uint32(v[0]), c_uint32(v[1])
    delta = 0x9E3779B9

    total = c_uint32(0)
    for i in range(32):  
        v0.value += (((v1.value << 4) ^ (v1.value >> 5)) + v1.value) ^ (total.value + key[total.value & 3])
        total.value += delta 
        v1.value += (((v0.value << 4) ^ (v0.value >> 5)) + v0.value) ^ (total.value + key[(total.value>>11) & 3])

    return v0.value, v1.value 


def decrypt(v, key):
    v0, v1  = c_uint32(v[0]), c_uint32(v[1])
    delta = 0x9E3779B9
    
    total = c_uint32(delta * 32)
    for i in range(32):
        v1.value -= (((v0.value << 4) ^ (v0.value >> 5)) + v0.value) ^ (total.value + key[(total.value>>11) & 3])
        total.value -= delta 
        v0.value -= (((v1.value << 4) ^ (v1.value >> 5)) + v1.value) ^ (total.value + key[total.value & 3])

    return v0.value, v1.value 
  
def tostring(v):
    v1 = []
    for i in range(len(v)):
        tmpstr = ''
        for j in range(4):
            tmpstr += chr(v[i]>>(8*j) &0xff)
        v1.append(tmpstr) 
    return ''.join(v1) 

# test
if __name__ == "__main__":
    # 待加密的明文，两个32位整型，即64bit的明文数据
    value = [0x12345678, 0x78563412]
    # 四个key，每个是32bit，即密钥长度为128bit
    key = [0x1, 0x2, 0x3, 0x4]

    print("Data is : ", hex(value[0]), hex(value[1]))
    res = encrypt(value, key)
    print("Encrypted data is : ", tostring(res))
    res = decrypt(res, key)
    print("Decrypted data is : ", tostring(res))
"""
Data is :  0x12345678 0x78563412
Encrypted data is :  0xae685ec7 0x59af4238
Decrypted data is :  0x12345678 0x78563412
"""

```

## xxtea

```python
from ctypes import *


def MX(z, y, total, key, p, e):
    temp1 = (z.value>>5 ^ y.value<<2) + (y.value>>3 ^ z.value<<4)
    temp2 = (total.value ^ y.value) + (key[(p&3) ^ e.value] ^ z.value)
    
    return c_uint32(temp1 ^ temp2)


def encrypt(n, v, key):
    delta = 0x9e3779b9 
    rounds = 6 + 52//n

    total = c_uint32(0)
    z = c_uint32(v[n-1])
    e = c_uint32(0)
    
    while rounds > 0:
        total.value += delta  
        e.value = (total.value >> 2) & 3
        for p in range(n-1):
            y = c_uint32(v[p+1])
            v[p] = c_uint32(v[p] + MX(z,y,total,key,p,e).value).value
            z.value = v[p]
        y = c_uint32(v[0])
        v[n-1] = c_uint32(v[n-1] + MX(z,y,total,key,n-1,e).value).value
        z.value = v[n-1]
        rounds -= 1 

    return v


def decrypt(n, v, key):
    delta = 0x9e3779b9
    rounds = 6 + 52//n 
    
    total = c_uint32(rounds * delta)
    y = c_uint32(v[0])
    e = c_uint32(0)

    while rounds > 0:
        e.value = (total.value >> 2) & 3
        for p in range(n-1, 0, -1):
            z = c_uint32(v[p-1])
            v[p] = c_uint32((v[p] - MX(z,y,total,key,p,e).value)).value
            y.value = v[p]
        z = c_uint32(v[n-1])  
        v[0] = c_uint32(v[0] - MX(z,y,total,key,0,e).value).value
        y.value = v[0]  
        total.value -= delta
        rounds -= 1

    return v 

def tostring(v):
    v1 = []
    for i in range(len(v)):
        tmpstr = ''
        for j in range(4):
            tmpstr += chr(v[i]>>(8*j) &0xff)
        v1.append(tmpstr) 
    return ''.join(v1) 

#  test  
if __name__ == "__main__":
	# 该算法中每次可加密不只64bit的数据，并且加密的轮数由加密数据长度决定
    v = [0x12345678, 0x78563412]
    k = [0x1, 0x2, 0x3, 0x4]
    n = 2

    print("Data is : ", hex(v[0]), hex(v[1]))
    res = encrypt(n, v, k)
    print("Encrypted data is : ", tostring(res))
    res = decrypt(res, key)
    print("Decrypted data is : ", tostring(res))
"""
Data is :  0x12345678 0x78563412
Encrypted data is :  0xef86c2bb 0x25f31b5e
Decrypted data is :  0x12345678 0x78563412
"""

```

# 换表base64算法

```python
s = "abcdefghijklmnopqrstuvwxyz!@#$%^&*()ABCDEFGHIJKLMNOPQRSTUVWXYZ+/"
# inputs为bytes类型，return string
def My_base64_encode(inputs):
        # 将字符串转化为2进制
        bin_str = []
        for i in inputs:
            x = str(bin(i)).replace('0b', '') 
            # x = str(bin(ord(i))).replace('0b', '')  # inputs为string
            bin_str.append('{:0>8}'.format(x))
        #print(bin_str)
        # 输出的字符串
        outputs = ""
        # 不够三倍数，需补齐的次数
        nums = 0
        while bin_str:
            #每次取三个字符的二进制
            temp_list = bin_str[:3]
            if(len(temp_list) != 3):
                nums = 3 - len(temp_list)
                while len(temp_list) < 3:
                    temp_list += ['0' * 8]
            temp_str = "".join(temp_list)
            # print(temp_str)
            # 将三个8字节的二进制转换为4个十进制
            temp_str_list = []
            for i in range(0,4):
                temp_str_list.append(int(temp_str[i*6:(i+1)*6],2))
            #print(temp_str_list)
            if nums:
                temp_str_list = temp_str_list[0:4 - nums]
                
            for i in temp_str_list:
                outputs += s[i]
            bin_str = bin_str[3:]
        outputs += nums * '='
        print("Encrypted String:\n%s "%outputs)
        return outputs

# inputs为string类型 return string
def My_base64_decode(inputs):
    # 将字符串转化为2进制
    bin_str = []
    for i in inputs:
        if i != '=':
            x = str(bin(s.index(i))).replace('0b', '')
            bin_str.append('{:0>6}'.format(x))
    #print(bin_str)
    # 输出的字符串
    outputs = ""
    nums = inputs.count('=')
    while bin_str:
        temp_list = bin_str[:4]
        temp_str = "".join(temp_list)
        #print(temp_str)
        # 补足8位字节
        if(len(temp_str) % 8 != 0):
            temp_str = temp_str[0:-1 * nums * 2]
        # 将四个6字节的二进制转换为三个字符
        for i in range(0,int(len(temp_str) / 8)):
            outputs += chr(int(temp_str[i*8:(i+1)*8],2))
        bin_str = bin_str[4:]	
    print("Decrypted String:\n%s "%outputs)
    return outputs

# 官方库
# str2为base64加密数据，用string1替换表string2
# input为string return为bytes
base64.b64decode(str2.translate(str.maketrans(string1,string2)))
# 加密没有表替换
base64.b64encode(b'123456') 
```
base64换表加解密，如果是bytes<->stirng的话，加密可用My_base64_encode，解密可用base64.b64decode(str2.translate(str.maketrans(string1,string2)))

# RC4(b64处理)

```python
import sys
import base64
from Crypto.Cipher import  ARC4

class rc4util():
    def __init__(self,key):
        if isinstance(key,str):
            self.__keyGen = key.encode()
        elif isinstance(key,bytes):
            self.__keyGen = key
    def __encrypt(self,data) ->bytes:
        rc4 = ARC4.new( self.__keyGen)
        res = rc4.encrypt(data)
        res = base64.b64encode(res)
        return res
    def __decrypt(self,data)->bytes:
        rc4 = ARC4.new(self.__keyGen)
        res = base64.b64decode(data)
        res = rc4.decrypt(res)
        return res
    def encrypt(self,src)->bytes:  
        res = self.__encrypt(src)    
        return res
    def decrypt(self,src)->bytes:    
        res = self.__decrypt(src)           
        return res


def Entry(src,key):
    rc4 = rc4util(key)
    bret = rc4.encrypt(src)

    if bret:
        print("加密成功:",bret)
    else:
        print("加密失败")


def Decry(src,key):
    rc4 = rc4util(key)
    bret = rc4.decrypt(src)
    if bret:
        print("解密成功:",bret)
    else:
        print("解密失败")

if __name__ == "__main__":
    key = b'carol'
    src = b"xxxsrcFile"  #这里是读取src文件数据,然后对其进行加密.加密的结果写入到dst文件中
    encstr = b"mg6CITV6GEaFDTYnObFmENOAVjKcQmGncF90WhqvCFyhhsyqq1s="
    Entry(src,key)
    Decry(encstr,key)
```

# 自定义维吉尼亚

```python
# write by 2021/7/12
# 维吉尼亚密码
from itertools import cycle

# DIC = 'abcdefghijklmnopqrstuvwxyz0123456789,"{}!'
DIC = 'abcdefghijklmnopqrstuvwxyz'


def judge_key(key):
    if not key:
        return 0
    key = key.lower()
    for i in key:
        if i not in DIC:
            return 0
    return 1


def encrypt_vigenere(string, key):
    if not judge_key(key):
        return -1
    ciphertext = ""
    key_index = 0
    key_len = len(key)
    for i in string:
        if i.isupper():
            i = i.lower()
            ciphertext += DIC[(DIC.index(i)+DIC.index(key[key_index % key_len])) % len(DIC)].upper()
            key_index += 1
        elif i.islower() or i in DIC:
            ciphertext += DIC[(DIC.index(i)+DIC.index(key[key_index % key_len])) % len(DIC)]
            key_index += 1
        else:
            ciphertext += i

    return ciphertext


def decrypt_vigenere(string, key):
    if not judge_key(key):
        return -1
    plaintext = ""
    key_index = 0
    key_len = len(key)
    for i in string:
        if i.isupper():
            i = i.lower()
            plaintext += DIC[(DIC.index(i)-DIC.index(key[key_index % key_len])) % len(DIC)].upper()
            key_index += 1
        elif i.islower() or i in DIC:
            plaintext += DIC[(DIC.index(i)-DIC.index(key[key_index % key_len])) % len(DIC)]
            key_index += 1    
        else:
            plaintext += i
    return plaintext


if __name__ == '__main__':
    key_ = "linux"
    ciphertext_ = encrypt_vigenere("i love you,Common sense is not so common.As an example", key_)
    plaintext_ = decrypt_vigenere(ciphertext_, key_) 
    print(f"{plaintext_}: {ciphertext_}")
```

[爆破密钥网站](https://www.guballa.de/vigenere-solver)

## DES

```python
# -*- coding=utf-8-*-
from Crypto.Cipher import DES
import base64
"""
des cbc加密算法
padding : PKCS5
"""
class DESUtil:
    __BLOCK_SIZE_8 = BLOCK_SIZE_8 = DES.block_size
    __IV = "dy_crack" # __IV = chr(0)*8
    @staticmethod
    def encryt(str, key):
        cipher = DES.new(key, DES.MODE_CBC, DESUtil.__IV)
        x = DESUtil.__BLOCK_SIZE_8 - (len(str) % DESUtil.__BLOCK_SIZE_8)
        if x != 0:
            str = str + chr(x)*x
        msg = cipher.encrypt(str)
        # msg = base64.urlsafe_b64encode(msg).replace('=', '')
        msg = base64.b64encode(msg)
        return msg
    @staticmethod
    def decrypt(enStr, key):
        cipher = DES.new(key, DES.MODE_CBC,DESUtil.__IV)
        # enStr += (len(enStr) % 4)*"="
        # decryptByts = base64.urlsafe_b64decode(enStr)
        decryptByts = base64.b64decode(enStr)
        msg = cipher.decrypt(decryptByts)
        paddingLen = ord(msg[len(msg)-1])
        return msg[0:-paddingLen]
if __name__ == "__main__":
    enc = 'fOCPTVF0diO+B0IMXntkPoRJDUj5CCsT'
    key = 'wctf{wol'
    print (DESUtil.decrypt(enc, key))



```


# rotN

```python
'''
Author: yrl
date : 2022/8/1
'''
import string
import argparse

parser = argparse.ArgumentParser(
    usage="""

python3 rotN.py [-dec] [-h] [-n] [-u] [-l] [-d] [-m] message

Three parameters are optional, the default is the original string
eg: python3 rotN.py -n13 -u -l -d -m message # this table is a-z A-Z 0-9
eg: python3 rotN.py -n13 -s asdfghjklqwertyuASDcv -m message # custom table
eg: python3 rotN.py -n13 -dec -s asdfghjklqwertyuASDcv -m message # custom table and decrypt mode
  """,
    description="This is rotN process."
)
parser.add_argument(
    '-dec', '--decrypt', help='enable decrypt mode', default=False, action='store_true')
parser.add_argument(
    '-n', '--N', help='ROTN,plz choice the number of 3-24.', default=13, type=int,
    choices=[3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24])
parser.add_argument(
    '-u', '--upper', help='Convert plain text with uppercase,default=False', default=False, action='store_true')
parser.add_argument(
    '-l', '--lower', help='Convert plain text with lowercase,default=False', default=False, action='store_true')
parser.add_argument(
    '-d', '--digits', help='Convert plain text with digitscase,default=False', default=False, action='store_true')
parser.add_argument(
    '-s', '--strings', help='Custom rot table')
parser.add_argument(
    '-m', '--message', help='ROTN message.', default="V nz gur qrsnhyg!")
args = parser.parse_args()
word = args.message

lowercase = string.ascii_lowercase  # abcdefghijklmnopqrstuvwxyz
uppercase = string.ascii_uppercase  # ABCDEFGHIJKLMNOPQRSTUVWXYZ
digitscase = string.digits  # 0123456789
customcase = args.strings  # custom table

# control case tables
lower = args.lower
upper = args.upper
digits = args.digits
N = args.N

print("rot%s: " % N, end='')
if not args.decrypt :
        for i in range(len(word)):
                flag = False
                for j in range(len(lowercase)):
                        if lower and word[i] == lowercase[j]:  # search for lower
                                print(lowercase[(j + N) % 26], end='')
                                flag = True
                                break
                        elif upper and word[i] == uppercase[j]:  # search for upper
                                print(uppercase[(j + N) % 26], end='')
                                flag = True
                                break
                if not flag:
                        flag1 = False  # None of the characters match
                        for j in range(len(digitscase)):
                                if digits and word[i] == digitscase[j]:  # search for digits
                                        print(digitscase[(j + N) % 10], end='')
                                        flag1 = True
                                        break
                        if customcase:
                                for j in range(len(customcase)):
                                        if word[i] == customcase[j]:  # search for customcase
                                                print(customcase[(j + N) % (len(customcase))], end='')
                                                flag1 = True
                                                break
                        if not flag1:
                                print(word[i], end='')
        print()
else:
        for i in range(len(word)):
                flag = False
                for j in range(len(lowercase)):
                        if lower and word[i] == lowercase[j]:  # search for lower
                                print(lowercase[(j - N) % 26], end='')
                                flag = True
                                break
                        elif upper and word[i] == uppercase[j]:  # search for upper
                                print(uppercase[(j - N) % 26], end='')
                                flag = True
                                break
                if not flag:
                        flag1 = False  # None of the characters match
                        for j in range(len(digitscase)):
                                if digits and word[i] == digitscase[j]:  # search for digits
                                        print(digitscase[(j - N) % 10], end='')
                                        flag1 = True
                                        break
                        if customcase:
                                for j in range(len(customcase)):
                                        if word[i] == customcase[j]:  # search for customcase
                                                print(customcase[(j - N) % (len(customcase))], end='')
                                                flag1 = True
                                                break
                        if not flag1:
                                print(word[i], end='')
        print()

```

# AES/CBC/PKCS5Padding

```python
# encoding=utf8
from Crypto.Cipher import AES
from base64 import b64decode, b64encode

BLOCK_SIZE = AES.block_size
# 不足BLOCK_SIZE的补位(s可能是含中文，而中文字符utf-8编码占3个位置,gbk是2，所以需要以len(s.encode())，而不是len(s)计算补码)
pad = lambda s: s + (BLOCK_SIZE - len(s.encode()) % BLOCK_SIZE) * chr(BLOCK_SIZE - len(s.encode()) % BLOCK_SIZE)
# 去除补位
unpad = lambda s: s[:-ord(s[len(s) - 1:])]

class AESCipher:
    def __init__(self, secretkey: str,iv:str):
        self.key = secretkey  # 密钥
        self.iv = iv  # 偏移量

    def encrypt(self, text):
        """
        加密 ：先补位，再AES加密，后base64编码
        :param text: 需加密的明文
        :return:
        """
        # text = pad(text) 包pycrypto的写法，加密函数可以接受str也可以接受bytess
        text = pad(text).encode()  # 包pycryptodome 的加密函数不接受str
        cipher = AES.new(key=self.key.encode(), mode=AES.MODE_CBC, IV=self.iv.encode())
        encrypted_text = cipher.encrypt(text)
        # 进行64位的编码,返回得到加密后的bytes，decode成字符串
        return b64encode(encrypted_text).decode('utf-8')

    def decrypt(self, encrypted_text):
        """
        解密 ：偏移量为key[0:16]；先base64解，再AES解密，后取消补位
        :param encrypted_text : 已经加密的密文
        :return:
        """
        encrypted_text = b64decode(encrypted_text)
        cipher = AES.new(key=self.key.encode(), mode=AES.MODE_CBC, IV=self.iv.encode())
        decrypted_text = cipher.decrypt(encrypted_text)
        return unpad(decrypted_text).decode('utf-8')

dde = b'8fELmoXiWXHTgnSASsWOFxKVCXMgDeSRWZpwxT5Vgltq3oqeKmwH8WZIui65GPsp'
key = 'Z29qZSUgYKMmYJ5fch9kZL=='
iv = b64encode(b'flagflagre').decode().replace("\n", "")
decrypted_text = AESCipher(key,iv).decrypt(dde)
print(decrypted_text)
```
# AES/ECB
```python
from Crypto.Cipher import AES
def pad(data):
    pad_data = data
    for i in range(0,16-len(data)):
        pad_data = pad_data + ' '
    return pad_data
 
def encrypt(key,text):
    text = pad(text)
    cryptos = AES.new(key=key, mode=AES.MODE_ECB)
    cipher_text = cryptos.encrypt(text)
    return cipher_text

```