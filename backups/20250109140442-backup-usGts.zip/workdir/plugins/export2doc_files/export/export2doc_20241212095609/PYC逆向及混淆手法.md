---
title: PYC逆向及混淆手法
id: 117
date: 2024-01-09 20:09:11
auther: yrl
cover: 
excerpt: 工具由于010editor的模板库只有python2.7的pyc模板，所以可以自己导入一个python3.8的模板 010 editor python3.8 pyc模板//------------------------------------------------//--- 010 Editor
permalink: /archives/pyc%E9%80%86%E5%90%91
categories:
 - re知识点
 - 花指令
 - python
tags: 
 - pyc逆向
 - 花指令
---

# 前言

最近频繁遇见pyc的逆向题目，简单的就是直接工具获得源码，审计代码即可，但是如果加了花指令，逆向代价和难度直接直线上升，所有记录下花指令混淆及去除手法，顺便整理下pyc文件格式。

# 工具

由于010editor的模板库只有python2.7的pyc模板，所以可以自己导入一个python3.8的模板 [010 editor python3.8 pyc模板](https://github.com/UndeadFu/pyc-3.8-3.10-template/blob/main/pyc_3.8%2B.bt)

比较流行的pyc反编译工具为uncompyle6、pycdc，最新出了一个pydumpck工具可以直接反编译exe/elf为py，不过成功率和兼容性还在提升。

对于正常的 pyc 文件，使用 uncompyle6 插件可以正常的进行字节码逆向，得到原来的代码
## uncompyle6

`uncompyle6 ./py2.pyc  `
详细安装[使用方法](https://github.com/rocky/python-uncompyle6)

## pycdc

需要编译之后运行  `./pycdc ./pyc.pyc ` 
具体编译方法参考[pycdc](https://github.com/zrax/pycdc)

## pydumpck

运行`pydumpck *.exe/*.pyc`支持exe和pyc的反编译，支持上面两种方式反编译，具有多线程支持

安装：pip install pydumpck即可。

## PY4COC

[PY4COC](https://github.com/Svenskithesource/PY4COC)，是一个python脚本，依赖pycdc，可直接把pyc或exe反编译成python文件。实现了pydumpck的基础功能。

## pyinstxtractor 

pyinstxtractor是支持通过pyinstaller打包成的elf或exe的解包，支持的pyinstaller的版本较全，解包效果较好，可搭配pydumpck和uncompyle6使用。

[pyinstxtractor](https://github.com/extremecoders-re/pyinstxtractor)

## 在线工具

在线反编译[tool.lu](https://tool.lu/pyc)，支持所有版本python，会员好用，非会员只能30分钟一次喽

# 基础知识储备

Python执行这个文件首先要进行的动作就是编译，编译会得到字节码（pyc）。然而除了字节码之外，还应该包含一些其它的信息，这些信息也是Python运行的时候所必须的。

在编译过程中，像常量值、字符串这些源代码当中的静态信息都会被Python编译器收集起来，并且这些静态信息也都会体现在编译之后的结果里面。在Python运行期间，这些源文件提供的静态信息都会被存储在一个运行时的对象当中，当Python运行结束时，这个运行时对象中所包含的信息还会被存储在一种文件中。这个对象和文件就是PyCodeObject对象和pyc文件。

## pyc文件
Pyc文件是py编译过程中产生的字节码文件，可以由虚拟机直接执行，是python将目标源码编译成字节码以后在磁盘上的文件形式。

## PyCodeObject
Python中的字节码只是一个PyBytesObject对象、或者说一段字节序列，PyCodeObject对象中有一个成员co_code，它是一个指针，指向了这段字节序列。但是这个对象除了有co_code指向字节码之外，还有很多其它成员，负责保存代码涉及到的常量、变量(名字、符号)等等。

所以我们知道了，pyc文件里面的内容是PyCodeObject对象。对于Python编译器来说，PyCodeObject对象才是其真正的编译结果，而pyc文件是这个对象在硬盘上表现形式。

python虚拟机执行的是字节码，而字节码就是PyCodeObject中的co_code成员，所以我们先了解下PyCodeObject的结构体

python2.7，位于python目录下`include/code.h`:
```c
typedef struct {
    PyObject_HEAD
    int co_argcount;        /* 位置参数个数 */
    int co_nlocals;         /* 局部变量个数 */
    int co_stacksize;       /* 栈大小 */
    int co_flags;   
    PyObject *co_code;      /* 字节码指令序列 */
    PyObject *co_consts;    /* 所有常量集合 */
    PyObject *co_names;     /* 所有符号名称集合 */
    PyObject *co_varnames;  /* 局部变量名称集合 */
    PyObject *co_freevars;  /* 闭包用的的变量名集合 */
    PyObject *co_cellvars;  /* 内部嵌套函数引用的变量名集合 */
    /* The rest doesn’t count for hash/cmp */
    PyObject *co_filename;  /* 代码所在文件名 */
    PyObject *co_name;      /* 模块名|函数名|类名 */
    int co_firstlineno;     /* 代码块在文件中的起始行号 */
    PyObject *co_lnotab;    /* 字节码指令和行号的对应关系 */
    void *co_zombieframe;   /* for optimization only (see frameobject.c) */
} PyCodeObject;
```
python3.9，位于python目录下include/cpython/code.h:
```c
typedef struct {
    PyObject_HEAD		/* 头部信息, 我们看到真的一切皆对象, 字节码也是个对象 */	
    int co_argcount;            /* 可以通过位置参数传递的参数个数 */
    int co_posonlyargcount;     /* 只能通过位置参数传递的参数个数,  Python3.8新增 */
    int co_kwonlyargcount;      /* 只能通过关键字参数传递的参数个数 */
    int co_nlocals;             /* 代码块中局部变量的个数，也包括参数 */
    int co_stacksize;           /* 执行该段代码块需要的栈空间 */
    int co_flags;               /* 参数类型标识 */
    int co_firstlineno;         /* 代码块在对应文件的行号 */
    PyObject *co_code;          /* 指令集, 也就是字节码, 它是一个bytes对象 */
    PyObject *co_consts;        /* 常量池, 一个元组，保存代码块中的所有常量。 */
    PyObject *co_names;         /* 一个元组,保存代码块中引用的其它作用域的变量 */
    PyObject *co_varnames;      /* 一个元组,保存当前作用域中的变量 */
    PyObject *co_freevars;      /* 内层函数引用的外层函数的作用域中的变量 */
    PyObject *co_cellvars;      /* 外层函数中作用域中被内层函数引用的变量，本质上和co_freevars是一样的 */

    Py_ssize_t *co_cell2arg;    /* 无需关注 */
    PyObject *co_filename;      /* 代码块所在的文件名 */
    PyObject *co_name;          /* 代码块的名字，通常是函数名或者类名 */
    PyObject *co_lnotab;        /* 字节码指令与python源代码的行号之间的对应关系，以PyByteObject的形式存在 */
    
    //剩下的无需关注了
    void *co_zombieframe;       /* for optimization only (see frameobject.c) */
    PyObject *co_weakreflist;   /* to support weakrefs to code objects */
    void *co_extra;
    unsigned char *co_opcache_map;
    _PyOpcache *co_opcache;
    int co_opcache_flag; 
    unsigned char co_opcache_size; 
} PyCodeObject;

```
关于格式，py3相对于py2有所变动，py3的PyCodeObject新增加了co_posonlyargcount、co_kwonlyargcount几个字段。

Python编译器在对Python源代码进行编译的时候，对于代码中的每一个block，都会创建一个PyCodeObject与之对应，PyCodeObject也可以嵌套，各种PyCodeObject组成完整的程序。
具体PyCodeObject的成员解释参考[文章](https://www.cnblogs.com/traditional/p/13507329.html)

提一下，函数的字节码怎么单独获得:
```python
def foo(a, b, /, c, *, d, e):
    f = 123
    g = list()
    g.extend([tuple, getattr, print])


print(foo.__code__.co_code)
"""
b'd\x01}\x05t\x00\x83\x00}\x06|\x06\xa0\x01t\x02t\x03t\x04g\x03\xa1\x01\x01\x00d\x00S\x00'
"""
# 这便是字节码, 当然单单是这些字节码肯定不够的, 所以还需要其它的静态信息
# 其它的信息显然连同字节码一样, 都位于PyCodeObject中

# co_lnotab: 字节码指令与python源代码的行号之间的对应关系，以PyByteObject的形式存在
print(foo.__code__.co_lnotab)  # b'\x00\x01\x04\x01\x06\x01'
"""
然而事实上，Python不会直接记录这些信息，而是会记录增量值。比如说：
字节码在co_code中的偏移量            .py文件中源代码的行号
0                                  1  
6                                  2
50                                 7

那么co_lnotab就应该是: 0 1 6 1 44 5
0和1很好理解, 就是co_code和.py文件的起始位置
而6和1表示字节码的偏移量是6, .py文件的行号增加了1
而44和5表示字节码的偏移量是44, .py文件的行号增加了5
"""
```
## PyCodeObject对象生成

```python
statement = "a, b = 1, 2"
# 参数一：代码
# 参数二：可以为这些代码起一个文件名
# 参数三：执行方式,可以选择三种方式。exec: 将源码当做一个模块来编译;single: 用于编译一个单独d的Python语句(交互式下);eval:用于编译一个eval表达式
# 这里显然是exec
co = compile(statement, "d1ag0n", "exec")
print(co.co_firstlineno)  # 1
print(co.co_filename)  # d1ag0n
print(co.co_argcount)  # 0

# 这里是一个元组，因为我们是a, b = 1, 2这种方式赋值的，所以加载的是一个元组
print(co.co_consts)  # ((1, 2), None)

statement = "a = 1;b = 2"
co = compile(statement, "d1ag0n", "exec")
print(co.co_consts)  # (1, 2, None)
print(co.co_names)  # ('a', 'b')

```
## 访问PyCodeObject对象
以访问PyCodeObject对象的nlocals为例
	
    co_nlocals：代码块中局部变量的个数，也包括参数

```python
def foo(a, b, *, c):
    name = "xxx"
    age = 16
    gender = "f"
    c = 33

print(foo.__code__.co_nlocals)  # 6
```
局部变量：a、b、c、name、age、gender，所以我们看到在编译成字节码的时候函数内局部变量的个数就已经确定了，因为它是静态存储的。

## 生成pyc文件
python脚本单独运行时是不会有pyc文件生成的，只有当脚本被视为一个库被另一个脚本引用时(import module)，会生成pyc文件，为的是加快运行速度。也可以主动生成pyc文件：
```bash
python -m py_compile test.py #单个生成
python -m compileall /path/to/  #批量生成
```
脚本生成：
```python
# 单个
import py_compile
if __name__=='__main__':
　　　　py_compile.compile('/path/to/test.py')#/path/to/代表脚本所在目录
# 批量
import compileall
if __name__=='__main__':
        compileall.compile_dir('/path/to')
```
pyo为pyc的优化版，大小更小，运行速度相差无几，生成时只需加上`-O`参数。

## pyc文件格式

各个版本的pyc文件头：
```
enum PycMagic {
    MAGIC_1_0 = 0x00999902,
    MAGIC_1_1 = 0x00999903, /* Also covers 1.2 */
    MAGIC_1_3 = 0x0A0D2E89,
    MAGIC_1_4 = 0x0A0D1704,
    MAGIC_1_5 = 0x0A0D4E99,
    MAGIC_1_6 = 0x0A0DC4FC,

    MAGIC_2_0 = 0x0A0DC687,
    MAGIC_2_1 = 0x0A0DEB2A,
    MAGIC_2_2 = 0x0A0DED2D,
    MAGIC_2_3 = 0x0A0DF23B,
    MAGIC_2_4 = 0x0A0DF26D,
    MAGIC_2_5 = 0x0A0DF2B3,
    MAGIC_2_6 = 0x0A0DF2D1,
    MAGIC_2_7 = 0x0A0DF303,

    MAGIC_3_0 = 0x0A0D0C3A,
    MAGIC_3_1 = 0x0A0D0C4E,
    MAGIC_3_2 = 0x0A0D0C6C,
    MAGIC_3_3 = 0x0A0D0C9E,
    MAGIC_3_4 = 0x0A0D0CEE,
    MAGIC_3_5 = 0x0A0D0D16,
    MAGIC_3_5_3 = 0x0A0D0D17,
    MAGIC_3_6 = 0x0A0D0D33,
    MAGIC_3_7 = 0x0A0D0D42,
    MAGIC_3_8 = 0x0A0D0D55,
    MAGIC_3_9 = 0x0A0D0D61,
    MAGIC_3_10 = 0x0A0D0D6F,
};
```
前面我们提到，Python通过import module进行加载时，如果没有找到相应的pyc或者dll文件，就会在py文件的基础上自动创建pyc文件。所以想要了解pyc文件是怎么创建的，只需要了解PyCodeObject是如何写入的即可。关于写入pyc文件，主要写入三个内容：

1. magic number

这是Python定义的一个整数值，不同版本的Python会定义不同的`magic number`，这个值是为了保证Python能够加载正确的pyc。比如Python3.7不会加载3.6版本的pyc，因为Python在加载这个pyc文件的时候会首先检测该pyc的`magic number`，如果和自身的`magic number`不一致，则拒绝加载。占四字，紧接着四字节未用。

2. pyc的创建时间

这个很好理解，因为编译完之后要是把源代码修改了怎么办呢？因此会判断源代码的最后修改时间和pyc文件的创建时间，如果pyc文件的创建时间比源代码修改时间要早，说明在生成pyc之后，源代码被修改了，那么会重新编译新的pyc，而反之则会直接加载pyc。占四字节。

3. pyc的hash值

python3新增，占四字节。

4. PyCodeObject对象

hash值后面是PyCodeObject对象。当然还有字节码，不过PyCodeObject里面的co_code指向了这个字节码，所以我们就直接说PyCodeObject对象了。

如下是一个python3.8的pyc文件：

![image](/upload/2022/12/image.png)

**pyc文件头部**：
前4个字节：55 0d 0d 0a，表示python版本3.8
后四个字节：00 00 00 00 ，暂无用
接着4个字节：df 27 71 63，表示pyc文件修改时间
接着四字节：8a 21 00 00, pyc的hash值
**PyCodeObject对象二进制编译结果**：
第17字节：0xe3，TYPE_CODE字段，表示接下为是一个PyCodeObject对象
**PyCodeObject对象----全局参数**:
然后4个字节是0x00 0000 00，code block的位置参数个数co_argument，这里是0；
再接着4个字节是0x00 0000 00， code block中的只能通过位置参数传递的局部变量个数co_posonlyargcount，这里是0；
再接着4个字节是0x00 0000 00， code block中的只能通过关键字参数传递的局部变量个数co_kwonlyargcount，这里是0；
再接着4个字节是0x00 0000 00， code block中的局部变量个数co_nlocals，这里是0；
再接着4个字节是0x0a 0000 00， code block需要的栈空间co_stacksize，这里是10；
再接着4个字节是0x40 0000 00， co_flags，参数类型标识，这里是64；
**PyCodeObject对象----code block**:
1个字节0x73为TYPE_CODE字段， 表示该字段为string格式；
4个字节62 04 00 00表示code block段的数据部分占用0x0462个字节；
接下来0x0462个字节6400 ...... 64 01 53 00为该TYPE_CODE字段（数据类型string）部分，也就是pyc文件中包含的字节码指令

再往下的逐个TYPE_CODE字段都是重复结构的，用来表示PyCodeObject对象中的一些其他参数。

## python字节码
Python 代码先被编译为字节码后，再由 Python 虚拟机来执行字节码，Python 的字节码是一种类似汇编指令的中间语言，一个 Python 语句会对应若干字节码指令，虚拟机一条一条执行字节码指令，从而完成程序执行。
混淆前要清楚python字节码都有哪些，功能是什么，这里给出一个脚本，可以查看当前python环境的opcode：
```python
import opcode
import sys
if len(sys.argv) == 1:
	for op in range(len(opcode.opname)):	    
	    	print('0x%.2x(%.3d): %s'%(op,op,opcode.opname[op]))
else:   
	opname = sys.argv[1]
	for op in range(len(opcode.opname)):	    
		if opname == opcode.opname[op]:
			print('0x%.2x(%.3d): %s'%(op,op,opcode.opname[op]))
			break
```
用法（没有参数会输出所有opcode）：
```bash
➜  PYC python3 getopcode.py BUILD_TUPLE_UNPACK
0x98(152): BUILD_TUPLE_UNPACK
```
## 函数调用
以简单的例子为例：
```python
import dis

def fun(x, y, z):
    a = 1
    a += 1
    print("aaa")
    fun(1, 2, 3)
    return

dis.dis(fun)
```
会输出fun函数的反编译后的指令，运行`python3 -u python.py `：
```
  4           0 LOAD_CONST               1 (1)
              2 STORE_FAST               3 (a)

  5           4 LOAD_FAST                3 (a)
              6 LOAD_CONST               1 (1)
              8 INPLACE_ADD
             10 STORE_FAST               3 (a)

  6          12 LOAD_GLOBAL              0 (print)
             14 LOAD_CONST               2 ('aaa')
             16 CALL_FUNCTION            1
             18 POP_TOP

  7          20 LOAD_GLOBAL              1 (fun)
             22 LOAD_CONST               1 (1)
             24 LOAD_CONST               3 (2)
             26 LOAD_CONST               4 (3)
             28 CALL_FUNCTION            3
             30 POP_TOP

  8          32 LOAD_CONST               0 (None)
             34 RETURN_VALUE
```

第一列对应的是源代码中的行号
第二列开头的数字是opcode的当前位置，紧接着是opname，对应的是源代码转化成的字节码
第三列为此次操作对应的值（括号内为具体值）

**注意**：python2 opcode有1字节（无参数）指令、3字节指令（两字节为参数，小端序）；python3统一为2字节指令。

变量赋值一般会先讲变量值load栈顶，然后存储到对应变量，对应第四行
函数调用一般先将全局对象print函数推入程序栈，然后将参数aaa推入栈，调用函数并指定有几个参数（参数个数由CALL_FUNCTION指令的参数决定），解释器就会将栈顶的参数传递给函数，然后调用

**注意**：
- 函数的参数入栈顺序是从左往右，最右边的在栈的最顶端。
- CALL_FUNCTION 会在结束后弹出栈顶对应参数数量的元素，但是函数不会被弹出栈，因此最后有一个 POP_TOP

## 常用指令
常用字节码如下：
-   详细内容见[官方文档](https://docs.python.org/zh-cn/3.6/library/dis.html#python-bytecode-instructions)

-   一般指令与一元操作指令

| 指令                | 作用                                                         |
| ------------------- | ------------------------------------------------------------ |
| NOP                 | 无作用，用于占位                                             |
| POP_TOP             | 弹出栈顶元素                                                 |
| ROT_TWO             | 交换栈顶元素                                                 |
| LOAD_CONST          | 将读取的值推入栈                                             |
| LOAD_GLOBAL         | 将全局变量对象压入栈顶                                       |
| STORE_FAST          | 将栈顶指令存入对应局部变量                                   |
| COMPARE_OP          | 比较操作符                                                   |
| CALL_FUNCTION       | 调用函数                                                     |
| BUILD_SLICE         | 调用切片，跟的参数为切片的值的个数，一般从上到下为 [Val1:Val2:Val3] |
| JUMP_ABSOLUTE       | 向下跳转几句操作符，变量为跳转偏移量                         |
| UNARY_POSITIVE      | 实现 Val1 = +Val1                                            |
| UNARY_NEGATIVE      | 实现 Val1 = -Val1                                            |
| UNARY_NOT           | 实现 Val1 = not Val1                                         |
| UNARY_INVERT        | 实现 Val1 = ~Val                                             |
| FOR_ITER            | for 循环                                                     |
| GET_ITER            | 获取迭代器（一般后面跟循环）                                 |
| GET_YIELD_FROM_ITER | 获取 yield 生成器                                            |

-   二元操作指令

| 指令                   | 作用                                 |
| ---------------------- | ------------------------------------ |
| BINARY_POWER           | 乘方，栈顶数为指数                   |
| BINARY_MULTIPLY        | 乘法                                 |
| BINARY_MATRIX_MULTIPLY | 矩阵乘法，3.5 引入的新功能           |
| BINARY_FLOOR_DIVIDE    | 除法，结果向下取整                   |
| BINARY_TRUE_DIVIDE     | 除法                                 |
| BINARY_MODULO          | 取余                                 |
| BINARY_ADD             | 加法                                 |
| BINARY_SUBTRACT        | 减法                                 |
| BINARY_SUBSCR          | 数组取下标，栈顶为下标               |
| BINARY_LSHIFT          | 左移操作符（乘2）                    |
| BINARY_RSHIFT          | 右移操作符（除2向下取整）            |
| BINARY_AND             | 按位与                               |
| BINARY_XOR             | 异或                                 |
| BINARY_OR              | 按位或                               |
| STORE_SUBSCR           | 列表下标存储，例如 Val1[Val2] = Val3 |
| DELETE_SUBSCR          | 按下标删除元素，例如 del Val1[Val2]  |

-   自身操作指令，类似 `b += 1` ，就是上方有 BINARY 的指令的 BINARY 改成 INPLACE

-   其他指令见[官方文档](https://docs.python.org/zh-cn/3.6/library/dis.html#python-bytecode-instructions)
.
# pyc混淆
## pyc花指令
常见的python花指令形式有两种：单重叠指令和多重叠指令。
以下以python3.8为例，指令长度为2字节。
**单重叠指令：**
```
#例1 Python单重叠指令
 0 JUMP_ABSOLUTE        [71 04]     5 
 2 PRINT_ITEM           [47 --]
 4 LOAD_CONST           [64 10]     16
 6 STOP_CODE            [00 --]
#例1 实际执行
 0 JUMP_ABSOLUTE        [71 04]     5 
 4 LOAD_CONST           [64 10]     16
```
单重叠指令多是分支的跳转，导致一些反编译工具如pycdc、uncompyle6出错。
**多重叠指令：**
```
#例2 Python多重叠指令
 0 EXTENDED_ARG         [91 64] 
 2 EXTENDED_ARG         [91 53]
 4 JUMP_ABSOLUTE        [71 01]
#例2 实际执行
 0 EXTENDED_ARG         [91 64] 
 2 EXTENDED_ARG         [91 53]
 4 JUMP_ABSOLUTE        [71 02]
 1 LOAD_CONST           [64 91]
 3 RETURN_VALUE         [53 --]
```
多重叠指令是将指令的数据部分当作下一条指令的opcode部分执行，在跳转基础上进一步混淆控制流的技术手段，可以有效对抗逆向者。

常见的花指令形式：
```
 83         654 JUMP_FORWARD             0 (to 656)
        >>  656 JUMP_FORWARD             2 (to 660)
            658 NOP
        >>  660 JUMP_FORWARD             4 (to 666)

 84         662 NOP
            664 NOP
        >>  666 JUMP_FORWARD             4 (to 672)
            668 NOP

 85         670 NOP
        >>  672 JUMP_FORWARD             4 (to 678)
            674 NOP
            676 NOP
            
            
 65       412 LOAD_CONST               1 ('You Are Debug')
            414 LOAD_CONST               1 ('You Are Debug')
            416 LOAD_CONST               2 ('0b')
            418 JUMP_FORWARD             0 (to 420)
```
NOP为junk code，其他的花指令形式可自由发挥，只要不影响正常执行逻辑即可。

## pyc解花指令

去花之路漫漫不可懈怠矣，pyc去除花指令后，很大可能是不能被现有工具反编译成源码的，因为现有反编译工具对pyc要求比较严格，不能有nop以及其他junk指令，但程序运行时python虚拟机却没有。
解决方法：

1. 将原来花指令的地方填充其他无关指令占位
2. 修改pycdc源码，将反编译相关的限制放开

以上两种方式均为理论，总之想在patch过的pyc反编译回原来的源码，需要做的工作还挺多。

自己写了一个自动去除花指令的脚本，去花思路：用python模拟执行python的opcode，遇到分支就跳转，直到ret_value停止本次执行，采用的是简单的DFS递归算法，支持python2.7和python3.8版本的去花：
```python2.7
import marshal, sys, opcode, types, dis

NOP = 9

HAVE_ARGUMENT = 90

JUMP_FORWARD = 110
JUMP_IF_FALSE_OR_POP = 111
JUMP_IF_TRUE_OR_POP = 112
JUMP_ABSOLUTE = 113
POP_JUMP_IF_FALSE = 114
POP_JUMP_IF_TRUE = 115

CONTINUE_LOOP = 119
FOR_ITER = 93

RETURN_VALUE = 83

used_set = set()

def deconf_inner(code, now):
    global used_set

    while code[now] != RETURN_VALUE:
        if now in used_set:
            break
        used_set.add(now)
        if code[now] >= HAVE_ARGUMENT:
            used_set.add(now+1)
            used_set.add(now+2)
        op = code[now]

        #print(str(now) + " " + opcode.opname[op])

        if op == JUMP_FORWARD:
            arg = code[now+2] << 8 | code[now+1]
            now += arg + 3
            continue

        elif op == JUMP_ABSOLUTE:
            arg = code[now+2] << 8 | code[now+1]
            now = arg
            continue

        elif op == JUMP_IF_TRUE_OR_POP:
            arg = code[now+2] << 8 | code[now+1] 
            deconf_inner(code, arg)

        elif op == JUMP_IF_FALSE_OR_POP:
            arg = code[now+2] << 8 | code[now+1] 
            deconf_inner(code, arg)

        elif op == POP_JUMP_IF_TRUE:
            arg = code[now+2] << 8 | code[now+1] 
            deconf_inner(code, arg)

        elif op == POP_JUMP_IF_FALSE: 
            arg = code[now+2] << 8 | code[now+1] 
            deconf_inner(code, arg)

        elif op == CONTINUE_LOOP:
            arg = code[now+2] << 8 | code[now+1] 
            deconf_inner(code, arg)

        elif op == FOR_ITER: 
            arg = code[now+2] << 8 | code[now+1] 
            deconf_inner(code, now + arg + 3)

        if op < HAVE_ARGUMENT:
            now += 1
        else:
            now += 3

    used_set.add(now)
    if code[now] >= HAVE_ARGUMENT:
        used_set.add(now+1)
        used_set.add(now+2)

def deconf(code):
    global used_set

    used_set = set() #Remember to clean up used_set for every target function

    cod = list(map(ord, code))
    deconf_inner(cod, 0)

    for i in range(len(cod)):
        if i not in used_set:
            cod[i] = NOP

    return "".join(list(map(chr, cod)))

with open(sys.argv[1], 'rb') as f:
    header = f.read(8)
    code = marshal.load(f)

print(code.co_consts,type(code))
'''
print(dis.dis(deconf(code.co_consts[3].co_code)))
'''

consts = list()

for i in range(len(code.co_consts)):
    if hasattr(code.co_consts[i], 'co_code'):
        consts.append(types.CodeType(code.co_consts[i].co_argcount,
            # c.co_kwonlyargcount,  Add this in Python3
            code.co_consts[i].co_nlocals,
            code.co_consts[i].co_stacksize,
            code.co_consts[i].co_flags,
            deconf(code.co_consts[i].co_code),
            code.co_consts[i].co_consts,
            code.co_consts[i].co_names,
            code.co_consts[i].co_varnames,
            code.co_consts[i].co_filename,
            code.co_consts[i].co_name,
            code.co_consts[i].co_firstlineno,
            code.co_consts[i].co_lnotab,   # In general, You should adjust this
            code.co_consts[i].co_freevars,
            code.co_consts[i].co_cellvars))
    else:
        consts.append(code.co_consts[i])

mode = types.CodeType(code.co_argcount,
    # c.co_kwonlyargcount,  Add this in Python3
    code.co_nlocals,
    code.co_stacksize,
    code.co_flags,
    deconf(code.co_code),
    tuple(consts),
    code.co_names,
    code.co_varnames,
    code.co_filename,
    code.co_name,
    code.co_firstlineno,
    code.co_lnotab,   # In general, You should adjust this
    code.co_freevars,
    code.co_cellvars)

f = open(sys.argv[1]+".mod", 'wb') 
f.write(header)
marshal.dump(mode, f)
```
```python3.8
import marshal, sys, opcode, types, dis
import opcode


def getopcode(opname):
    return opcode.opname.index(opname)


NOP = getopcode('NOP')

# HAVE_ARGUMENT = getopcode('HAVE_ARGUMENT')  # py2.7

JUMP_FORWARD = getopcode('JUMP_FORWARD')
JUMP_IF_FALSE_OR_POP = getopcode('JUMP_IF_FALSE_OR_POP')
JUMP_IF_TRUE_OR_POP = getopcode('JUMP_IF_TRUE_OR_POP')
JUMP_ABSOLUTE = getopcode('JUMP_ABSOLUTE')
POP_JUMP_IF_FALSE = getopcode('POP_JUMP_IF_FALSE')
POP_JUMP_IF_TRUE = getopcode('POP_JUMP_IF_TRUE')
EXTENDED_ARG = getopcode('EXTENDED_ARG')
# CONTINUE_LOOP = getopcode('CONTINUE_LOOP')  # py2.7
FOR_ITER = getopcode('FOR_ITER')

RETURN_VALUE = getopcode('RETURN_VALUE')

used_set = set()


def deconf_inner(code, now):
    global used_set

    while code[now] != RETURN_VALUE:
        if now in used_set:
            break
        used_set.add(now)
        used_set.add(now + 1)
        op = code[now]


        # print(str(now) + " " + opcode.opname[op])

        if op == EXTENDED_ARG: # 对JUMP_FORWARD带有EXTENDED_ARG的处理
            # 第一层
            op_next = code[now + 2]
            now += 2
            used_set.add(now)
            used_set.add(now+1)
            if op_next == EXTENDED_ARG:
                # 第二层
                arg = code[now - 1] << 8|code[now + 1]
                op_next_next = code[now + 2]
                now += 2
                used_set.add(now)
                used_set.add(now+1)
                if op_next_next == EXTENDED_ARG:
                    arg = arg << 8 | code[now + 1]
                    # 第三层
                    if op_next == JUMP_FORWARD or op_next == FOR_ITER:
                        arg = arg << 8 | code[now + 1]
                        deconf_inner(code, arg + now + 2)
                    else:
                        arg = arg << 8 | code[now + 1]
                        deconf_inner(code, arg)
                elif op_next == JUMP_FORWARD or op_next == FOR_ITER:
                    arg = code[now - 1] << 8 | code[now + 1]
                    deconf_inner(code, arg + now + 2)
                else:
                    arg = code[now - 1] << 8 | code[now + 1]
                    deconf_inner(code, arg)
            elif op_next == JUMP_FORWARD or op_next == FOR_ITER:
                arg = code[now - 1] << 8 | code[now + 1]
                deconf_inner(code, arg + now + 2)
            else:
                arg = code[now - 1] << 8 | code[now + 1]
                deconf_inner(code, arg)

            
        elif op == JUMP_FORWARD:
            arg = code[now + 1]
            now += arg + 2
            op_next = code[now]
            if op_next == JUMP_FORWARD or arg == 0 or arg == 1 or arg == 2 or arg == 4: # 一般JUMP_FORWARD参数为0、2、4都为花指令
                used_set.remove(now - (arg + 2))
                used_set.remove(now - (arg + 2) + 1)
            continue

        elif op == JUMP_ABSOLUTE:
            arg = code[now + 1]
            now = arg
            continue

        elif op == JUMP_IF_TRUE_OR_POP:
            arg = code[now + 1]
            deconf_inner(code, arg)

        elif op == JUMP_IF_FALSE_OR_POP:
            arg = code[now + 1]
            deconf_inner(code, arg)

        elif op == POP_JUMP_IF_TRUE:
            arg = code[now + 1]
            deconf_inner(code, arg)

        elif op == POP_JUMP_IF_FALSE:
            arg = code[now + 1]
            deconf_inner(code, arg)

        elif op == FOR_ITER:
            arg = code[now + 1]
            deconf_inner(code, now + arg + 2)

        now += 2

    used_set.add(now)


def deconf(code):
    global used_set

    used_set = set()  # Remember to clean up used_set for every target function

    # cod = list(map(ord, code))
    cod = list(code)
    deconf_inner(cod, 0)

    for i in range(len(cod)):
        if i not in used_set:
            cod[i] = NOP
    # aa = bytes(cod)
    aa = b''.join(map(lambda x: int.to_bytes(x, 1, 'little'), cod))
    return aa


filename = 'PYC.pyc'
with open(filename, 'rb') as f:
    header = f.read(16)
    code = marshal.load(f)

print(code.co_consts)
'''

print(dis.dis(deconf(code.co_consts[3].co_code)))
'''

consts = list()

for i in range(len(code.co_consts)):
    if hasattr(code.co_consts[i], 'co_code'):
        consts.append(types.CodeType(code.co_consts[i].co_argcount,
                                     code.co_posonlyargcount,
                                     code.co_kwonlyargcount,  # Add this in Python3
                                     code.co_consts[i].co_nlocals,
                                     code.co_consts[i].co_stacksize,
                                     code.co_consts[i].co_flags,
                                     deconf(code.co_consts[i].co_code),
                                     code.co_consts[i].co_consts,
                                     code.co_consts[i].co_names,
                                     code.co_consts[i].co_varnames,
                                     code.co_consts[i].co_filename,
                                     code.co_consts[i].co_name,
                                     code.co_consts[i].co_firstlineno,
                                     code.co_consts[i].co_lnotab,  # In general, You should adjust this
                                     code.co_consts[i].co_freevars,
                                     code.co_consts[i].co_cellvars))
    else:
        consts.append(code.co_consts[i])

mode = types.CodeType(code.co_argcount,
                      code.co_posonlyargcount,
                      code.co_kwonlyargcount,  # Add this in Python3
                      code.co_nlocals,
                      code.co_stacksize,
                      code.co_flags,
                      deconf(code.co_code),
                      tuple(consts),
                      code.co_names,
                      code.co_varnames,
                      code.co_filename,
                      code.co_name,
                      code.co_firstlineno,
                      code.co_lnotab,  # In general, You should adjust this
                      code.co_freevars,
                      code.co_cellvars)

f = open(filename + ".mod", 'wb')
f.write(header)
marshal.dump(mode, f)

```
使用方法`python3 run_code.py pyc.pyc`，执行成功后会在当前目录生成*.mod文件，为去除花指令的pyc，基本上不影响阅读，对于特定的花指令还需要手动去除。

python提供了dis（反汇编）和marshal模块（序列化）来反汇编和序列化python字节码，我们可以使用这两个模块来反汇编pyc文件，生成python字节码：

```python
import marshal,dis

fd = open("PYC-src.pyc.mod",'rb')
fd.seek(0x10)
samplecode = marshal.load(fd)
fd.close()
dis.dis(samplecode)
```
```python
import dis
import marshal
'''
09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 09 00 
'''
def comp_py(py_path,flag):
    source = open(py_path).read()
    code = compile(source, py_path, 'exec')
    if(flag=='0'):
        dis.dis(code)
    else:   
        print("len 0x%.8X" % (len(code.co_code)))
        print("0x%.8X" % (code.co_argcount))
        print("0x%.8X" % (code.co_nlocals))
        print("0x%.8X" % (code.co_stacksize))
        print("0x%.8X" % (code.co_flags))
        print(code.co_code)
        print(code.co_consts)
        print(code.co_names)
        print(code.co_varnames)
        print(code.co_cellvars)
        print(code.co_freevars)
        print(code.co_filename)
        print(code.co_name)
        print("0x%.8X" % (code.co_firstlineno))
        print(code.co_lnotab)
        # print(code.co_zombieframe)
    
def comp_pyc(pyc_path,flag):
    fp=open(pyc_path, 'rb').read()
    code=marshal.loads(fp[16:])#python3的头部是16字节,python2的头部是8字节
    if(flag=='0'):
        dis.dis(code)
    else:
        print("len 0x%.8X" % (len(code.co_code)))
        print("0x%.8X" % (code.co_argcount))
        print("0x%.8X" % (code.co_nlocals))
        print("0x%.8X" % (code.co_stacksize))
        print("0x%.8X" % (code.co_flags))
        print(code.co_code)
        print(code.co_consts)
        print(code.co_names)
        print(code.co_varnames)
        print(code.co_cellvars)
        print(code.co_freevars)
        print(code.co_filename)
        print(code.co_name)
        print("0x%.8X" % (code.co_firstlineno))
        print(code.co_lnotab)
    # print(code.co_zombieframe)3086
    
    
    
#test.py
path=input()
flag=input()
if path=='pyc':
    path='./nop.pyc'
    comp_pyc(path,flag)
elif path=='py':
    path='./ctf.py'
    comp_py(path,flag)
else:
    print("no")
    '''
    71 03 87
    '''
```
以上去花脚本是在2022年安洵杯逆向的[flower.pyc](https://github.com/D0g3-Lab/i-SOON_CTF_2022/tree/main/re)题目上进行测试，有兴趣可以看看这道题目，花指令有点可（变）了（态）。

# 参考

[py字节码混淆](https://github.com/De3mond/de3mond.github.io/blob/88ced8897e4211222f92b7d5642372a7d926920f/library/%E5%85%A5%E4%BE%B5%E4%B8%8E%E7%A0%B4%E8%A7%A3/Reverse/Python%E5%AD%97%E8%8A%82%E7%A0%81.md)
[python逆向](https://www.cnblogs.com/blili/p/11799398.html)
[python逆向之pyc](https://www.cnblogs.com/lordtianqiyi/articles/15851675.html)
[通过字节码混淆来保护Python代码](https://blog.csdn.net/ir0nf1st/article/details/61650984)
[理解Python字节码](https://towardsdatascience.com/understanding-python-bytecode-e7edaae8734d)
