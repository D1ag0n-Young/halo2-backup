---
title: qiling框架初探-实验
id: e9243375-c2ec-4f45-bbcc-35a99010570a
date: 2024-01-18 10:54:12
auther: yrl
cover: 
excerpt: qiling初探 qiling 基于 python 开发，是一个开源的、可模拟多种架构和平台的二进制仿真(模拟) 框架，同时还提供跨架构的调试能力，多种层次的 hook 方法，该工具由 Unicorn 引擎驱动，具有模拟多平台(Windows，MacOS，Linux，Android，BSD，UEFI
permalink: /archives/qilingkuang-jia-chu-tan-shi-yan
categories:
 - qiling
tags: 
 - qiling-hook
---

# qiling初探

qiling 基于 python 开发，是一个开源的、可模拟多种架构和平台的二进制仿真(模拟) 框架，同时还提供跨架构的调试能力，多种层次的 hook 方法，该工具由 Unicorn 引擎驱动，具有模拟多平台(Windows，MacOS，Linux，Android，BSD，UEFI，DOS，MBR)；仿真多架构（8086、X86、X86_64、ARM、ARM64、MIPS、RISCV、PowerPC）；支持多种文件格式（PE，MachO，ELF，COM，MBR）；提供完全可配置的沙盒；支持跨架构和平台调试功能；
具有反向调试功能的内置调试器；允许动态修补运行中的程序代码，包括已加载的库等功能

unicorn：只是一个CPU模拟器，它主要针对的是模拟CPU指令
qiling：基于unicorn对cpu指令的模拟基础上，进行操作系统级别的封装，可实现操作系统级别的仿真模拟
qemu：qemu用户模式 跟 qiling类似，它可以跨架构模拟整个可执行文件的源码，但qemu只是一个模拟工具，不能提供框架级别的代码热修补等操作

[qiling官方文档](https://docs.qiling.io/en/latest/)

## 安装

安装：`pip install qiling`
安装最新版：`pip install --user https://github.com/qilingframework/qiling/archive/dev.zip`

克隆项目：
```bash
git clone https://github.com/qilingframework/qiling
cd qiling
git submodule update --init --recursive #下载各个架构文件系统
```

### linux下模拟执行windows文件

在 linux 上使用 qiling 运行 exe 时，需要模拟 windows系统环境(window的dll 和 注册表等组件)才能运行。
qiling 提供了一个脚本`qiling/examples/scripts/dllscollector.bat`，在 windows 上执行，就能得到全部所需要的依赖了，然后将examples/rootfs/对应文件放到qiling对应rootfs下即可，模板如下：
```python
from qiling import *
 
# sandbox to emulate the EXE
def my_sandbox(path, rootfs):
    # setup Qiling engine
    ql = Qiling(path, rootfs)
    # now emulate the EXE
    ql.run()
 
if __name__ == "__main__":
    # execute Windows EXE under our rootfs
    # 参数：可执行文件位置， 模拟的windows64所在位置
    my_sandbox(["x8664_hello.exe"], "examples/rootfs/x8664_windows")
```
### windows下模拟执行linux文件
同linux下的模板，将my_sandbox的路径修改linux下的环境即可，特殊环境需要替换rootfs下对应的依赖库

## 使用方法

### 基本使用：demo
模拟运行windows下一段shellcode
```python
from qiling import Qiling
from qiling.const import QL_VERBOSE,QL_ARCH,QL_OS
 
# 提前写好要执行的shellcode，fromhex是将十六进制数变成\x的形式
shellcode = bytes.fromhex('''
fc4881e4f0ffffffe8d0000000415141505251564831d265488b52603e488b52183e488b52203e488b72503e480fb74a4a4d31c94831c0ac3c617c022c2041c1c90d4101c1e2ed5241513e488b52203e8b423c4801d03e8b80880000004885c0746f4801d0503e8b48183e448b40204901d0e35c48ffc93e418b34884801d64d31c94831c0ac41c1c90d4101c138e075f13e4c034c24084539d175d6583e448b40244901d0663e418b0c483e448b401c4901d03e418b04884801d0415841585e595a41584159415a4883ec204152ffe05841595a3e488b12e949ffffff5d49c7c1000000003e488d95fe0000003e4c8d850f0100004831c941ba45835607ffd54831c941baf0b5a256ffd548656c6c6f2c2066726f6d204d534621004d657373616765426f7800
''')
 
# 执行的code，设置架构和系统，其实就是实例化程序
ql = Qiling(
    code=shellcode,
    rootfs=r'examples/rootfs/x8664_windows',
    archtype=QL_ARCH.X8664, ostype=QL_OS.WINDOWS,
    verbose=QL_VERBOSE.DEBUG
)
 
# 运行
ql.run()
```
Qiling 初始化 constructor 可以采用多个参数：

1. filename：二进制文件及其参数，例如：filename = ["test", "-argv1", "argv2"]
2. rootfs：虚拟根(/) 文件夹，这是执行 Qiling（目标体系结构）时的 jail 文件系统
3. env：环境变量，例如：env = {"SHELL": "/bin/bash", "HOME": "/tmp"}
4. output：“默认”，“调试”，“ disasm”，“ dump”，其中dump =（disam + debug）

该 run() 函数还可以采用多个参数：

1. begin：仿真代码的起始地址
2. end：仿真代码的结束地址
3. timeout：仿真超时（以微秒为单位）
4. count：要模拟的最大指令数

### qiling使用方法（栈、寄存器、内存、hook）

1. 操作栈
```python
ql.stack_push()                 # 模拟程序中进行压栈操作
ql.stack_read(offset)           # 从栈中读出数据
ql.stack_write(offset,data)     # 向栈中写入数据
```
2. 操作寄存器
```python
# 旧使用方式，从 eax 中读： demo = ql.reg.eax
demo = ql.arch.regs.read("eax")
print(demo)  # 输出寄存器的信息
```
3. 操作内存
```python
ql.mem.read(address, size)     # 从 address 中读出 size 字节的数据
ql.mem.write(address, data)    # 向 address 里写入 data
```
4. hook
对地址的hook：
```python
from qiling import Qiling

def stop(ql: Qiling) -> None:
    ql.log.info('killer switch found, stopping')
    # 当程序执行到 0x40819a 处时执行 stop 函数
    ql.emu_stop()
 
ql = Qiling(
    [r'examples/rootfs/x86_windows/bin/wannacry.bin'],
    r'examples/rootfs/x86_windows'
)
ql.hook_address(stop, 0x40819a)
ql.run()
```
对代码的hook：
```python
from capstone import Cs
from qiling import Qiling
from qiling.const import QL_VERBOSE
 
 
def simple_disassembly(ql: Qiling, address: int, size: int, md: Cs) -> None:
    # 读取内存中指定地址、指定长度 的 十六进制的code
    buf = ql.mem.read(address, size)
 
    # 将十六进制数转变成汇编代码，并且输出
    for insn in md.disasm(buf, address):
        ql.log.debug(f':: {insn.address:#x} : {insn.mnemonic:24s} {insn.op_str}')
 
 
if __name__ == "__main__":
    ql = Qiling(
        [r'examples/rootfs/x8664_linux/bin/x8664_hello'],
        r'examples/rootfs/x8664_linux',
        verbose=QL_VERBOSE.DEBUG
    )
    # 代码 hook
    ql.hook_code(simple_disassembly, user_data=ql.arch.disassembler)
    ql.run()
```
ql.hook_code 是对 read 的十六进制数进行 hook，通俗来说就是执行每条汇编语句之前都会先执行simple_diassembler

一些常量开关含义：
1. 日志相关

| 级别 | 作用 |
| --- | --- |
| QL_VERBOSE.DISABLED | 日志记录完全禁用 |
| QL_VERBOSE.OFF | 日志记录仅输出警告、错误等信息 |
| QL_VERBOSE.DEFAULT | 默认模式，输出一定的信息 |
| QL_VERBOSE.DEBUG | 调试模式，输出详细程度增加 |
| QL_VERBOSE.DISASM | 汇编模式，输出每条模拟指令的汇编代码 |
| QL_VERBOSE.DUMP | DUMP模式，输出每一条汇编指令及其寄存器信息 |

2. hook相关

| 类型 | 作用 |
| --- | --- |
| QL_INTERCEPT.CALL | 执行API被替换成执行hook函数 |
| QL_INTERCEPT.ENTER | 目标API被调用前，执行hook函数 |
| QL_INTERCEPT.EXIT | 目标API被调用后，执行hook函数 |


## Qiling Framework 入门，11个挑战快速上手

[Shielder - QilingLab – Release](https://www.shielder.com/blog/2021/07/qilinglab-release/)是一个用来练习熟悉qiling框架使用的小练习，是一个包含11个小挑战的程序，用于快速上手Qiling 框架的主要功能。

aarch64版本已有Joan Sivion做的[Qiling Labs - JoanSivion Security Blog](https://joansivion.github.io/qilinglabs/)，这里本文用x86-64做一遍，熟悉qiling框架的用法

### 题目列表

```bash
Welcome to QilingLab.
Here is the list of challenges:
Challenge 1: Store 1337 at pointer 0x1337.
Challenge 2: Make the 'uname' syscall return the correct values.
Challenge 3: Make '/dev/urandom' and 'getrandom' "collide".
Challenge 4: Enter inside the "forbidden" loop.
Challenge 5: Guess every call to rand().
Challenge 6: Avoid the infinite loop.
Challenge 7: Don't waste time waiting for 'sleep'.
Challenge 8: Unpack the struct and write at the target address.
Challenge 9: Fix some string operation to make the iMpOsSiBlE come true.
Challenge 10: Fake the 'cmdline' line file to return the right content.
Challenge 11: Bypass CPUID/MIDR_EL1 checks.

Checking which challenge are solved...
Note: Some challenges will results in segfaults and infinite loops if they aren't solved.
```
我们的目的就是让传入的指针指向的位置能被正确赋值1，直接运行的话，并不会输出每个Challenge的结果（SOLVED/UNSOLVED），甚至还会出现segment fault，这些都是正常现象，请放心食用，当你完成某些挑战后，自然就能看到更多的结果了

**基本模板**

```python
from qiling import *
 
def challenge1(ql: Qiling):
    pass
 
if __name__  == '__main__':
    path = ['qilinglab-x86_64'] # 我们的目标
    rootfs = "./qiling/examples/rootfs/x8664_linux" # 在你clone下来的仓库里
    ql = Qiling(path, rootfs,verbose=QL_VERBOSE.OFF)
    challenge1(ql) # 在ql.run()之前，做好我们的hook工作
    ql.run()
```

### challenge1: 操作内存

```c
_BYTE *__fastcall challenge1(_BYTE *a1)
{
  _BYTE *result; // rax

  result = (_BYTE *)*(unsigned int *)((char *)&loc_1335 + 2);
  if ( *(_DWORD *)((char *)&loc_1335 + 2) == 1337 )
  {
    result = a1;
    *a1 = 1;
  }
  return result;
}
```
目标是在`*(_DWORD *)((char *)&loc_1335 + 2) == 1337`也就是在0x1337内存处写入1337，我们其实并不能保证程序加载基地址，这里我们需要用：`ql.mem.map(0x1000, 0x1000, info='[challenge]')`映射一块内存，需要注意的是，qiling底层就是用的Unicorn Engine，内存映射时，要4k对齐。

脚本：

```python
# 修改内存 store 0x1337 to addr 0x1337
def challenge1(ql: Qiling):
    ql.mem.map(0x1000, 0x1000, info='[challenge1]')
    ql.mem.write(0x1337, ql.pack32(1337)) # pack16(value) == struct.pack('H', value)
```
脚本verbose=QL_VERBOSE.OFF关闭调试信息，方便看输出内容

### challenge2: 修改系统调用

```c
unsigned __int64 __fastcall challenge2(_BYTE *a1)
{
  unsigned int v2; // [rsp+10h] [rbp-1D0h]
  int v3; // [rsp+14h] [rbp-1CCh]
  int v4; // [rsp+18h] [rbp-1C8h]
  int v5; // [rsp+1Ch] [rbp-1C4h]
  struct utsname name; // [rsp+20h] [rbp-1C0h] BYREF
  char s[10]; // [rsp+1A6h] [rbp-3Ah] BYREF
  char v8[24]; // [rsp+1B0h] [rbp-30h] BYREF
  unsigned __int64 v9; // [rsp+1C8h] [rbp-18h]

  v9 = __readfsqword(0x28u);
  if ( uname(&name) )
  {
    perror("uname");
  }
  else
  {
    strcpy(s, "QilingOS");
    s[9] = 0;
    strcpy(v8, "ChallengeStart");
    v8[15] = 0;
    v2 = 0;
    v3 = 0;
    while ( v4 < strlen(s) )
    {
      if ( name.sysname[v4] == s[v4] )
        ++v2;
      ++v4;
    }
    while ( v5 < strlen(v8) )
    {
      if ( name.version[v5] == v8[v5] )
        ++v3;
      ++v5;
    }
    if ( v2 == strlen(s) && v3 == strlen(v8) && v2 > 5 )
      *a1 = 1;
  }
  return __readfsqword(0x28u) ^ v9;
}
```
uname系统调用用来获取系统的一些信息，传入一个utsname结构体buffer让它填充。可以在<sys/utsname.h>看到utsname的定义（经过整理）：

```c
struct utsname
{
    char sysname[65];
    char nodename[65];
    char release[65];
    char version[65];
    char machine[65];
    char domainname[65];
};
```
qiling框架可以在系统调用返回的时候进行hook，我们的目标就是修改utsname中sysname和version成员分别为QilingOS和ChallengeStart即可

脚本：
```python
# hook uname return 
# sysname == QilingOS 
# version == ChallengeStart
'''
struct utsname {
    char sysname[65];
    char nodename[65];
    char release[65];   
    char version[65];
    char machine[65];
    char domainname[65];
};
'''
# 修改系统调用
def challenge2(ql: Qiling):
    def hook_uname_on_exit(ql: Qiling, *args):
        rdi = ql.arch.regs.rdi
        ql.mem.write(rdi, b'QilingOS\x00')
        ql.mem.write(rdi + 65 * 3, b'ChallengeStart\x00')

    ql.os.set_syscall('uname', hook_uname_on_exit, QL_INTERCEPT.EXIT)

```

### challenge3: 劫持文件系统&系统调用

```c
unsigned __int64 __fastcall challenge3(_BYTE *a1)
{
  int v2; // [rsp+10h] [rbp-60h]
  int i; // [rsp+14h] [rbp-5Ch]
  int fd; // [rsp+18h] [rbp-58h]
  char v5; // [rsp+1Fh] [rbp-51h] BYREF
  char buf[32]; // [rsp+20h] [rbp-50h] BYREF
  char v7[40]; // [rsp+40h] [rbp-30h] BYREF
  unsigned __int64 v8; // [rsp+68h] [rbp-8h]

  v8 = __readfsqword(0x28u);
  fd = open("/dev/urandom", 0);
  read(fd, buf, 0x20uLL);
  read(fd, &v5, 1uLL);
  close(fd);
  getrandom(v7, 32LL, 1LL);
  v2 = 0;
  for ( i = 0; i <= 31; ++i )
  {
    if ( buf[i] == v7[i] && buf[i] != v5 )
      ++v2;
  }
  if ( v2 == 32 )
    *a1 = 1;
  return __readfsqword(0x28u) ^ v8;
}
```
需要满足`/dev/urandom`获得的随机数和`getrandom`的随机数相等，且不能包含v5这个特定的值

Qiling提供了QlFsMappedObject让我们能很方便地自定义文件系统，最少要实现close，剩下的可以看源码，根据需要自行去实现：read, write, fileno, lseek, fstat, ioctl, tell, dup, readline

思路：hook设备`/dev/urandom`当readlen=1时返回\x23，不为1时返回0，同时hook getrandom函数让其返回0，即可满足条件

脚本：
```python
# hook /dev/urandom read single 32-byte data to be different from otheres
# hook /dev/urandom read 32 1-byte data to be the same with getrandom
# hook getrandom syscall
class Fake_urandom(QlFsMappedObject):
    def read(self, expected_len):
        if expected_len == 1:
            return b'\x23'  # casual single byte here
        else:
            return b'\x00' * expected_len
 
    def close(self):
        return 0

# 劫持文件系统&系统调用
def challenge3(ql: Qiling):
    def hook_getrandom(ql: Qiling, buf, buflen, flags, *args):
        ql.mem.write(buf, b'\x00' * buflen)
        ql.os.set_syscall_return(0)
    ql.add_fs_mapper('/dev/urandom', Fake_urandom())
    ql.os.set_syscall('getrandom', hook_getrandom)

```

### challenge4: hook地址
ida反编译为null，看汇编发现
```
text:0000000000000E1D ; __int64 challenge4()
.text:0000000000000E1D                 public challenge4
.text:0000000000000E1D challenge4      proc near               ; CODE XREF: start+18F↓p
.text:0000000000000E1D
.text:0000000000000E1D var_18          = qword ptr -18h
.text:0000000000000E1D var_8           = dword ptr -8
.text:0000000000000E1D var_4           = dword ptr -4
.text:0000000000000E1D
.text:0000000000000E1D ; __unwind {
.text:0000000000000E1D                 push    rbp
.text:0000000000000E1E                 mov     rbp, rsp
.text:0000000000000E21                 mov     [rbp+var_18], rdi
.text:0000000000000E25                 mov     [rbp+var_8], 0
.text:0000000000000E2C                 mov     [rbp+var_4], 0
.text:0000000000000E33                 jmp     short loc_E40
.text:0000000000000E35 ; ---------------------------------------------------------------------------
.text:0000000000000E35
.text:0000000000000E35 loc_E35:                                ; CODE XREF: challenge4+29↓j
.text:0000000000000E35                 mov     rax, [rbp+var_18]
.text:0000000000000E39                 mov     byte ptr [rax], 1
.text:0000000000000E3C                 add     [rbp+var_4], 1
.text:0000000000000E40
.text:0000000000000E40 loc_E40:                                ; CODE XREF: challenge4+16↑j
.text:0000000000000E40                 mov     eax, [rbp+var_8]
.text:0000000000000E43                 cmp     [rbp+var_4], eax
.text:0000000000000E46                 jl      short loc_E35
.text:0000000000000E48                 nop
.text:0000000000000E49                 pop     rbp
.text:0000000000000E4A                 retn
.text:0000000000000E4A ; } // starts at E1D
```

伪代码为：
```c
__int64 challenge4(_BYTE *a1)
{
    int i = 0;
    while (i < 0) {
        *a1 = 1;
        i++;
    }
    return;
}
```
可以看到这个循环不成立，正常执行不会进入，所以在比较前将终止条件改为1，这样可以执行一次，让函数参数赋值为1

脚本:

`hook_address`里注册的回调在执行被hook地址处之前执行，然后才执行这个地址上的指令。所以我们hook在cmp这句。这样while里就是比较 i < 1了
```python
# hook地址
def challenge4(ql: Qiling):
    """
    000055A3E4800E40 8B 45 F8   mov     eax, [rbp+var_8]
    000055A3E4800E43 39 45 FC   cmp     [rbp+var_4], eax        <<< hook here
    000055A3E4800E46 7C ED      jl      short loc_55A3E4800E35
    """
    def enter_forbidden_loop_hook(ql: Qiling):
        ql.arch.regs.eax = 1
    base = ql.mem.get_lib_base(os.path.basename(ql.path))
    hook_addr = base + 0xE43
    ql.hook_address(enter_forbidden_loop_hook, hook_addr)

```

### challenge5: hook外部函数

```c
unsigned __int64 __fastcall challenge5(_BYTE *a1)
{
  unsigned int v1; // eax
  int i; // [rsp+18h] [rbp-48h]
  int j; // [rsp+1Ch] [rbp-44h]
  int v5[14]; // [rsp+20h] [rbp-40h]
  unsigned __int64 v6; // [rsp+58h] [rbp-8h]

  v6 = __readfsqword(0x28u);
  v1 = time(0LL);
  srand(v1);
  for ( i = 0; i <= 4; ++i )
  {
    v5[i] = 0;
    v5[i + 8] = rand();
  }
  for ( j = 0; j <= 4; ++j )
  {
    if ( v5[j] != v5[j + 8] )
    {
      *a1 = 0;
      return __readfsqword(0x28u) ^ v6;
    }
  }
  *a1 = 1;
  return __readfsqword(0x28u) ^ v6;
}
```

显然，只要让rand()每次都返回0是最简单的修改方法了。所以代码比较简单

脚本：
```python
# hook外部函数
def challenge5(ql: Qiling):
    def hook_rand(ql: Qiling):
        ql.arch.regs.rax = 0
    ql.os.set_api('rand', hook_rand)
```
看不到输出challenge5: SOLVED是正常的，因为卡在了challenge6，没有输出来信息

### challenge6: 突破死循环

```c
void challenge6()
{
  while ( 1 )
    ;
}
```

```
.text:0000000000000EF6 ; void challenge6()
.text:0000000000000EF6                 public challenge6
.text:0000000000000EF6 challenge6      proc near               ; CODE XREF: start+1D7↓p
.text:0000000000000EF6
.text:0000000000000EF6 var_18          = qword ptr -18h
.text:0000000000000EF6 var_5           = byte ptr -5
.text:0000000000000EF6 var_4           = dword ptr -4
.text:0000000000000EF6
.text:0000000000000EF6 ; __unwind {
.text:0000000000000EF6                 push    rbp
.text:0000000000000EF7                 mov     rbp, rsp
.text:0000000000000EFA                 mov     [rbp+var_18], rdi
.text:0000000000000EFE                 mov     [rbp+var_4], 0
.text:0000000000000F05                 mov     [rbp+var_5], 1
.text:0000000000000F09                 jmp     short loc_F12
.text:0000000000000F0B ; ---------------------------------------------------------------------------
.text:0000000000000F0B
.text:0000000000000F0B loc_F0B:                                ; CODE XREF: challenge6+22↓j
.text:0000000000000F0B                 mov     [rbp+var_4], 1  <<-- 赋值为1
.text:0000000000000F12
.text:0000000000000F12 loc_F12:                                ; CODE XREF: challenge6+13↑j
.text:0000000000000F12                 movzx   eax, [rbp+var_5]
.text:0000000000000F16                 test    al, al  <<-- hook addr
.text:0000000000000F18                 jnz     short loc_F0B
.text:0000000000000F1A                 mov     rax, [rbp+var_18]
.text:0000000000000F1E                 mov     byte ptr [rax], 1
.text:0000000000000F21                 nop
.text:0000000000000F22                 pop     rbp
.text:0000000000000F23                 retn
.text:0000000000000F23 ; } // starts at EF6
```
只要我们修改hook死循环.text:0000000000000F16部分，参数就会到loc_F0B处乖乖被赋值1，然后退出

脚本：
```python
# 突破死循环
def challenge6(ql: Qiling):
    def hook_while_true(ql: Qiling):
        """
        0000564846E00F12 0F B6 45 FB    movzx   eax, [rbp+var_5]
        0000564846E00F16 84 C0          test    al, al          <<< hook here
        0000564846E00F18 75 F1          jnz     short loc_564846E00F0B
        """
        ql.arch.regs.rax = 0
    base = ql.mem.get_lib_base(os.path.basename(ql.path))
    ql.hook_address(hook_while_true, base + 0xF16)
```

### challenge7：修改sleep()

```c
unsigned int __fastcall challenge7(_BYTE *a1)
{
  *a1 = 1;
  return sleep(0xFFFFFFFF);
}
```

可以很轻易想到多种办法：

- 修改sleep参数值，减少睡眠时间
- 自己实现sleep()，直接返回
- 修改系统调用nanosleep()，直接返回，因为sleep()底层调用的nanosleep()

可以看一下nanosleep()定义：

```c
       #include <time.h>
       int nanosleep(const struct timespec *req, struct timespec *rem);
```

脚本：
```python
# hook sleep
def challenge7(ql: Qiling):
    def modify_arg(ql: Qiling):
        ql.arch.regs.edi = 0

    def i_slept_i_faked_it(ql: Qiling):
        # 我睡了，我装的
        return

    def hook_nanosleep(ql: Qiling, *args, **kwargs):
        # 注意参数列表
        return
    # method 1
    # ql.os.set_api('sleep', modify_arg, QL_INTERCEPT.ENTER)
    # method 2
    # ql.os.set_api('sleep', i_slept_i_faked_it)
    # method 3
    ql.os.set_syscall('nanosleep', hook_nanosleep)
```
### challenge8: 解析结构体，往正确地址写入值

```c
_DWORD *__fastcall challenge8(__int64 a1)
{
  _DWORD *result; // rax
  _DWORD *v2; // [rsp+18h] [rbp-8h]

  v2 = malloc(0x18uLL);
  *(_QWORD *)v2 = malloc(0x1EuLL);
  v2[2] = 1337;
  v2[3] = 1039980266;
  strcpy(*(char **)v2, "Random data");
  result = v2;
  *((_QWORD *)v2 + 2) = a1;
  return result;
}
```
经过分析，可以得到结构体大致如下：
```c
struct random_struct {
  char *some_string;
  __int64 magic;
  char *check_addr;
};
```
恢复符号后
```c
struct_v2 *__fastcall challenge8(char *a1)
{
  struct_v2 *result; // rax
  random_struct *v2; // [rsp+18h] [rbp-8h]

  v2 = (random_struct *)malloc(0x18uLL);
  v2->some_string = (char *)malloc(0x1EuLL);
  LODWORD(v2->magic) = 0x539;
  HIDWORD(v2->magic) = 0x3DFCD6EA;
  strcpy(v2->some_string, "Random data");
  result = (struct_v2 *)v2;
  v2->check_addr = a1;
  return result;
}
```
方法有两种：

1. 最后一句的时候，获取这个结构体地址，可以看一下最后部分的汇编：
```
.text:0000000000000FA9                 mov     rax, [rbp+var_8] <--- struct addr == rbp - 8
.text:0000000000000FAD                 mov     rdx, [rbp+var_18]
.text:0000000000000FB1                 mov     [rax+10h], rdx
.text:0000000000000FB5                 nop
.text:0000000000000FB6                 leave
.text:0000000000000FB7                 retn
.text:0000000000000FB7 ; } // starts at F44
```
然后结构体偏移+0x16的地方就是保存了参数的位置，直接找到对应结构体条目，写内存

2. 使用qiling提供的机制，用`ql.mem.search()`搜索内存。看一下代码可以发现，这个结构体保存了一个魔数`0x3DFCD6EA00000539`，这正好是个特征方便我们去搜索这块内存。当然，还在第一个字段保存了一个指针指向一个固定的字符串，如果那个魔数在内存中出现多次，那显然我们还需要进一步获取信息确定是不是我们要找的那个结构体：保存了参数check的结构体。

脚本：
```python
# 解析结构体，往正确地址写入值
def challenge8(ql: Qiling):
    def hook_struct(ql: Qiling):
        """
        0000564846E00FA9 48 8B 45 F8      mov     rax, [rbp+str]    ; rbp - 8
        0000564846E00FAD 48 8B 55 E8      mov     rdx, [rbp+var_18]
        0000564846E00FB1 48 89 50 10      mov     [rax+10h], rdx
        0000564846E00FB5 90               nop       <<< hook here
        0000564846E00FB6 C9               leave
        0000564846E00FB7 C3               retn
        """
        heap_struct_addr = ql.unpack64(ql.mem.read(ql.arch.regs.rbp - 8, 8))
        heap_struct = ql.mem.read(heap_struct_addr, 24)
        print(heap_struct)
        _, _, check_addr = struct.unpack('QQQ', heap_struct)
        # other simple method
        # check_addr = ql.arch.regs.rax + 0x10
        ql.mem.write(check_addr, b'\x01')

    def search_mem_to_find_struct(ql: Qiling):
        MAGIC = ql.pack64(0x3DFCD6EA00000539)
        candidate_addrs = ql.mem.search(MAGIC)

        for addr in candidate_addrs:
            # 有可能有多个地址，所以通过其他特征进一步确认
            stru_addr = addr - 8
            stru = ql.mem.read(stru_addr, 24)
            string_addr, _, check_addr = struct.unpack('QQQ', stru)
            if ql.mem.string(string_addr) == 'Random data':
                ql.mem.write(check_addr, b'\x01')
                break
    base = ql.mem.get_lib_base(os.path.basename(ql.path))
    # method 1
    # ql.hook_address(hook_struct, base + 0xFB5)
    # method 2
    ql.hook_address(search_mem_to_find_struct, base + 0xFB5)
```

### challenge9: 修改字符串函数

```c
unsigned __int64 __fastcall challenge9(bool *a1)
{
  char *i; // [rsp+18h] [rbp-58h]
  char dest[32]; // [rsp+20h] [rbp-50h] BYREF
  char src[40]; // [rsp+40h] [rbp-30h] BYREF
  unsigned __int64 v5; // [rsp+68h] [rbp-8h]

  v5 = __readfsqword(0x28u);
  strcpy(src, "aBcdeFghiJKlMnopqRstuVWxYz");
  src[27] = 0;
  strcpy(dest, src);
  for ( i = dest; *i; ++i )
    *i = tolower(*i);
  *a1 = strcmp(src, dest) == 0;
  return __readfsqword(0x28u) ^ v5;
}
```
让tolower()失效或让strcmp()失效，由于strcmp()失效会影响其他challenge代码流程，这里就让tolower()失效

脚本：
```python
# 修改字符串函数
def challenge9(ql: Qiling):
    def fake_strcmp(ql: Qiling):
        rax = ql.arch.regs.rax
        ql.arch.regs.eax = 0 # 0:等于; -1:小于 ;1:大于

    def fake_tolower(ql: Qiling):
        return
    # method 1
    ql.os.set_api('tolower', fake_tolower)
    # method 2 challenge10 also sovled
    # ql.os.set_api('strcmp', fake_strcmp)
```

### challenge10: 劫持文件系统，返回指定命令行

```c
unsigned __int64 __fastcall challenge10(_BYTE *a1)
{
  int i; // [rsp+10h] [rbp-60h]
  int fd; // [rsp+14h] [rbp-5Ch]
  ssize_t v4; // [rsp+18h] [rbp-58h]
  char buf[72]; // [rsp+20h] [rbp-50h] BYREF
  unsigned __int64 v6; // [rsp+68h] [rbp-8h]

  v6 = __readfsqword(0x28u);
  fd = open("/proc/self/cmdline", 0);
  if ( fd != -1 )
  {
    v4 = read(fd, buf, 0x3FuLL);
    if ( v4 > 0 )
    {
      close(fd);
      for ( i = 0; v4 > i; ++i )
      {
        if ( !buf[i] )
          buf[i] = 32;
      }
      buf[v4] = 0;
      if ( !strcmp(buf, "qilinglab") )
        *a1 = 1;
    }
  }
  return __readfsqword(0x28u) ^ v6;
}
```
让我们能从`/proc/self/cmdline`读到"qilinglab"，故技重施即可，hook文件系统

脚本：
```python
class Fake_cmdline(QlFsMappedObject):
    def read(self, expected_len):
        return b'qilinglab'  # casual single byte here
 
    def close(self):
        return 0

# 劫持文件系统，返回指定命令行
def challenge10(ql: Qiling):
    # method 1
    ql.add_fs_mapper('/proc/self/cmdline', Fake_cmdline())
    # method 2
    # ql.add_fs_mapper("/proc/self/cmdline", "./fake_cmdline")

```
其中method 1为简便方法，可以直接替换指定文件成我们的文件，先创建我们需要的文件：
`echo -n "qilinglab" > fake_cmdline`

### challenge11: 指令hook

```c
unsigned __int64 __fastcall challenge11(_BYTE *a1)
{
  int v7; // [rsp+1Ch] [rbp-34h]
  int v8; // [rsp+24h] [rbp-2Ch]
  char s[4]; // [rsp+2Bh] [rbp-25h] BYREF
  char v10[4]; // [rsp+2Fh] [rbp-21h] BYREF
  char v11[4]; // [rsp+33h] [rbp-1Dh] BYREF
  unsigned __int64 v12; // [rsp+38h] [rbp-18h]

  v12 = __readfsqword(0x28u);
  _RAX = 0x40000000LL;
  __asm { cpuid }
  v7 = _RCX;
  v8 = _RDX;
  if ( __PAIR64__(_RBX, _RCX) == 0x696C6951614C676ELL && (_DWORD)_RDX == 538976354 )
    *a1 = 1;
    ...
}
```
看汇编：
```
.text:000000000000118F 0F A2                                   cpuid
.text:0000000000001191 89 D0                                   mov     eax, edx
.text:0000000000001193 89 DE                                   mov     esi, ebx
.text:0000000000001195 89 75 D0                                mov     [rbp+var_30], esi
.text:0000000000001198 89 4D CC                                mov     [rbp+var_34], ecx
.text:000000000000119B 89 45 D4                                mov     [rbp+var_2C], eax
.text:000000000000119E 81 7D D0 51 69 6C 69                    cmp     [rbp+var_30], 696C6951h
.text:00000000000011A5 75 19                                   jnz     short loc_11C0
.text:00000000000011A7 81 7D CC 6E 67 4C 61                    cmp     [rbp+var_34], 614C676Eh
.text:00000000000011AE 75 10                                   jnz     short loc_11C0
.text:00000000000011B0 81 7D D4 62 20 20 20                    cmp     [rbp+var_2C], 20202062h
.text:00000000000011B7 75 07                                   jnz     short loc_11C0
.text:00000000000011B9 48 8B 45 B8                             mov     rax, [rbp+var_48]
.text:00000000000011BD C6 00 01                                mov     byte ptr [rax], 1
```
目标就很明确了。cpuid指令使用 eax 作为输入参数,eax,ebx,ecx,edx作为输出参数，具体可以参考intel手册。

脚本:
```python
# 指令hook
def challenge11(ql: Qiling):
    def hook_cpuid(ql: Qiling, address, size):
        """
        0000564846E0118F 0F A2      cpuid
        """
        if ql.mem.read(address, size) == b'\x0F\xA2':
            ql.arch.regs.ebx = 0x696C6951
            ql.arch.regs.ecx = 0x614C676E
            ql.arch.regs.edx = 0x20202062
            # print(hex(ql.arch.regs.ebx)+'-'+hex(ql.arch.regs.ebx)+'-'+hex(ql.arch.regs.ebx))
            ql.arch.regs.rip += 2
    begin, end = 0, 0
    for info in ql.mem.map_info:
        if info[2] == 5 and info[3] == 'qilinglab-x86_64':
            begin, end = info[:2]

    ql.hook_code(hook_cpuid, begin=begin, end=end)
```
`ql.mem.map_info`也就是`ql.mem.show_mapinfo()`的内容，5表示的是r-x属性，加这个判断也是为了缩小hook的范围，提高性能

### 整体代码

```python
from qiling import *
from qiling.const import QL_INTERCEPT,QL_VERBOSE
from qiling.os.mapper import QlFsMappedObject
import os
import struct

# 修改内存 store 0x1337 to addr 0x1337
def challenge1(ql: Qiling):
    ql.mem.map(0x1000, 0x1000, info='[challenge1]')
    ql.mem.write(0x1337, ql.pack32(1337)) # pack16(value) == struct.pack('H', value)

# hook uname return 
# sysname == QilingOS 
# version == ChallengeStart
'''
struct utsname {
    char sysname[65];
    char nodename[65];
    char release[65];   
    char version[65];
    char machine[65];
    char domainname[65];
};
'''
# 修改系统调用
def challenge2(ql: Qiling):
    def hook_uname_on_exit(ql: Qiling, *args):
        rdi = ql.arch.regs.rdi
        ql.mem.write(rdi, b'QilingOS\x00')
        ql.mem.write(rdi + 65 * 3, b'ChallengeStart\x00')

    ql.os.set_syscall('uname', hook_uname_on_exit, QL_INTERCEPT.EXIT)

# hook /dev/urandom read single 32-byte data to be different from otheres
# hook /dev/urandom read 32 1-byte data to be the same with getrandom
# hook getrandom syscall
class Fake_urandom(QlFsMappedObject):
    def read(self, expected_len):
        if expected_len == 1:
            return b'\x23'  # casual single byte here
        else:
            return b'\x00' * expected_len
 
    def close(self):
        return 0

# 劫持文件系统&系统调用
def challenge3(ql: Qiling):
    def hook_getrandom(ql: Qiling, buf, buflen, flags, *args):
        ql.mem.write(buf, b'\x00' * buflen)
        ql.os.set_syscall_return(0)
    ql.add_fs_mapper('/dev/urandom', Fake_urandom())
    ql.os.set_syscall('getrandom', hook_getrandom)

# hook地址
def challenge4(ql: Qiling):
    """
    000055A3E4800E40 8B 45 F8   mov     eax, [rbp+var_8]
    000055A3E4800E43 39 45 FC   cmp     [rbp+var_4], eax        <<< hook here
    000055A3E4800E46 7C ED      jl      short loc_55A3E4800E35
    """
    def enter_forbidden_loop_hook(ql: Qiling):
        ql.arch.regs.eax = 1
    base = ql.mem.get_lib_base(os.path.basename(ql.path))
    # print(base)
    hook_addr = base + 0xE43
    ql.hook_address(enter_forbidden_loop_hook, hook_addr)

# hook外部函数
def challenge5(ql: Qiling):
    def hook_rand(ql: Qiling):
        ql.arch.regs.rax = 0
    ql.os.set_api('rand', hook_rand)

# 突破死循环
def challenge6(ql: Qiling):
    def hook_while_true(ql: Qiling):
        """
        0000564846E00F12 0F B6 45 FB    movzx   eax, [rbp+var_5]
        0000564846E00F16 84 C0          test    al, al          <<< hook here
        0000564846E00F18 75 F1          jnz     short loc_564846E00F0B
        """
        ql.arch.regs.rax = 0
    base = ql.mem.get_lib_base(os.path.basename(ql.path))
    ql.hook_address(hook_while_true, base + 0xF16)

# hook sleep
def challenge7(ql: Qiling):
    def modify_arg(ql: Qiling):
        ql.arch.regs.edi = 0

    def i_slept_i_faked_it(ql: Qiling):
        # 我睡了，我装的
        return

    def hook_nanosleep(ql: Qiling, *args, **kwargs):
        # 注意参数列表
        return
    # method 1
    # ql.os.set_api('sleep', modify_arg, QL_INTERCEPT.ENTER)
    # method 2
    # ql.os.set_api('sleep', i_slept_i_faked_it)
    # method 3
    ql.os.set_syscall('nanosleep', hook_nanosleep)

# 解析结构体，往正确地址写入值
def challenge8(ql: Qiling):
    def hook_struct(ql: Qiling):
        """
        0000564846E00FA9 48 8B 45 F8      mov     rax, [rbp+str]    ; rbp - 8
        0000564846E00FAD 48 8B 55 E8      mov     rdx, [rbp+var_18]
        0000564846E00FB1 48 89 50 10      mov     [rax+10h], rdx
        0000564846E00FB5 90               nop       <<< hook here
        0000564846E00FB6 C9               leave
        0000564846E00FB7 C3               retn
        """
        heap_struct_addr = ql.unpack64(ql.mem.read(ql.arch.regs.rbp - 8, 8))
        heap_struct = ql.mem.read(heap_struct_addr, 24)
        print(heap_struct)
        _, _, check_addr = struct.unpack('QQQ', heap_struct)
        # check_addr = ql.arch.regs.rax + 0x10
        ql.mem.write(check_addr, b'\x01')

    def search_mem_to_find_struct(ql: Qiling):
        MAGIC = ql.pack64(0x3DFCD6EA00000539)
        candidate_addrs = ql.mem.search(MAGIC)

        for addr in candidate_addrs:
            # 有可能有多个地址，所以通过其他特征进一步确认
            stru_addr = addr - 8
            stru = ql.mem.read(stru_addr, 24)
            string_addr, _, check_addr = struct.unpack('QQQ', stru)
            if ql.mem.string(string_addr) == 'Random data':
                ql.mem.write(check_addr, b'\x01')
                break
    base = ql.mem.get_lib_base(os.path.basename(ql.path))
    # method 1
    # ql.hook_address(hook_struct, base + 0xFB5)
    # method 2
    ql.hook_address(search_mem_to_find_struct, base + 0xFB5)


# 修改字符串函数
def challenge9(ql: Qiling):
    def fake_strcmp(ql: Qiling):
        rax = ql.arch.regs.rax
        ql.arch.regs.eax = 0 # 0:等于; -1:小于 ;1:大于

    def fake_tolower(ql: Qiling):
        return
    # method 1
    ql.os.set_api('tolower', fake_tolower)
    # method 2 challenge10 also sovled
    # ql.os.set_api('strcmp', fake_strcmp)

class Fake_cmdline(QlFsMappedObject):
    def read(self, expected_len):
        return b'qilinglab'  # casual single byte here
 
    def close(self):
        return 0

# 劫持文件系统，返回指定命令行
def challenge10(ql: Qiling):
    # method 1
    ql.add_fs_mapper('/proc/self/cmdline', Fake_cmdline())
    # method 2
    # ql.add_fs_mapper("/proc/self/cmdline", "./fake_cmdline")

# 指令hook
def challenge11(ql: Qiling):
    def hook_cpuid(ql: Qiling, address, size):
        """
        0000564846E0118F 0F A2      cpuid
        """
        if ql.mem.read(address, size) == b'\x0F\xA2':
            ql.arch.regs.ebx = 0x696C6951
            ql.arch.regs.ecx = 0x614C676E
            ql.arch.regs.edx = 0x20202062
            # print(hex(ql.arch.regs.ebx)+'-'+hex(ql.arch.regs.ebx)+'-'+hex(ql.arch.regs.ebx))
            ql.arch.regs.rip += 2
    begin, end = 0, 0
    for info in ql.mem.map_info:
        if info[2] == 5 and info[3] == 'qilinglab-x86_64':
            begin, end = info[:2]

    ql.hook_code(hook_cpuid, begin=begin, end=end)

if __name__  == '__main__':
    path = ['./examples/rootfs/x8664_linux/bins/qilinglab-x86_64'] # 我们的目标
    rootfs = "./examples/rootfs/x8664_linux" # 在你clone下来的仓库里
    ql = Qiling(path, rootfs,verbose=QL_VERBOSE.OFF)
    # ql.debugger = 'gdb:0.0.0.0:9999'
    # 在ql.run()之前，做好我们的hook工作
    challenge1(ql) 
    challenge2(ql) 
    challenge3(ql) 
    challenge4(ql) 
    # ql.debugger = True
    challenge5(ql) 
    challenge6(ql) 
    challenge7(ql) 
    challenge8(ql) 
    challenge9(ql) 
    challenge10(ql) 
    challenge11(ql) 
    ql.run()
```

```bash
➜  qiling git:(master) ✗ python3 qilingLab_test.py
Welcome to QilingLab.
Here is the list of challenges:
Challenge 1: Store 1337 at pointer 0x1337.
Challenge 2: Make the 'uname' syscall return the correct values.
Challenge 3: Make '/dev/urandom' and 'getrandom' "collide".
Challenge 4: Enter inside the "forbidden" loop.
Challenge 5: Guess every call to rand().
Challenge 6: Avoid the infinite loop.
Challenge 7: Don't waste time waiting for 'sleep'.
Challenge 8: Unpack the struct and write at the target address.
Challenge 9: Fix some string operation to make the iMpOsSiBlE come true.
Challenge 10: Fake the 'cmdline' line file to return the right content.
Challenge 11: Bypass CPUID/MIDR_EL1 checks.

Checking which challenge are solved...
Note: Some challenges will results in segfaults and infinite loops if they aren't solved.

Challenge 1: SOLVED
Challenge 2: SOLVED
Challenge 3: SOLVED
Challenge 4: SOLVED
Challenge 5: SOLVED
Challenge 6: SOLVED
Challenge 7: SOLVED
Challenge 8: SOLVED
Challenge 9: SOLVED
Challenge 10: SOLVED
Challenge 11: SOLVED
You solved 11/11 of the challenges
```

## 总结

通读全文，你能掌握qiling基础的动态修补、hook方法等方法

