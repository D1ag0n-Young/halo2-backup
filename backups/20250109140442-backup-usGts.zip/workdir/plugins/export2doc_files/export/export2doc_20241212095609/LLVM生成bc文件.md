---
title: LLVM生成bc文件
id: 111
date: 2024-01-09 20:09:11
auther: yrl
cover: 
excerpt: LLVM安装可源码安装和release安装llvm-releaserelease版下好就能用，解压完大概4G左右，如果想在bash全局生效，可加入环境变量。export LLVM_HOME=/home/xxxx/clang+llvm-14.0.0/binexport PATH=SLLVM HOME
permalink: /archives/llvm%E4%B9%8Bbc%E6%96%87%E4%BB%B6
categories:
 - llvm
tags: 
 - bc文件
---

# LLVM安装

可源码安装和release安装[llvm-release](https://github.com/llvm/llvm-project/releases/download/llvmorg-14.0.0/clang+llvm-14.0.0-x86_64-linux-gnu-ubuntu-18.04.tar.xz)

release版下好就能用，解压完大概4G左右，如果想在bash全局生效，可加入环境变量。
```bash
export LLVM_HOME=/home/xxxx/clang+llvm-14.0.0/bin
export PATH=SLLVM HOME:SPATH
```
将以上代码写入bashrc文件。

源码安装参考[官方方法](https://github.com/llvm/llvm-project)

# llvm bc文件

题目是做赛题时遇到的，我们看一下文件类型：
```bash
➜  file check_in.bc
check_in.bc: LLVM IR bitcode

```
发现是llvm的IR文件，即LLVM IR bitcode文件。
官方定义：LLVM是一个模块化和可重用的编译器和工具链技术的集合。

个人理解为bc文件是编译器LLVM的中间代码即IR指令文件，属于编译过程中的未完成的格式文件，继续往下编译生成.s（准确说叫.ll文件）汇编代码文件，再之后是可执行文件，往前是编译之前的源文件。

![image-1668741963013](/upload/2022/11/image-1668741963013.png)

此时可以通过llvm的clang来编译生成elf文件：
```bash
./clang check_in.bc -o check_in
```
会得到elf文件，然后通过ida去静态分析程序逻辑。

注：llvm的版本需要和bc文件的版本一致，否则会出现如下异常：
```bash
error: Unknown attribute kind (68) (Producer: 'LLVM14.0.0' Reader: 'LLVM 10.0.0')
1 error generated.
```

# llvm示例
编写示例hello.c
```c
#include <stdio.h>
int main(){
   printf("hello world\n");
}
```
将C文件编译为本机可执行文件，执行clang 命令如下：
```
$ clang  hello.c -o hello
```
**PS:** Clang为LLVM提供的C语言编译器，默认参数可以生成本机可执行的二进制程序。-S和-c参数与GCC一样，可分别生成.s汇编文件与.o目标文件。

将C文件编译为LLVM bitcode 文件， 执行如下如下命令
```
$ clang -o3  -emit-llvm hello.c -c -o hello.bc
$ clang -o3  -emit-llvm hello.c -S -o hello.ll
```
> .ll 文件 llvm bitcode 的可读文本 .bc 是bitcode的二进制格式

两种形式运行程序
```bash
$./hello
hello world
$./lli hello.bc
hello world
```
5.llvm-dis 工具反汇编llvm bitcode 文件， 可以将bc文件的内容以刻度文本形式进行展示

```bash
$ ./llvm-dis < hello.bc
; ModuleID = '<stdin>'
source_filename = "hello.c"
target datalayout = "e-m:o-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-apple-macosx10.12.0"

@str = private unnamed_addr constant [12 x i8] c"hello world\00"

; Function Attrs: nounwind ssp uwtable
define i32 @main() local_unnamed_addr #0 {
  %1 = tail call i32 @puts(i8* getelementptr inbounds ([12 x i8], [12 x i8]* @str, i64 0, i64 0))
  ret i32 0
}

; Function Attrs: nounwind
declare i32 @puts(i8* nocapture readonly) local_unnamed_addr #1

attributes #0 = { nounwind ssp uwtable "correctly-rounded-divide-sqrt-fp-math"="false" "disable-tail-calls"="false" "less-precise-fpmad"="false" "no-frame-pointer-elim"="true" "no-frame-pointer-elim-non-leaf" "no-infs-fp-math"="false" "no-jump-tables"="false" "no-nans-fp-math"="false" "no-signed-zeros-fp-math"="false" "no-trapping-math"="false" "stack-protector-buffer-size"="8" "target-cpu"="penryn" "target-features"="+cx16,+fxsr,+mmx,+sahf,+sse,+sse2,+sse3,+sse4.1,+ssse3,+x87" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { nounwind }

!llvm.module.flags = !{!0, !1}
!llvm.ident = !{!2}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"PIC Level", i32 2}
!2 = !{!"clang version 7.0.0 (tags/RELEASE_700/final)"}
```
llc 代码生成器将程序编译为本机CPU架构的汇编指令
```bash
$ ./llc hello.bc -o hello.s
$ cat hello.s
    .section    __TEXT,__text,regular,pure_instructions
    .macosx_version_min 10, 12
    .globl  _main                   ## -- Begin function main
    .p2align    4, 0x90
_main:                                  ## @main
    .cfi_startproc
## %bb.0:
    pushq   %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq    %rsp, %rbp
    .cfi_def_cfa_register %rbp
    leaq    L_str(%rip), %rdi
    callq   _puts
    xorl    %eax, %eax
    popq    %rbp
    retq
    .cfi_endproc
                                        ## -- End function
    .section    __TEXT,__cstring,cstring_literals
L_str:                                  ## @str
    .asciz  "hello world"


.subsections_via_symbols
```
将本机的汇编语言文件编译成程序，使用gcc 命令直接编译：
```bash
$ gcc hello.s -o hello.native
```
