---
title: ubuntu无法联网解决方法
id: 39
date: 2024-01-09 20:09:11
auther: yrl
cover: 
excerpt: 
permalink: /archives/ubuntu-wu-fa-lian-wang-jie-jue-fang-fa
categories:
 - linux
 - useful
tags: 
 - 常用功能
---

# 情况

一天开开虚拟机发现有网卡但是不能上网，尝试以下方法解决

# 判断

首先，我尝试了选择：编辑 --> 虚拟网络编辑器 --> 更改设置 --> 还原默认设置，或者在关闭虚拟机的前提下依次选择：虚拟机 --> 设置 --> 网络适配器 --> 改为桥接模式或者NAT模式，或者重启虚拟机等方式，但是这些方式都不能有效解决我的虚拟机断网问题。

# 解决

- 打开终端，输入	`sudo service network-manager stop`
- `sudo rm /var/lib/NetworkManager/NetworkManager.state`
- `sudo service network-manager start`
- `sudo vim /etc/NetworkManager/NetworkManager.conf`，将其中的managed=false改为managed=true
- `sudo service network-manager restart`

ubuntu显示网卡了。
