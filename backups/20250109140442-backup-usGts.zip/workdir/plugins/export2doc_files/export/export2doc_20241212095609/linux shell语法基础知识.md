---
title: linux shell语法基础知识
id: 125
date: 2024-01-09 20:09:12
auther: yrl
cover: 
excerpt: set命令总结set命令的四个参数，一般都放在一起使用，这两种写法建议放在所有 Bash 脚本的头部。写法一set -euxo pipefail写法二set -euxset -o pipefailset -u 未定义变量报错若使用未定义的变量默认不报错脚本在头部加上它，遇到不存在的变量就会报错，并停
permalink: /archives/linuxshell%E8%AF%AD%E6%B3%95%E5%9F%BA%E7%A1%80%E7%9F%A5%E8%AF%86
categories:
 - linux
 - shell脚本
tags: 
 - linuxshell基础
---

# 前言

这里记录一些遇到的linux shell基础命令的用法，遇到会实时更新...

## set命令总结
set命令的四个参数，一般都放在一起使用，这两种写法建议放在所有 Bash 脚本的头部。

### 写法一
`set -euxo pipefail`

### 写法二
```
set -eux
set -o pipefail
```
### set -u 未定义变量报错
若使用未定义的变量默认不报错

脚本在头部加上它，遇到不存在的变量就会报错，并停止执行
```
#!/usr/bin/env bash
set -u

echo $a
```
### set -x / set +x 打印执行语句 / 关闭输出
在运行结果之前，先输出执行的那一行命令
```
#!/usr/bin/env bash
set -x

echo bar
```
输出
```
$ bash script.sh
+ echo bar
bar
```
### set +x 关闭输出
```
#!/bin/bash

number=1

set -x
if [ $number = "1" ]; then
  echo "Number equals 1"
else
  echo "Number does not equal 1"
fi
set +x
```
### Bash 的错误处理
```
command || exit 1
```
### 停止后进行多步处理
```
# 写法一
command || { echo "command failed"; exit 1; }

# 写法二
if ! command; then echo "command failed"; exit 1; fi

# 写法三
command
if [ "$?" -ne 0 ]; then echo "command failed"; exit 1; fi
```
### set -e / set +e 脚本只要发生错误，就终止执行
```
#!/usr/bin/env bash
set -e

foo
echo bar
```
某些命令的非零返回值可能不表示失败,这时可以暂时关闭set -e，该命令执行结束后，再重新打开set -e

### set -o pipefail
多个子命令通过管道运算符（|）组合成为一个大的命令。

Bash 会把最后一个子命令的返回值，作为整个命令的返回值。

也就是说，只要最后一个子命令不失败，管道命令总是会执行成功，因此它后面命令依然会执行，set -e就失效了

使用 `set -o pipefail `可以解决这个问题
### 参考
[Bash脚本](http://static.kancloud.cn/idcpj/python/1988104)