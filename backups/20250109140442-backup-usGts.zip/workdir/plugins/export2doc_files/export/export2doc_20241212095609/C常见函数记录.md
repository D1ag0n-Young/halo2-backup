---
title: C常见函数记录
id: 118
date: 2024-01-09 20:09:12
auther: yrl
cover: 
excerpt: 
permalink: /archives/c-chang-jian-han-shu-ji-lu
categories:
 - note
 - cc
tags: 
 - c语言
---


# strtok

- 描述
C 库函数 `char *strtok(char *str, const char *delim)` **分解字符串 str 为一组字符串，delim 为分隔符。**

- 声明
下面是 strtok() 函数的声明。
`char *strtok(char *str, const char *delim)`

- 参数
str -- 要被分解成一组小字符串的字符串。
delim -- 包含分隔符的 C 字符串。

- 返回值
该函数返回被分解的第一个子字符串，如果没有可检索的字符串，则返回一个空指针。

# strset/strnset

`strset(char *str,char ch);` 功能: 将一个串中的所有字符都设为指定字符
`char *strnset(char *str, char ch, unsigned n); `功能 将一个字符串中的前n个字符都设为指定字符ch。

# 追加函数
## strcat()与strncat()函数

头文件：string.h

原型：

char *strcat(char *dest, const char *src)

char *strcat(char *dest, const char *src,int n)

返回值：将src以追加的方式添加到dest中，返回值为dest首地址或者也可以直接访问dest获得最终结果

# 查找字符串
## strstr()函数

头文件：string.h

原型

char *strstr(char *str1, const char *str2); //从左向右

返回值：返回查找到的字符串中的首地址

注意：strrstr()函数是不自带的，可以通过strstr()进行模拟

举个栗子：
```c
#include<stdio.h>
#include<string.h>
void main(){
 char *ch1="1234562321";
 printf("%s\n",strstr(ch1,"23"));//234562321
 if(!strstr(ch1,"5566")){
  printf("-------------\n");//成功输出此处
 }
}
```

# 查找字符
## strchr()与strrchr()函数

头文件：string.h

原型：

char *strchr(const char *s,char c) //从左向右

char *strrchr(const char *s,char c) //从右向左

返回值：返回查找到的本身位置，如果查找失败则发货NULL

- 描述
C 库函数 char *strchr(const char *str, int c) 在参数 str 所指向的字符串中搜索第一次出现字符 c（一个无符号字符）的位置。

- 声明
下面是 strchr() 函数的声明。
char *strchr(const char *str, int c)

- 参数
str -- 要被检索的 C 字符串。
c -- 在 str 中要搜索的字符。
- 返回值
该函数返回在字符串 str 中第一次出现字符 c 的位置，如果未找到该字符则返回 NULL。

# 类型转换
## Str->double
函数原型：double strtod(const char *nptr,char **endptr);

说明：nptr为原字符串，endptr原字符串转换后抛弃的后面的内容，填写NULL则不返回，原字符串数字前面只能是控制或者加减号。

返回值：正负double值

## Str->long int

头文件:stdlib.h

函数原型：long int strtol(const char *str, char **endptr, int base)

返回值：长整型，以base提取，然后再转换为long int 类型

参数：

str -- 要转换为长整数的字符串。

endptr -- 对类型为 char* 的对象的引用，其值由函数设置为 str 中数值后的下一个字符。

base -- 基数，必须介于 2 和 36（包含）之间，或者是特殊值 0（如0x开头的自动设置为十六进制等）。

## Str->int

头文件：stdlib.h

原型：int atoi(const char *nptr);

注意：原字符串开头必须是空格或者数字或者加减号

# str->double

atof() 字符串转换到 double 符点数,使用方法与stoi相似

# str->long int

atol() 字符串转换到 long 整型，使用方法与stoi相似