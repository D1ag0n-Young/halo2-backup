---
title: tea算法
id: db869d9a-118e-431e-8b78-37423fe70dc3
date: 2024-01-12 21:35:03
auther: csh
cover: null
excerpt: 2019红帽杯xx——xxtea RE与算法-tea加密算法 tea TEA算法使用64位的明文分组和128位的密钥，它使用Feistel分组加密框架，需要进行 64 轮迭代，作者认为32轮就已经足够。该算法使用了一个神秘常数δ作为倍数，它来源于黄金比率，以保证每一轮加密都不相同。 在TEA算法中有
permalink: /archives/teasuan-fa
categories:
tags: 
 - reverse
 - 脚本
---

# 2019红帽杯xx——xxtea

# RE与算法-tea加密算法

## tea

TEA算法使用64位的明文分组和128位的密钥，它使用Feistel分组加密框架，需要进行 64 轮迭代，作者认为32轮就已经足够。该算法使用了一个神秘常数δ作为倍数，它来源于黄金比率，以保证每一轮加密都不相同。

在TEA算法中有一个固定的常数`0x9e3779b9`或者`0x61c88647`或者其他。

加密过程，tea的加密过程，抽取key密钥中的前四位，加密数组4个字节为一组每次加密两组。总共加密32轮，最后再把加密的结果重新写入到数组中。

加密脚本：

```c
void encrypt(uint32_t* v,uint32_t* key){
uint32_t v0=v[0],v1=v[1],sum=0,i;
uint32_t delta=0x9e3779b9;
uint32_t k0=key[0],k1=key[1],k2=key[2],k3=key[3];
for(i=0;i<32;i++){
    sum+=delta;
    v0+=((v1<<4)+k0)^(v1+sum)^((v1>>5)+k1);
    v1+=((v0<<4)+k2)^(v0+sum)^((v0>>5)+k3);
}
v[0]=v0;v[1]=v1;
}
```

解密脚本

```c
void decrypt(uint32_t* v,uint32_t* key){
uint32_t v0=v[0],v1=v[1],sum=0xC6EF3720,i;
uint32_t delta=0x9e3779b9;
uint32_t k0=key[0],k1=key[1],k2=key[2],k3=key[3];
for(i=0;i<32;i++){
    v1-=((v0<<4)+k2)^(v0+sum)^((v0>>5)+k3);
    v0-=((v1<<4)+k0)^(v1+sum)^((v1>>5)+k1);
    sum-=delta;
}
v[0]=v0;v[1]=v1;
}
```

## xTea

XTEA 跟 TEA 使用了相同的简单运算，但它采用了不同的顺序，为了阻止密钥表攻击，四个子密钥（在加密过程中，原 128 位的密钥被拆分为 4 个 32 位的子密钥）采用了一种不太正规的方式进行混合。

其中`key[sum & 3]`就是通过计算来取子密钥，`sum & 3`结果会出现在`[0, 4]`。

加密脚本

```c
void encipher(unsigned int num_rounds, uint32_t v[2], uint32_t const key[4])
{
    unsigned int i;
    uint32_t v0=v[0],v1=v[1],delta=0x9E3779B9,sum=delta*num_rounds;
    for(i=0;i<num_rounds;i++){
        v0+=(((v1<<4)^(v1>>5))+v1)^(sum+key[sum&3]);
        sum += delta;
        v1 += (((v0 << 4) ^ (v0 >> 5)) + v0) ^ (sum + key[(sum>>11) & 3]);
    }
    v[0]=v0;v[1]=v1;
}
```

解密脚本

```c
void encipher(unsigned int num_rounds, uint32_t v[2], uint32_t const key[4])
{
    unsigned int i;
    uint32_t v0=v[0],v1=v[1],delta=0x9E3779B9,sum=delta*num_rounds;
    for(i=0;i<num_rounds;i++){
        v0+=(((v1<<4)^(v1>>5))+v1)^(sum+key[sum&3]);
        sum += delta;
        v1 += (((v0 << 4) ^ (v0 >> 5)) + v0) ^ (sum + key[(sum>>11) & 3]);
    }
    v[0]=v0;v[1]=v1;
}
```

## xxTea

相比TEA,xTEA算法，xxTEA算法的优势是原字符串长度可以不是4的倍数了。

加密脚本

```c
#include <stdio.h>
#include <stdint.h>
#define DELTA 0x9e3779b9
#define MX (((z>>5^y<<2)+(y>>3^z<<4))^((sum^y)+(key[(p&3)^e]^z)))
void btea(uint32_t *v,int n,uint32_t const key[4])//n为v数组长度 
{
    uint32_t y,z,sum;
    unsigned p,rounds,e;
    if(n>1)
    {
        rounds=6+52/n;
        sum=0;
        z=v[n-1];
        do
        {
            sum+=DELTA;//循环加密过程
            e=(sum>>2)&3;
            for(p=0;p<n-1;p++)
            {
                y=v[p+1];
                v[p]+=MX;
                z=v[p];
            }
            y=v[0];
            z=v[n-1]+=MX;
        }
        while(--rounds); 
    }
}     
```

解密脚本

```c
#include <stdio.h>
#include <stdint.h>
#define DELTA 0x9e3779b9
#define MX (((z>>5^y<<2)+(y>>3^z<<4))^((sum^y)+(key[(p&3)^e]^z)))
void dtea(uint32_t *v,int n,uint32_t const key[4])//n为v数组长度 {
 rounds = 6 + 52/n;
 sum = rounds*DELTA;
    y = v[0];
    do {
        e = (sum >> 2) & 3;
        for (p=n-1; p>0; p--) {
          z = v[p-1];
          y = v[p] -= MX;
        }
        z = v[n-1];
        y = v[0] -=
        MX;
        sum -= DELTA;
      } while (--rounds);
}
```

## 特征和区分点

相同点：

1.  key 128 bit特征量`0x9e3779b9`
2.  主要加密部分进行移位和异或操作

首先如果题目中出现常量`0x9e3779b9`，那么肯定是`Tea`相关算法了。

区分：

1.  Tea的主加密部分为`<<4,>>5,xor`，循环32轮
2.  xTea的主加密部分`<<4,>>5,>>11,xor`,循环次数不定，但通常也为32轮，需要传入3个参数
3.  xxTea的主加密部分`>>5,<<2,>>3,<<4,xor`,循环次数为`6+52/n`，enc长度大于64

## 题目练习

### \[2019红帽杯]xx

#### 首先复习一下ida远程调试

ida支持远程调试Windows、linux、Android、Mac OS的二进制文件，将文件放在远程的对应系统服务器上，ida远程连接服务器，在服务器上运行、调试程序，并在本地客户端显示调试界面。界面视图上和本地调试并没有区别。

如果需要远程调试，首先需要将ida的服务端部署在远程服务器上，ida的服务端存储在ida目录中的dbgsrv文件中

图片

将需要调试的文件和服务端版本放入服务器中，然后运行服务端，会默认在23946端口启动ida服务端程序，以windows为例

被调试程序是64位`exe`文件，所以在本机(就是服务器端，linux的话可以使用虚拟机运行)win64\_remote64.exe，然后回到本机(客户端)。

客户端的第一步没什么变化，在ida菜单选择debugger栏，在选择debugger时，选择Remote Linux debugger，

然后在ida菜单选择debugger栏，选择process options，第一行application和input file选择被调试文件在服务端中的存储路径。下面第三行的directory是存储路径，直接选被调试文件所在目录就行。再下面第四行的是程序启动时传入的参数，可以为空。在hostname栏填写服务器端地址，可以是本机地址，或者虚拟机地址等等。

最后一行的password是linux\_server启动时设置的密码，如果没有设置，则为空即可。全部设置正确之后就可以开始调试了

点击“start process”或者F9，开始调试程序。

-   F7  单步步进
-   F8  单步步过
-   F9  继续运行程序
-   F4  运行到光标所在行
-   Ctrl + F7  直到该函数返回时才停止
-   Ctrl + F2  终止一个正在运行的进程
-   F2  设置断点

#### 回归xx题目

通过调试得到函数大致流程：

- 输入

  ![](image/image_2gv8yeCIAf.png)

- 检查输入是否合法
  只判断了前四位

  ![](image/image_6pmqxZN1Cv.png)

- 构造前四位为key，作为xxtea加密的密钥

  ![](image/image_BIZxzAAgBn.png)

- 将xxtea加密结果调换顺序

  ![](image/image_pgGiLzh_lo.png)

- 将调换完顺序的结果，做一个有规律的异或

  ![](image/image_bbkz0B6P1C.png)

- 将异或结果与正确数据比较，注意小端序

  ![](image/image_Vt_At9jaKE.png)

#### 解密：

```python
# 解异或
data = [0xCE, 0xBC, 0x40, 0x6B, 0x7C, 0x3A, 0x95, 0xC0, 0xEF, 0x9B, 0x20, 0x20, 0x91, 0xF7, 0x02, 0x35, 0x23, 0x18, 0x02, 0xC8, 0xE7, 0x56, 0x56, 0xFA]


def divide_list(lst, n):
    # 计算每个小列表的长度
    size = len(lst) // n

    # 创建嵌套列表
    nested_list = [lst[i:i + size] for i in range(0, len(lst), size)]

    return nested_list

parts = 8
divided_list = divide_list(data, parts)
print(divided_list)

i = 8
while(i >= 0):
    if i == 0:
        pass
    else:
        part = divided_list[i - 1]
        for k in range(len(part)):
            for j in range(i-1):
                data[(i-1)*3 + k] ^= data[j]
    i -= 1
print(data)
print([hex(x) for x in data])

"""
result：
['0xce', '0xbc', '0x40', '0xa5', '0xb2', '0xf4', '0xe7', '0xb2', '0x9d', '0xa9', '0x12', '0x12', '0xc8', '0xae', '0x5b', '0x10', '0x6', '0x3d', '0x1d', '0xd7', '0xf8', '0xdc', '0xdc', '0x70']
"""


# 调换顺序

v19 = [0] * 24
v20 = data
# 调换循序
v19[2] = v20[0]
v19[0] = v20[1]
v19[3] = v20[2]
v19[1] = v20[3]
v19[6] = v20[4]
v19[4] = v20[5]
v19[7] = v20[6]
v19[5] = v20[7]
v19[10] = v20[8]
v19[8] = v20[9]
v19[11] = v20[10]
v19[9] = v20[11]
v19[14] = v20[12]
v19[12] = v20[13]
v19[15] = v20[14]
v19[13] = v20[15]
v19[18] = v20[16]
v19[16] = v20[17]
v19[19] = v20[18]
v19[17] = v20[19]
v19[22] = v20[20]
v19[20] = v20[21]
v19[23] = v20[22]
v19[21] = v20[23]
print([hex(x) for x in v19])

"""
result:
['0xbc', '0xa5', '0xce', '0x40', '0xf4', '0xb2', '0xb2', '0xe7', '0xa9', '0x12', '0x9d', '0x12', '0xae', '0x10', '0xc8', '0x5b', '0x3d', '0xd7', '0x6', '0x1d', '0xdc', '0x70', '0xf8', '0xdc']
"""

groups = [hex_list[i:i + 4] for i in range(0, len(hex_list), 4)]

# 对每组应用小端序并组合成单个字节
bytes_list = []
group_processed = []
for group in groups:

    group_processed = [num[2:] for num in group[::-1]]
    byte_str = ''.join(group_processed)
    bytes_list.append(byte_str)

print(bytes_list)

"""
['40cea5bc', 'e7b2b2f4', '129d12a9', '5bc810ae', '1d6d73d', 'dcf870dc']
"""

```

解异或更简单的算法

```c
#include<stdio.h>
#include<Windows.h>
int main()
{
    int count = 0;
    int b[24];
    int a[] = { 0xCE, 0xBC, 0x40, 0x6B, 0x7C, 0x3A, 0x95, 0xC0, 0xEF, 0x9B, 0x20, 0x20, 0x91, 0xF7, 0x02, 0x35, 0x23, 0x18, 0x02, 0xC8, 0xE7, 0x56, 0x56, 0xFA };

    for (int i = 23; i >=3; i--)
    {

        for (int j = 6-count; j >= 0; j--)
        {
                a[i]^=a[j];     
        }
        if (i % 3 == 0)
        {
            count++;
        }

    }
```

xxtea解密脚本：

python版本

```python
# python2
import struct  
  
_DELTA = 0x9E3779B9  
  
def _long2str(v, w):  
    n = (len(v) - 1) << 2  
    if w:  
        m = v[-1]  
        if (m < n - 3) or (m > n): return ''  
        n = m  
    s = struct.pack('<%iL' % len(v), *v)  
    return s[0:n] if w else s  
  
def _str2long(s, w):  
    n = len(s)  
    m = (4 - (n & 3) & 3) + n  
    s = s.ljust(m, "\0")  
    v = list(struct.unpack('<%iL' % (m >> 2), s))  
    if w: v.append(n)  
    return v  
  
def encrypt(str, key):  
    if str == '': return str  
    v = _str2long(str, True)  
    k = _str2long(key.ljust(16, "\0"), False)  
    n = len(v) - 1  
    z = v[n]  
    y = v[0]  
    sum = 0  
    q = 6 + 52 // (n + 1)  
    while q > 0:  
        sum = (sum + _DELTA) & 0xffffffff  
        e = sum >> 2 & 3  
        for p in xrange(n):  
            y = v[p + 1]  
            v[p] = (v[p] + ((z >> 5 ^ y << 2) + (y >> 3 ^ z << 4) ^ (sum ^ y) + (k[p & 3 ^ e] ^ z))) & 0xffffffff  
            z = v[p]  
        y = v[0]  
        v[n] = (v[n] + ((z >> 5 ^ y << 2) + (y >> 3 ^ z << 4) ^ (sum ^ y) + (k[n & 3 ^ e] ^ z))) & 0xffffffff  
        z = v[n]  
        q -= 1  
    return _long2str(v, False)  
  
def decrypt(str, key):  
    if str == '': return str  
    v = _str2long(str, False)  
    k = _str2long(key.ljust(16, "\0"), False)  
    n = len(v) - 1  
    z = v[n]  
    y = v[0]  
    q = 6 + 52 // (n + 1)  
    sum = (q * _DELTA) & 0xffffffff  
    while (sum != 0):  
        e = sum >> 2 & 3  
        for p in xrange(n, 0, -1):  
            z = v[p - 1]  
            v[p] = (v[p] - ((z >> 5 ^ y << 2) + (y >> 3 ^ z << 4) ^ (sum ^ y) + (k[p & 3 ^ e] ^ z))) & 0xffffffff  
            y = v[p]  
        z = v[n]  
        v[0] = (v[0] - ((z >> 5 ^ y << 2) + (y >> 3 ^ z << 4) ^ (sum ^ y) + (k[0 & 3 ^ e] ^ z))) & 0xffffffff  
        y = v[0]  
        sum = (sum - _DELTA) & 0xffffffff  
    return _long2str(v, True)

if __name__ == "__main__":  
    key = "flag"
    data1 = [0xbc,0xa5,0xce,0x40,0xf4,0xb2,0xb2,0xe7,0xa9,0x12,0x9d,0x12,0xae,0x10,0xc8,0x5b,0x3d,0xd7,0x6,0x1d,0xdc,0x70,0xf8,0xdc]
    s = "".join(map(chr, data1))
    s = decrypt(s, key)
    print(repr(s))

```

C语言版本

```c
#include <stdio.h>  
#include <stdint.h>  
#define DELTA 0x9e3779b9  
#define MX (((z>>5^y<<2) + (y>>3^z<<4)) ^ ((sum^y) + (key[(p&3)^e] ^ z)))  

void btea(uint32_t *v, int n, uint32_t const key[4])
{
    uint32_t y, z, sum;
    unsigned p, rounds, e;
    if (n > 1)            /* Coding Part */
    {
        rounds = 6 + 52 / n;
        sum = 0;
        z = v[n - 1];
        do
        {
            sum += DELTA;
            e = (sum >> 2) & 3;
            for (p = 0; p<n - 1; p++)
            {
                y = v[p + 1];
                z = v[p] += MX;
            }
            y = v[0];
            z = v[n - 1] += MX;
        } while (--rounds);
    }
    else if (n < -1)      /* Decoding Part */
    {
        n = -n;
        rounds = 6 + 52 / n;
        sum = rounds*DELTA;
        y = v[0];
        do
        {
            e = (sum >> 2) & 3;
            for (p = n - 1; p>0; p--)
            {
                z = v[p - 1];
                y = v[p] -= MX;
            }
            z = v[n - 1];
            y = v[0] -= MX;
            sum -= DELTA;
        } while (--rounds);
    }
}

int main()
{
    uint32_t v[6] = { (unsigned int)0x40cea5bc, (unsigned int)0xe7b2b2f4,(unsigned int)0x129d12a9,(unsigned int)0x5bc810ae,(unsigned int)0x1d06d73d,(unsigned int)0xdcf870dc };
            uint32_t const k[4] = { (unsigned int)0x67616c66, (unsigned int)0x0, (unsigned int)0X0, (unsigned int)0x0 };
            int n = 6; //n的绝对值表示v的长度，取正表示加密，取负表示解密  
            // v为要加密的数据是两个32位无符号整数  
            // k为加密解密密钥，为4个32位无符号整数，即密钥长度为128位  
            btea(v, -n, k);
            // 逐个字节输出每个字符
      for (int i = 0; i < n; ++i) {
        for (int j = 0; j < 4; ++j) {
          printf("%c", ((char*)&v[i])[j]);
        }
      }
      printf("\n");
    return 0;
}
```

结果：

![](image/image_usDdOA-beq.png)

参考链接：

[https://forum.butian.net/share/1455](url "https://forum.butian.net/share/1455")

[https://blog.csdn.net/m0\_52164435/article/details/124871122](https://blog.csdn.net/m0_52164435/article/details/124871122 "https://blog.csdn.net/m0_52164435/article/details/124871122")