---
title: Note-Useful
id: 35
date: 2024-01-09 20:09:11
auther: yrl
cover: 
excerpt: 新建用户及修改密码groupadd ctf useradd -g ctf ctf -mecho &quot;ctf112331d2sd23&quot; | chpasswdssh配置hostkey算法适配高版本容器的ssh兼容性。需要在服务器端的/etc/ssh/sshd_config配置中增加H
permalink: /archives/note-useful
categories:
 - linux
 - note
 - useful
tags: 
 - 常用功能
---

# 新建用户及修改密码

```bash
groupadd ctf 
useradd -g ctf ctf -m
echo "ctf:112331d2sd23" | chpasswd
```
# ssh配置hostkey算法

**适配高版本容器的ssh兼容性**。
需要在服务器端的/etc/ssh/sshd_config配置中增加
```
HostkeyAlgorithms +ssh-rsa
PubkeyAcceptedAlgorithms +ssh-rsa
```
重启systemctl restart sshd 即可。

# 容器ssh、xinetd服务在centos服务器上起不来

是容器版本太高导致在centos上起不来，添加`--security-opt seccomp=unconfined`参数绕过docker系统调用的限制。

`docker run -itd --security-opt seccomp=unconfined qad `
[Docker运行ubuntu22.04出现异常](https://blog.csdn.net/fly910905/article/details/126473224)

# C语言实现execve执行命令

```c
#include<stdio.h>
#include<unistd.h>

int main(int arg, char **args)
{
    char *argv[]={"./qemu-system-x86_64","-display","none","-machine", "accel=qtest", "-m", "512M", "-nodefaults", "-monitor", "none", "-qtest", "stdio", "-device", "ctf", NULL};

    char *envp[]={0,NULL}; //传递给执行文件新的环境变量数组

    execve("./qemu-system-x86_64",argv,envp);

}
//./qemu-system-x86_64 -display none -machine accel=qtest -m 512M -nodefaults -monitor none -qtest stdio -device ctf
```

# docker清理bridge
```bash
docker network prune
```
[non-overlapping IPv4...错误](https://blog.csdn.net/linhua_111/article/details/119380067)

# ubuntu自动挂载目录

下面实现开机自动挂载远程NAS目录和宿主机共享目录：
```bash
# /etc/fstab: static file system information.
#
# Use 'blkid' to print the universally unique identifier for a
# device; this may be used with UUID= as a more robust way to name devices
# that works even if disks are added and removed. See fstab(5).
#
# <file system> <mount point>   <type>  <options>       <dump>  <pass>
# / was on /dev/sda5 during installation
UUID=5d56ada6-3730-447f-8951-349cb90b6f3a /               ext4    errors=remount-ro 0       1
# /boot/efi was on /dev/sda1 during installation
UUID=B7D6-896A  /boot/efi       vfat    umask=0077      0       1
/swapfile                                 none            swap    sw              0       0
//10.10.10.15/sharedata /mnt/sharedata cifs username=xxx1,password=111111,vers=2.0,gid=1000,uid=1000 0 0
.host:/  /mnt/win10  fuse.vmhgfs-fuse  nonempty,allow_other  0  0
```

手动查看虚拟机共享目录：
```bash
vmware-hgfsclien #查看共享目录名字
sudo vmhgfs-fuse .host:/ /mnt/hgfs -o allow_other #挂载
```

# 虚拟机no space left开不开机，ssh也连不上

前提是你的虚拟机开启了ssh并且你知道ip，使用ssh执行命令删除虚拟机许需要的大文件或者临时文件

```bash
ssh root@1192.168.70.129 "cmd1;cmd2;"
```

# 更新ubuntu 内核

```bash
apt update 
apt upgrade #更新所有软件，包括内核
或
apt search linux-image # 搜索选择合适的linux内核版本
apt upgrade linux-image-generic #更新指定版本内核
```

# gdb dump内存为Cbytes

```
# dump_memory.gdb
define dump_memory
  set $addr = $arg0
  set $size = $arg1
  python
import gdb
addr = int(gdb.parse_and_eval("$addr"))
size = int(gdb.parse_and_eval("$size"))
data = gdb.selected_inferior().read_memory(addr, size)
output = ', '.join('0x{:02x}'.format(byte) for byte in data.tobytes())
print('unsigned char data[{}] = {{ {} }};'.format(size, output))
end
end
```

用法
```bash
source dump_memory.gdb
dump_memory $addr $size
dump_memory 0x4001256 0x4d
```
