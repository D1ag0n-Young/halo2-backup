---
title: shell脚本学习--工具实例集合
id: 162
date: 2024-01-09 20:09:14
auther: yrl
cover: 
excerpt: string&lt;-&gt;hexstring互转#!/bin/bashif [ $1 == &#39;enc&#39; ] then    # 要转换的字符串    input_str=$2    # 将字符串转换为十六进制字符    hex_str=$(echo &quot;$input_st
permalink: /archives/shell%E8%84%9A%E6%9C%AC%E5%AD%A6%E4%B9%A0--%E5%B7%A5%E5%85%B7%E5%AE%9E%E4%BE%8B%E9%9B%86%E5%90%88
categories:
 - ctf
 - linux
 - shell脚本
 - useful
tags: 
 - shell编程
---

# string<->hexstring互转

```bash
#!/bin/bash

if [ $1 == 'enc' ] 
then
    # 要转换的字符串
    input_str=$2
    # 将字符串转换为十六进制字符
    hex_str=$(echo "$input_str" | xxd -p |tr -d '\n')
    # 输出转换后的十六进制字符
    echo "$hex_str"
elif [ $1 == 'dec' ] 
then
    # 解密并执行命令
    echo -ne $2 | xxd -r -ps 
else
    echo "Usage ./2hexstr.sh enc/dec string"
fi
```
# 批量检测pi是否存活

```bash
#!/bin/bash

for a in $(seq $1 $2)  # team id
do
	for i in $(seq 11 11) # problem number
do
	ping -c 3 172.36.$a.$i | grep ttl > /dev/null 2>&1
	if [ $? != 0 ]
	then
		echo  -e "\033[0;31m172.36.$a.$i is DOWN\033[m"
		# echo  "\033[0;31m172.35.$a.$i is DOWN\033[m"
	else
		echo  -e "\033[0;32m172.36.$a.$i is UP\033[m"
		# echo  "\033[0;31m172.35.$a.$i is DOWN\033[m"
	fi
done
done

```

# shell脚本批量跑checker（非并发）

```bash
#!/bin/bash


for a in $(seq 61 64)  # problem number
do

	for i in $(seq 11 30) # team id
do
	if [[ $1 == '' ]]
	then
		echo "Usage: ./checker.sh 61"
		exit
	elif [ $1 == "61" ] && [ $a -eq 61 ]
	then
		echo -e "\033[0;32m172.35.$a.$i\033[m" → "python3 checker-babyphp.py" 172.35.$a.$i
		python3 checker-babyphp.py 172.35.$a.$i
	elif [ $1 == "62" ] && [ $a -eq 62 ]
	then
		echo -e "\033[0;32m172.35.$a.$i\033[m" → "python3 checker-bjcms.py" 172.35.$a.$i
		python3 checker-bjcms.py 172.35.$a.$i
	elif [ $1 == "63" ] && [ $a -eq 63 ]
	then
		echo -e "\033[0;32m172.35.$a.$i\033[m" → "python3 checker-ezcard.py" 172.35.$a.$i
		python3 checker-ezcard.py 172.35.$a.$i
	elif [ $1 == "64" ] && [ $a -eq 64 ]
	then
		echo -e "\033[0;32m172.35.$a.$i\033[m" → "python3 checker-phpok.py" 172.35.$a.$i
		python3 checker-phpok.py 172.35.$a.$i
	# else
	# 	echo "error ip!"
	fi
done
done

```

# change/download glibc

```bash
#!/bin/bash
usage_dowload() {
  echo >&2 "Usage: $0 id"
  exit 2
}
usage_extract() {
  echo -e >&2 "Usage: $0 deb output"
  exit 2
}
die() {
  echo >&2 $1
  exit 1
}
get_arch() {
    local x86="X86-64"
    local x32="80386"
    local data=$(readelf -h $1)
    if [[ $data =~ $x86 ]];then
        arch='amd64'
    elif [[ $data =~ $x32 ]];then
        arch='i386'
    else 
        echo "no"
        exit 1
    fi
}

get_ver() {
    buf=$(strings $libcname |grep "GNU C Library" |awk '{print $6}')
    libcversion=${buf%*)}
    buf=$(strings $libcname |grep "GNU C Library" |awk '{print $6}')
    version=${buf%-*}
}
extract() {
    if [[ $# -ne 2 ]]; then
        usage_extract
    fi
    local deb=`readlink -f $1`
    local out=$2
    if [ ! -d "$out" ]; then
        mkdir $out
    fi
    local tmp=`mktemp -d`

    cd $tmp
    ar xv $deb || die "ar failed"
    if [ -f "data.tar.zst" ];then
        tar -I zstd -xf data.tar.* || die "tar failed"
    else
        tar xf data.tar.* || die "tar failed"
    fi
    cd -

    cp -rP $tmp/lib/*/* $out 2>/dev/null \
      || cp -rP $tmp/lib32/* $out 2>/dev/null \
      || cp -rP $tmp/usr/lib/debug/lib/*/* $out 2>/dev/null \
      || cp -rP $tmp/usr/lib/debug/lib32/* $out 2>/dev/null \
      || cp -rP $tmp/usr/lib/debug/.build-id $out 2>/dev/null \
      || die "Failed to save. Check it manually $tmp"

    rm -rf $tmp
}
clibc() {
    FILE_NAME=$1
    LIBC_VERSION=$2
    LIBC_DIR=/home/yrl/glibc-all-in-one
    libc_dir=$(find $LIBC_DIR -name "$LIBC_VERSION*")
    if [ "$libc_dir" = "" ];then
        echo "Not support version or your $LIBC_DIR don't have libc"
        exit
    fi
    if  [ "$3" ] 
    then
        if [[ $(echo "$LIBC_VERSION >= 2.31"|bc) -eq 1 ]];then
            Record $1
            patchelf --set-interpreter $3/ld-linux-x86-64.so.2 --set-rpath $3/ $1
            sudo rm -rf /usr/lib/debug/.build-id/
            sudo cp -r $3/.debug/.build-id/ /usr/lib/debug
            die "[+]success"
        else
        Record $1
        patchelf --set-interpreter $3/ld-$LIBC_VERSION.so --set-rpath $3/ $1
        die "[+]success"
        fi
    else
        printf '%s\n' "$libc_dir"
        echo -e '\033[32mPlease specify the directory \033[0m'
    fi
}
chlibc() {
    FILE_NAME=$1
    LIBC_VERSION=$2
    LIBC_DIR=/home/yrl/glibc-all-in-one
    libc_dir=$(find $LIBC_DIR -name "$LIBC_VERSION*")
    if [ "$libc_dir" = "" ];then
        echo "Not support version or your $LIBC_DIR don't have libc"
        exit
    fi
    if  [ "$3" ] 
    then
        if [[ $(echo "$LIBC_VERSION >= 2.31"|bc) -eq 1 ]];then
            Record $1
            patchelf --set-interpreter $3/ld-linux-x86-64.so.2 --replace-needed libc.so.6 $3/libc.so.6 $1
            sudo rm -rf /usr/lib/debug/.build-id/
            sudo cp -r $3/.debug/.build-id/ /usr/lib/debug
            die "[+]success"
        else
        Record $1
        patchelf --set-interpreter $3/ld-$LIBC_VERSION.so --replace-needed libc.so.6 $3/libc-$LIBC_VERSION.so $1
        die "[+]success"
        fi
    else
        printf '%s\n' "$libc_dir"
        echo -e '\033[32mPlease specify the directory \033[0m'
    fi
}
download_rpath() {
    id=$libcversion'_'$arch
    local LIBC_PREFIX="libc6_"
    local LIBC_DBG_PREFIX="libc6-dbg_"
    local deb_name=$LIBC_PREFIX$id.deb
    local dbg_name=$LIBC_DBG_PREFIX$id.deb
    echo "Getting $id"
    if [ -d "$LIBC_DIR/libs/$id" ]; then
        clibc $filename $version $LIBC_DIR/libs/$id
        die "[+]success"
    fi
    # download binary package
    url="$SOURCE/$deb_name"
    echo "  -> Location: $url"
    echo "  -> Downloading libc binary package"
    sudo wget "$url" 2>/dev/null -O $LIBC_DIR/debs/$deb_name || download_old_rpath
    echo "  -> Extracting libc binary package"
    mkdir $LIBC_DIR/libs/$id
    extract $LIBC_DIR/debs/$deb_name $LIBC_DIR/libs/$id
    echo "  -> Package saved to $LIBC_DIR/libs/$id"

    # download debug info package
    url="$SOURCE/$dbg_name"
    echo "  -> Location: $url"
    echo "  -> Downloading libc debug package"
    sudo wget "$url" 2>/dev/null -O $LIBC_DIR/debs/$dbg_name || download_old_rpath
    echo "  -> Extracting libc debug package"
    mkdir $LIBC_DIR/libs/$id/.debug
    extract $LIBC_DIR/debs/$dbg_name $LIBC_DIR/libs/$id/.debug
    echo "  -> Package saved to $LIBC_DIR/libs/$id/.debug"
    
    clibc $filename $version $LIBC_DIR/libs/$id
    die "[+]success"
}
download_old_rpath(){
    id=$libcversion'_'$arch
    local LIBC_PREFIX="libc6_"
    local LIBC_DBG_PREFIX="libc6-dbg_"
    local deb_name=$LIBC_PREFIX$id.deb
    local dbg_name=$LIBC_DBG_PREFIX$id.deb
    echo "Getting $id"
    if [ -d "$LIBC_DIR/libs/$id" ]; then
        clibc $filename $version $LIBC_DIR/libs/$id
        die "[+]success"
    fi
    # download binary package
    url="$OLD_SOURCE/$deb_name"
    echo "  -> Location: $url"
    echo "  -> Downloading libc binary package"
    sudo wget "$url" 2>/dev/null -O $LIBC_DIR/debs/$deb_name || die "Failed to download package from $url"
    echo "  -> Extracting libc binary package"

    mkdir $LIBC_DIR/libs/$id
    extract $LIBC_DIR/debs/$deb_name $LIBC_DIR/libs/$id
    echo "  -> Package saved to $LIBC_DIR/$libs/$id"

    # download debug info package
    url="$OLD_SOURCE/$dbg_name"
    echo "  -> Location: $url"
    echo "  -> Downloading libc debug package"
    sudo wget "$url" 2>/dev/null -O $LIBC_DIR/debs/$dbg_name || die "Failed to download package from $url"
    echo "  -> Extracting libc debug package"
    mkdir $LIBC_DIR/libs/$id/.debug
    extract $LIBC_DIR/debs/$dbg_name $LIBC_DIR/libs/$id/.debug
    echo "  -> Package saved to $LIBC_DIR/libs/$id/.debug"
    clibc $filename $version $LIBC_DIR/libs/$id
    die "[+]success"
}

download_need() {
    id=$libcversion'_'$arch
    local LIBC_PREFIX="libc6_"
    local LIBC_DBG_PREFIX="libc6-dbg_"
    local deb_name=$LIBC_PREFIX$id.deb
    local dbg_name=$LIBC_DBG_PREFIX$id.deb
    echo "Getting $id"
    if [ -d "$LIBC_DIR/libs/$id" ]; then
        chlibc $filename $version $LIBC_DIR/libs/$id
        die "[+]success"
    fi
    # download binary package
    url="$SOURCE/$deb_name"
    echo "  -> Location: $url"
    echo "  -> Downloading libc binary package"
    sudo wget "$url" 2>/dev/null -O $LIBC_DIR/debs/$deb_name || download_old_need
    echo "  -> Extracting libc binary package"
    mkdir $LIBC_DIR/libs/$id
    extract $LIBC_DIR/debs/$deb_name $LIBC_DIR/libs/$id
    echo "  -> Package saved to $LIBC_DIR/libs/$id"

    # download debug info package
    url="$SOURCE/$dbg_name"
    echo "  -> Location: $url"
    echo "  -> Downloading libc debug package"
    sudo wget "$url" 2>/dev/null -O $LIBC_DIR/debs/$dbg_name || download_old_need
    echo "  -> Extracting libc debug package"
    mkdir $LIBC_DIR/libs/$id/.debug
    extract $LIBC_DIR/debs/$dbg_name $LIBC_DIR/libs/$id/.debug
    echo "  -> Package saved to $LIBC_DIR/libs/$id/.debug"
    chlibc $filename $version $LIBC_DIR/libs/$id
    die "[+]success"
}
download_old_need(){
    id=$libcversion'_'$arch
    local LIBC_PREFIX="libc6_"
    local LIBC_DBG_PREFIX="libc6-dbg_"
    local deb_name=$LIBC_PREFIX$id.deb
    local dbg_name=$LIBC_DBG_PREFIX$id.deb
    echo "Getting $id"
    if [ -d "$LIBC_DIR/libs/$id" ]; then
        chlibc $filename $version $LIBC_DIR/libs/$id
        die "[+]success"
    fi
    # download binary package
    url="$OLD_SOURCE/$deb_name"
    echo "  -> Location: $url"
    echo "  -> Downloading libc binary package"
    sudo wget "$url" 2>/dev/null -O $LIBC_DIR/debs/$deb_name || die "Failed to download package from $url"
    echo "  -> Extracting libc binary package"

    mkdir $LIBC_DIR/libs/$id
    extract $LIBC_DIR/debs/$deb_name $LIBC_DIR/libs/$id
    echo "  -> Package saved to $LIBC_DIR/libs/$id"

    # download debug info package
    url="$OLD_SOURCE/$dbg_name"
    echo "  -> Location: $url"
    echo "  -> Downloading libc debug package"
    sudo wget "$url" 2>/dev/null -O $LIBC_DIR/debs/$dbg_name || die "Failed to download package from $url"
    echo "  -> Extracting libc debug package"
    mkdir $LIBC_DIR/libs/$id/.debug
    extract $LIBC_DIR/debs/$dbg_name $LIBC_DIR/libs/$id/.debug
    echo "  -> Package saved to $LIBC_DIR/libs/$id/.debug"
    chlibc $filename $version $LIBC_DIR/libs/$id
    die "[+]success"
}

Record(){
    if [ -e $1.bak ];then
        cp $1.bak $1
    else
        cp $1 $1.bak
    fi
}


while getopts 's:x:hvc:e:r:' OPT
do
    case $OPT in
        s) 
        libcname=$OPTARG
        get_ver
        echo -e "\033[32mLIBC_VERSION: \033[0m"$libcversion
        ;;
        x)
        if [ "$2" = "-n" ];then
            filename=$3
            libcname=$4
            LIBC_DIR=/home/yrl/glibc-all-in-one
            SOURCE="https://mirror.tuna.tsinghua.edu.cn/ubuntu/pool/main/g/glibc"
            OLD_SOURCE="http://old-releases.ubuntu.com/ubuntu/pool/main/g/glibc"
            get_arch "$4"
            get_ver
            download_need
        else  
            filename=$2
            libcname=$3
            LIBC_DIR=/home/yrl/glibc-all-in-one
            SOURCE="https://mirror.tuna.tsinghua.edu.cn/ubuntu/pool/main/g/glibc"
            OLD_SOURCE="http://old-releases.ubuntu.com/ubuntu/pool/main/g/glibc"
            get_arch "$3"
            get_ver
            download_rpath
        fi
        ;;
        c)
        if [ "$2" = "-n" ];then
            chlibc $3 $4 $5
        else
            clibc $2 $3 $4
        fi
        ;;
        e)
        LIBC_PREFIX="libc6_"
        LIBC_DBG_PREFIX="libc6-dbg_"
        LIBC_DIR=/home/yrl/glibc-all-in-one/
        deb=$2
        fondername0=${deb#*_}
        fondername=${fondername0%.*}
        if [ -d /home/yrl/glibc-all-in-one/libs/$fondername ];then
            echo -e "[-]already exists, do overwrite"
        else
            mkdir $LIBC_DIR/libs/$fondername
            mkdir $LIBC_DIR/libs/$fondername/.debug
            echo -e "[+]create folder finish"
        fi
        if [[ $2 =~ $LIBC_DBG_PREFIX ]];then
            extract $2 $LIBC_DIR/libs/$fondername/.debug
            sudo chmod 755 -R $LIBC_DIR/libs/$fondername/.debug
        else 
            extract $2 $LIBC_DIR/libs/$fondername
            sudo chmod 755 -R $LIBC_DIR/libs/$fondername
        fi
        ;;
        r)
        if [ -e $2.bak ];then
            cp $2.bak $2
            echo -e "[+]restore!"
        else
            exit -1
        fi
        ;;
        v)
        echo "xclibc v0.6"
        echo "------------------------"
        echo "|Update based on xclibc|"
        echo "|Writen by E4L4        |"
        echo "------------------------"
        exit -1
        ;;
        h)
        echo "Usage: xclibc [OPTION]...[FILE]..."
        echo "Change the libc environment for file running."
        echo ""
        echo "  -s,[libcfile]                        see the libc file version"
        echo "  -x,<-n> [file] [libcfile]            change the libc environment,-n:by modifying --replace-needed"
        echo "  -c,<-n> [file] [version] [dir]       change the specified libc version environment,-n:by modifying --replace-needed"
        echo "  -e,[deb]                             extract the deb to the glibc-all-in-one"
        echo "  -r,[file]                            restore original file"
        echo "  -h,                                  display this help and exit"
        echo "  -v,                                  output version information and exit"
        echo ""
        echo "Examples:"
        echo "  xclibc -x pwn libc.so.6"
        echo "        switch the version environment of the libc.so.6"
        echo "  xclibc -c pwn 2.35 [Enter]"
        echo "  xclibc -c pwn 2.35 /home/pwn/glibc-all-in-one/libs/2.35-0ubuntu3_amd64"
        echo "        you can switch the libc environment where the pwn file runs to 2.35-0ubuntu3_amd64"
        exit -1
        ;;
    esac
done
```
使用前需要替换脚本中的libc库的目录路径，关于调试符号，脚本会替换本机的glibc调试符号，使用完毕后需手动恢复原始调试符号。
**用法：**
patch 某个glibc：
1. `xclibc -x pwn libc.so.6 ` 会自动识别libc版本，并且patch库中对应的版本，若库中没有，则会自动下载解压
2. `xclibc -c pwn 2.35 [Enter] ` 会列举对应大版本的所有小版本进行选择，随后`xclibc -c pwn 2.35 /home/pwn/glibc-all-in-one/libs/2.35-0ubuntu3_amd64` 进行切换libc