---
title: Binaryninja常用API总结
id: 137
date: 2024-01-09 20:09:13
auther: yrl
cover: 
excerpt: 以下是一份常用的 Binary Ninja Python API 汇总，包括常用的 BinaryView、Function、BasicBlock 等类及其属性和方法的介绍。这份总结提供了一些常用的 API，以便您更好地开始使用 Binary Ninja。BinaryViewBinaryView 类是
permalink: /archives/binaryninja-chang-yong-api-zong-jie
categories:
 - 工具使用
 - binaryninja
tags: 
 - binaryninjapythonapi
---

以下是一份常用的 Binary Ninja Python API 汇总，包括常用的 BinaryView、Function、BasicBlock 等类及其属性和方法的介绍。这份总结提供了一些常用的 API，以便您更好地开始使用 Binary Ninja。

# BinaryView
BinaryView 类是 Binary Ninja 中的最核心类之一，它提供了对二进制文件的访问和分析功能。以下是该类的一些重要属性和方法：

## 属性
- BinaryView.file.filename: 获取二进制文件的文件名。
- BinaryView.start: int: 获取二进制文件的起始地址。
- BinaryView.arch: Architecture: 获取二进制文件的架构。
- BinaryView.entry_point: int: 获取二进制文件的入口点地址。
- BinaryView.view: BinaryView: 获取当前 BinaryView 实例的原始 BinaryView 实例。

## 方法
- BinaryView.get_functions_containing(addr: int) -> Generator[Function, None, None]: 获取包含给定地址的函数列表。
- BinaryView.get_sections_at(addr: int) -> Sequence[Section]: 获取在给定地址处的所有节（section）。
- BinaryView.platform: Optional[Platform]: 获取二进制文件的操作系统平台。
- BinaryView.get_symbol_by_raw_name(name: str) -> Optional[Symbol]: 根据符号名称获取符号对象 Symbol。

# Symbol
Symbol 类表示二进制文件中的符号。以下是该类的一些重要属性和方法：

## 属性
- Symbol.type: SymbolType: 表示符号类型的枚举值（例如函数、变量等）。
- Symbol.name: str: 表示符号名称的字符串。
- Symbol.address: int: 表示符号地址的整数值。
## 方法
- Symbol.is_function() -> bool: 如果符号表示函数返回 True，否则返回 False。
- Symbol.is_imported() -> bool: 如果符号是引入的（也称为内部符号）返回 True，否则返回 False。
- Symbol.is_exported() -> bool: 如果符号是导出的（也称为外部符号）返回 True，否则返回 False。

# Function

Function 类表示二进制文件中的一个函数。以下是该类的一些重要属性和方法：

## 属性

- Function.name: str: 获取函数名称的字符串。
- Function.address: int: 获取函数起始地址的整数值。
- Function.view: BinaryView: 获取当前 Function 实例所属的 BinaryView 实例。
- Function.return_type: Type: 获取函数的返回类型的字符串。
- Function.calling_convention: CallingConvention: 获取函数的调用约定的枚举类型。

## 方法

- Function.get_high_level_il() -> Optional[HighLevelILFunction]: 获取函数的高级 IL（HLIL）对象 HighLevelILFunction。
- Function.get_basic_blocks(): -> Generator[BasicBlock, None, None]: 获取函数的所有基本块 BasicBlock。

# BasicBlock
BasicBlock 类表示一个函数中的基本块。以下是该类的一些重要属性和方法：

## 属性

- BasicBlock.start: int: 获取基本块的起始地址的整数值。
- BasicBlock.end: int: 获取基本块的结束地址的整数值。
- BasicBlock.function: Function: 获取当前 BasicBlock 实例所属的 Function 实例。

## 方法

- BasicBlock.get_disassembly_text(format: DisassemblyTextLineType) -> List[DisassemblyTextLine]: 获取基本块的反汇编文本。
- BasicBlock.get_presumed_line_number() -> int: 根据当前机器码的地址获取行号。

# HighLevelILOperation
HighLevelILOperation 枚举类型表示 HLIL 中支持的所有操作类型。以下是一些常见的操作类型：

- HighLevelILOperation.HLIL_CALL: HLIL 函数调用操作
- HighLevelILOperation.HLIL_BRANCH: HLIL 条件分支操作
- HighLevelILOperation.HLIL_RET: HLIL 函数返回操作

# HighLevelILInstruction
HighLevelILInstruction 类表示 HLIL 中的一条指令。以下是该类的一些重要属性和方法：

## 属性

- HighLevelILInstruction.operation: HighLevelILOperation: 获取当前指令的操作类型。
- HighLevelILInstruction.params: Tuple[int]: 获取当前 HLIL 指令的操作数的列表。
- HighLevelILInstruction.size: Optional[int]: 获取当前 HLIL 指令的大小（字节数）。

## 方法

- HighLevelILInstruction.get_raw(): -> ILInstruction: 获取原始的 IL 指令 ILInstruction。

# BinaryReader

BinaryReader 类允许您读取二进制数据，例如以特定字节顺序（大端或小端顺序）读取数据。以下是该类的一些重要属性和方法：

## 属性

- BinaryReader.view: BinaryView: 获取 BinaryReader 类的 BinaryView 实例。
- BinaryReader.endianness: Endianness: 获取当前 BinaryReader 实例的字节顺序。
- BinaryReader.offset: int: 获取当前要读取的流的偏移量。

## 方法

- BinaryReader.read(type: str) -> Any: 读取给定类型（例如 "int"、"short"、"long" 等）的数据。
- BinaryReader.seek(offset: int) -> None: 设置当前读取的流的偏移位置给定的偏移地址。

# BinaryWriter
BinaryWriter 类允许您根据二进制数据格式将数据写入二进制文件或内存中。以下是该类的一些重要属性和方法：

## 属性：

- BinaryWriter.view: BinaryView: 获取当前 BinaryWriter 实例的 BinaryView 实例。
- BinaryWriter.endianness: Endianness: 获取当前 BinaryWriter 实例的字节顺序。
- BinaryWriter.offset: int: 获取当前要写入数据的偏移位置。

## 方法：

- BinaryWriter.write(type: str, data: Any) -> int: 将给定类型（例如 "int"、"short"、"long" 等）的数据写入文件或内存中。
- BinaryWriter.seek(offset: int) -> None: 将当前要写入数据的偏移位置设置为给定的偏移地址。

# 参考文档

- Binary Ninja API 文档: https://api.binary.ninja/
- 示例代码库: https://github.com/Vector35/binaryninja-api/tree/dev/examples