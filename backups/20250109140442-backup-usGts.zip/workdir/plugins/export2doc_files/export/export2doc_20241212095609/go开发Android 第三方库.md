---
title: go开发Android 第三方库
id: 103
date: 2024-01-09 20:09:11
auther: yrl
cover: 
excerpt: 前言在开发项目中，有时需要在Android，ios中调用go语言的库，官方给出了gomobile这个工具来完成。go安装下载地址：https//golang.org/dl/，下载最新版本（当前最新版本是1.19.2）安装go的msi文件，安装完成后在命令提示符（cmd）中输入”go version
permalink: /archives/go%E5%BC%80%E5%8F%91android%E7%AC%AC%E4%B8%89%E6%96%B9%E5%BA%93
categories:
 - android
 - go
tags: 
 - android
 - gomobile
---

# 前言
在开发项目中，有时需要在Android，ios中调用go语言的库，官方给出了gomobile这个工具来完成。

# go安装

下载地址：https://golang.org/dl/，下载最新版本（当前最新版本是1.19.2）
安装go的msi文件，安装完成后在命令提示符（cmd）中输入”go version”校验是否安装成功（go安装时会自动配置到环境变量：$GOROOT、$GOPATH、$Path）

# 安装gomobile

`go get golang.org/x/mobile/cmd/gomobile`

# 编译gomobile

build gomobile成功后会在$GOPATH/bin目录生成gomobile可执行程序
`go build golang.org/x/mobile/cmd/gomobile`

# 初始化环境
初始化环境，自动下载安装依赖：
`gomobile init`
若提示未找到ndk，根据提示的路径把ndk包复制过去即可

# 配置Android SDK/NDK的环境变量
使用gomobile工具前需要先配置好Android SDK/NDK的环境变量。
配置ANDROID_HOME环境变量到电脑上的Android SDK目录（会自动使用SDK目录下的ndk-bundle目录作为NDK目录，使用最新的NDK版本）
配置ANDROID_NDK_HOME环境变量到NDK目录（$ANDROID_HOME和$ANDROID_NDK_HOME同时配置时，编译器会优先使用SDK/ndk-bundle目录下的NDK）

未配置环境变量提示：`gomobile: no Android NDK found in $ANDROID_HOME/ndk-bundle nor in $ANDROID_NDK_HOME`
NDK版本过低提示：`gomobile: No compiler for arm was found in the NDK (tried C:\Users\13927\AppData\Local\Android\sdk\ndk-bundle\toolchains\llvm\prebuilt\windows-x86_64\bin\armv7a-linux-androideabi16-clang). Make sure your NDK version is >= r19c. Use sdkmanager --update to update it.`

如下是我的go环境NDK环境详情：
![image-1667186996428](/upload/2022/10/image-1667186996428.png)

# bind 生成arr包和jar包
执行bind命令，后面跟上go代码所在的目录
```
 gomobile bind .\bind\test\
# 或者cd到test目录直接执行命令
 gomobile bind
 ```
 执行完命令后会在当前目录下生成一个arr包和jar包
 
# Golang开发手机应用demo
Golang开发手机应用有两种方式：原生应用开发、混合绑定开发。

## Golang原生应用开发示例(gomobile build命令)
(使用gomobile bind前，需要先配置Android SDK/NDK的环境变量)
在命令提示符（cmd）中输入命令:`go get -d golang.org/x/mobile/example/basic`，等待示例下载完成(下载到$GOPATH/src目录中)
生成apk安装包：`gomobile build -target=android golang.org/x/mobile/example/basic`，此命令会生成名为basic(目录名)的apk安装包(apk文件生成到命令提示符操作的目录中)
安装apk包到已连接的android设备:`gomobile install golang.org/x/mobile/example/basic` (类似于使用adb工具安装apk)

## 混合开发Android应用示例(gomobile bind命令)
(使用gomobile bind前，需要先配置Android SDK/NDK的环境变量)
在命令提示符（cmd）中输入命令:`go get -d golang.org/x/mobile/example/bind/…`，等待示例下载完成(下载到$GOPATH/src目录中)
生成aar包：`gomobile bind -target=android golang.org/x/mobile/example/bind/hello`，此命令会生成hello-sources.jar和hello.aar(文件生成到命令提示符操作的目录中)
导入aar包到Android工程中即可使用go中定义的相关方法
# 在android项目中导入.arr包和jar包
打开android studio，在项目中选择菜单file/new/new Module，选择要导入的jar/aar，选中刚才创建的aar文件，项目中自动生成’:hello’ Module
在需要引用Native方法的Module/build.gradle/dependencies中配置：implementation project(‘:hello’)
 ![image-1667192800797](/upload/2022/10/image-1667192800797.png)
 
# gomobile使用注意事项

- 目录结构：配置环境变量中GOPATH变量，go代码的工作目录是$GOPATH/src
1. go项目代码应放在$GOPATH/src目录下，并且代码中import包结构需和目录结构一致，包结构不一致则无法编译
1. `gomobile build/bind` 命令中的打包目录需使用相对目录(相对于$GOPATH/src)，目录地址分隔符需使用”/“(不能用”\”)
1. 例如一般开源项目的包结构：$GOAPTH/src/github.com/yourname/projectname/…
1. 打包生成的文件在命令提示符（cmd）中的操作目录下
- Go语言混合开发时要注意下，函数必须首字母大写的才能导出，否则无法导出给移动端使用

# 参考
https://blog.csdn.net/jianggehappy01/article/details/124963366
http://tblog.ehorizon.top/2019/05/28/20190528/