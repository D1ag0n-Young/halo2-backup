---
title: Ansible-高效批量运维工具
id: 159
date: 2024-01-09 20:09:14
auther: yrl
cover: 
excerpt: 批量工具ansibleansible是一个很好用的自动化运维工具、批量管理服务器的工具，它的很多功能需要自己去组合开发，最基础的就是可以批量执行命令，批量下载、上传文件等操作，当然这个依赖于ssh实现的。ansible本身是有很多模块的，每个模块都会有不同的功能，下面就简单记录下安装配置方式和在使用
permalink: /archives/2023-06-05-23-46-38
categories:
 - 工具使用
 - 运维工具
tags: 
 - ansible
---

# 批量工具ansible

ansible是一个很好用的自动化运维工具、批量管理服务器的工具，它的很多功能需要自己去组合开发，最基础的就是可以批量执行命令，批量下载、上传文件等操作，当然这个依赖于ssh实现的。

ansible本身是有很多模块的，每个模块都会有不同的功能，下面就简单记录下安装配置方式和在使用过程中涉及到的一些功能：

## 安装

ubuntu直接apt安装

```bash
sudo apt install sshpass # ssh密码会需要
sudo apt install ansible
```

默认的配置文件会在`/etc/ansible`目录下，但是高版本的ansible似乎没有,可以自己在`/etc/ansible`创建一个hosts、ansible.cfg文件。

hosts文件主要定义一些远程主机ip，可以将远程主机分组打标签，可以定义一些ssh的用户名密码等配置，这里给一个我自己的最简单的样例文件（官方配置文件太多啦）：

```hosts
#[test]
#127.0.0.1
[all]
172.35.[1:21].39
[one]
172.35.15.40
[pwnone]
172.35.1.33
#[web2]
#172.35.[1:15].14
#[pwn1]
#172.35.[1:15].11
#[pwn2]
#172.35.[1:15].12

[all:vars]
ansible_ssh_port=22
ansible_ssh_user=ubuntu
#ansible_private_key_file=Desktop/xxxi/rsa//id_rsa  
#cp /mnt/id_rsa /root/sshkey && chmod 600 /root/sshkey
#ansible_ssh_pass="123456"
ansible_ssh_pass="ubuntu123"
```

hosts定义了一些被管主机分组的ip和ssh的用户名密码
当然也可以为每个ip指定用户名密码：

```bash
[group 1]
192.168.1.100 ansible_ssh_user=root ansible_ssh_pass=123456
192.168.1.101 ansible_ssh_user=root ansible_ssh_pass=123456
```

```ansible.cfg
[defaults]
interpreter_python = /usr/bin/python3
inventory = /etc/ansible/hosts
remote_user = root
host_key_checking = False
# fork = 5 # -f 5
```
ansible.cfg定义了一些默认配置，依赖python3，inventory指定主机清单文件，remote_user远程主机名、fork线程数等。

测试：

```
root@pwnbase:~# ansible 127.0.0.1 -m ping
127.0.0.1 | SUCCESS => {
    "changed": false,
    "ping": "pong"
}
```
说明成功。

## 使用

### 查看ansible目录文件
tree /etc/ansible/
```bash
/etc/ansible/

├── ansible.cfg # 配置文件

├── hosts # 主仓库 用来存储需要管理的远程主机的相关信息

└── roles # 存放角色的目录
```
### Ansible命令参数详解

Ansible命令语法如下：
```
ansible [-i 主机文件] [-f 批次] [组名] [-m 模块名称] [-a 模块参数]

```
Ansible详细参数如下：
```
-i inventory_file——指定了主机文件，如果不指定，则默认为/etc/ansible/hosts文件，在主机文件中，定义了Ansible要控制的主机IP或域名，及其用户、密码
-f 10——表示指定开启同步进程的个数
-m module——表示Ansible要调用的模块
-a ——指定模块的参数，可以是命令等等
-sudo ——表示使用ansible获得sudo权限
-k ——表示ansible使用的SSH密码
-u username——表示指定Ansible执行的用户
-C —— 表示命令测试
```

### hosts文件

hosts文件一般存放我们的被管理主机信息。主机列表清单，也叫Inventory。所有被管理的主机都需要定义在该文件中。如果不想使用默认清单的话可以用-i选项指定自定义的清单文件，防止多人混合使用一个主机清单。如果没有定义在主机列表文件中，执行命令会提示`No hosts matched`

```bash
ansible -i hosts -m ping
```

### 查看文档

详细查看一个模块的功能，并且查看其参数，可以执行命令：

```bash
ansible-doc -s [mode]
```

## file模块

[官方文档](https://docs.ansible.com/ansible/latest/collections/ansible/builtin/file_module.html#file-module)

| 参数 | 选项/默认值 | 说明 |
|:-------|:--------|:-------|
|path/dest/name（required）| |**path参数 ：**必须参数，用于指定要操作的文件或目录，在之前版本的ansible中，使用dest参数或者name参数指定要操作的文件或目录，为了兼容之前的版本，使用dest或name也可以。|
|group|	|	文件数据复制到远程主机，设置文件属组用户信息|
|mode|	|	文件数据复制到远程主机，设置数据的权限 eg 0644 0755（或者 ‘644’ ‘755’)|
|owner||		文件数据复制到远程主机，设置文件属主用户信息|
|src|		|当state设置为link或者hard时，表示我们想要创建一个软链或者硬链，所以，我们必须指明软链或硬链链接的哪个文件，通过src参数即可指定链接源。|
|force|		|force参数 : 当state=link的时候，可配合此参数强制创建链接文件，当force=yes时，表示强制创建链接文件。不过强制创建链接文件分为三种情况。<br>情况一：当要创建的链接文件指向的源文件并不存在时，使用此参数，可以先强制创建出链接文件。<br>情况二：当要创建链接文件的目录中已经存在与链接文件同名的文件时，将force设置为yes，会将同名文件覆盖为链接文件，相当于删除同名文件，创建链接文件。<br>情况三：当要创建链接文件的目录中已经存在与链接文件同名的文件，并且链接文件指向的源文件也不存在，这时会强制替换同名文件为链接文件。|
|recurse|	yes|	当要操作的文件为目录，将 recurse 设置为 yes ，可以递归的修改目录中文件的属性。|
|state|		|state参数 ：此参数非常灵活，其对应的值需要根据情况设定。比如，我们想要在远程主机上创建/testdir/a/b目录，那么则需要设置 path=/testdir/a/b，但是，我们无法从”/testdir/a/b“这个路径看出b是一个文件还是一个目录，ansible也同样无法单单从一个字符串就知道你要创建文件还是目录，所以，我们需要通过state参数进行说明。当我们想要创建的/testdir/a/b是一个目录时，需要将state的值设置为directory，”directory”为目录之意，当它与path结合，ansible就能知道我们要操作的目标是一个目录。同理，当我们想要操作的/testdir/a/b是一个文件时，则需要将state的值设置为touch。当我们想要创建软链接文件时，需将state设置为link。想要创建硬链接文件时，需要将state设置为hard。当我们想要删除一个文件时（删除时不用区分目标是文件、目录、还是链接），则需要将state的值设置为absent，”absent”为缺席之意，当我们想让操作的目标”缺席”时，就表示我们想要删除目标。|
|state=|	absent|	如果是absent 那么目录将会被递归删除，如果是文件和软连接将会被取消|
|state=|	directory|	创建一个空目录信息|
|state=|	file|	查看指定目录信息是否存在|
|state=|	touch|	创建一个空文件信息|
|state=|	hard/link|	创建链接文件|

### 示例：

1. `state=directory `在远程主机上创建一个名为 data 的目录，如果存在则不会做操作

```bash
[root@master ~]# ansible dong -m file -a "path=/root/data state=directory"
```
2. `state=touch` 在远程主机上创建一个名为 testfile1 的文件，如果 testfile1 文件已经存在并且文件内有内容，则只会更新文件的时间戳，与 touch 命令的作用相同
```bash
[root@master ~]# ansible dong -m file -a "path=/root/data/testfile1 state=touch"
```
3. `state=link` 在远程主机上为 testfile1 文件创建软链接文件，软链接名为 linkfile1
```bash
[root@master ~]# ansible dong -m file -a "path=/root/data/linkfile1 state=link src=/root/data/testfile1"
```
4. `state=hard `在远程主机上上为 testfile1 文件创建硬链接文件，硬链接名为 hardfile2（类似于复制）
```bash
[root@master ~]# ansible dong -m file -a "path=/root/data/linkfile2 state=hard src=/root/data/testfile1"
```
在创建链接文件时，如果源文件不存在，或者链接文件与其他文件同名时，强制覆盖同名文件或者创建链接文件，参考上述 force 参数的解释。
```bash
[root@master ~]# ansible dong -m file -a "path=/root/data/linkfile3 state=link src=/root/data/123 force=yes"
[WARNING]: Cannot set fs attributes on a non-existent symlink target. follow should be set to False to avoid this.
192.168.169.161 | CHANGED => {
    "ansible_facts": {
        "discovered_interpreter_python": "/usr/bin/python"
    }, 
    "changed": true, 
    "dest": "/root/data/linkfile3", 
    "src": "/root/data/123"
}
192.168.169.162 | CHANGED => {
    "ansible_facts": {
        "discovered_interpreter_python": "/usr/bin/python"
    }, 
    "changed": true, 
    "dest": "/root/data/linkfile3", 
    "src": "/root/data/123"
}
```

## archive模块

[官方文档](https://docs.ansible.com/ansible/2.9/modules/archive_module.html#archive-module)

- 包存档
- 它与 unarchive 相反
- 默认情况下，它假定压缩源存在于目标上
- 在存档之前，它不会将源文件从本地系统复制到目标系统。
- 通过指定 remove=True，可以在归档后删除源文件。

也就是说archive和unarchive默认源文件都在目标主机上，可以在目标主机上进行压缩解压缩，可以将文件传到目标机器上压缩解压缩，但是不能从目标机器上压缩解压缩到本机。

具体参数含义可以参考官方文档，这里给出一些实例供参考：
```yml
# 压缩“/path/to/foo/”到“/path/to/foo.tgz”
- name: Compress directory /path/to/foo/ into /path/to/foo.tgz
  archive:
    path: /path/to/foo
    dest: /path/to/foo.tgz

# 将常规文件/path/to/foo压缩为/path/to/foo.gz并删除源文件
- name: Compress regular file /path/to/foo into /path/to/foo.gz and remove it
  archive:
    path: /path/to/foo
    remove: yes

# 创建/path/to/foo的zip归档文件
- name: Create a zip archive of /path/to/foo
  archive:
    path: /path/to/foo
    format: zip

# 创建多个文件的bz2存档，根目录为/path
- name: Create a bz2 archive of multiple files, rooted at /path
  archive:
    path:
    - /path/to/foo
    - /path/wong/foo
    dest: /path/file.tar.bz2
    format: bz2

# 创建globbed路径的bz2归档文件，同时排除特定的dirname
- name: Create a bz2 archive of a globbed path, while excluding specific dirnames
  archive:
    path:
    - /path/to/foo/*
    dest: /path/file.tar.bz2
    exclude_path:
    - /path/to/foo/bar
    - /path/to/foo/baz
    format: bz2

# 创建globbed路径的bz2存档，同时排除dirnames的glob
- name: Create a bz2 archive of a globbed path, while excluding a glob of dirnames
  archive:
    path:
    - /path/to/foo/*
    dest: /path/file.tar.bz2
    exclude_path:
    - /path/to/foo/ba*
    format: bz2

# 使用gzip压缩单个归档文件(例如，不要先用tar压缩它)
- name: Use gzip to compress a single archive (i.e don't archive it first with tar)
  archive:
    path: /path/to/foo/single.file
    dest: /path/file.gz
    format: gz

# 创建单个文件的tar.gz存档。
- name: Create a tar.gz archive of a single file.
  archive:
    path: /path/to/foo/single.file
    dest: /path/file.tar.gz
    format: gz
    force_archive: true

```
## unarchive模块

[官方文档](https://docs.ansible.com/ansible/latest/collections/ansible/builtin/unarchive_module.html)

示例：
```yml
- name: Extract foo.tgz into /var/lib/foo
  ansible.builtin.unarchive:
    src: foo.tgz
    dest: /var/lib/foo

- name: Unarchive a file that is already on the remote machine
  ansible.builtin.unarchive:
    src: /tmp/foo.zip
    dest: /usr/local/bin
    remote_src: yes

- name: Unarchive a file that needs to be downloaded (added in 2.0)
  ansible.builtin.unarchive:
    src: https://example.com/example.zip
    dest: /usr/local/bin
    remote_src: yes

- name: Unarchive a file with extra options
  ansible.builtin.unarchive:
    src: /tmp/foo.zip
    dest: /usr/local/bin
    extra_opts:
    - --transform
    - s/^xxx/yyy/
```
## fetch模块

从远端拉取文件到本地：

示例
```yml
- name: Store file into /tmp/fetched/host.example.com/tmp/somefile
  fetch:
    src: /tmp/somefile
    dest: /tmp/fetched

- name: Specifying a path directly
  fetch:
    src: /tmp/somefile
    dest: /tmp/prefix-{{ inventory_hostname }}
    flat: yes

- name: Specifying a destination path
  fetch:
    src: /tmp/uniquefile
    dest: /tmp/special/
    flat: yes

- name: Storing in a path relative to the playbook
  fetch:
    src: /tmp/uniquefile
    dest: special/prefix-{{ inventory_hostname }}
    flat: yes
```
## shell、command模块

一个典型的例子就是 shell 和 command 模块. 这两个模块在很多情况下都能完成同样的工作， 以下是两个模块之前的区别：

1. command 模块命令将不会使用 shell 执行. 因此, 像 $HOME 这样的变量是不可用的。还有像`<, >, |, ;, &`都将不可用。
2. shell 模块通过shell程序执行， 默认是`/bin/sh`, `<, >, |, ;, & `可用。但这样有潜在的 shell 注入风险

command 模块更安全，因为他不受用户环境的影响。 也很大的避免了潜在的 shell 注入风险

示例：
```yml
- name: Execute the command in remote shell; stdout goes to the specified file on the remote
  ansible.builtin.shell: somescript.sh >> somelog.txt

- name: Change the working directory to somedir/ before executing the command
  ansible.builtin.shell: somescript.sh >> somelog.txt
  args:
    chdir: somedir/

# You can also use the 'args' form to provide the options.
- name: This command will change the working directory to somedir/ and will only run when somedir/somelog.txt doesn't exist
  ansible.builtin.shell: somescript.sh >> somelog.txt
  args:
    chdir: somedir/
    creates: somelog.txt

# You can also use the 'cmd' parameter instead of free form format.
- name: This command will change the working directory to somedir/
  ansible.builtin.shell:
    cmd: ls -l | grep log
    chdir: somedir/

- name: Run a command that uses non-posix shell-isms (in this example /bin/sh doesn't handle redirection and wildcards together but bash does)
  ansible.builtin.shell: cat < /tmp/*txt
  args:
    executable: /bin/bash

- name: Run a command using a templated variable (always use quote filter to avoid injection)
  ansible.builtin.shell: cat {{ myfile|quote }}

# You can use shell to run other executables to perform actions inline
- name: Run expect to wait for a successful PXE boot via out-of-band CIMC
  ansible.builtin.shell: |
    set timeout 300
    spawn ssh admin@{{ cimc_host }}

    expect "password:"
    send "{{ cimc_password }}\n"

    expect "\n{{ cimc_name }}"
    send "connect host\n"

    expect "pxeboot.n12"
    send "\n"

    exit 0
  args:
    executable: /usr/bin/expect
  delegate_to: localhost
```
## 示例

eg：实现从远端服务器将固定目录下所有文件保存到本地以ip命名的特定目录下，并解压：

`ansible-playbook`剧本模式，可以使用ansible各个模块组合实现一系列操作，`ansible-playbook getfile.yml `即可使用。

```yml
- name: Fetch files from remote servers and save to local directory
  hosts: pwnone
  vars:
    rank: 1
    file_name: ""
    target_dir: "/home/pwnbase/remotefile"
    remote_dir: "/home/ctf/challenge"
  tasks:
    - name: compress files on remote server
      archive:
        path: "{{ remote_dir }}/{{ file_name }}"
        dest: /tmp/files.zip
        format: zip
    - name: Fetch file from remote server
      fetch:
        src: /tmp/files.zip
        dest: "{{ target_dir }}/{{ rank }}/{{ inventory_hostname }}/"
        flat: yes
      #delegate_to: localhost
    - name: remove temporary file on remote server
      file:
        path: /tmp/files.zip
        state: absent
```
```bash
#!/bin/bash
if [ "$1" ];then
  ansible-playbook getfile.yml
  # 查找目标目录下的zip文件
  find $1 -name "*.zip" -type f | while read zip_file; do
    # 计算zip文件所在的目录
    dir=$(dirname "${zip_file}")
    
    # 解压缩zip文件到同目录下
    unzip -q "${zip_file}" -d "${dir}"
  done
else
  echo "useage ./unzip.sh floder_path"
fi
```
```bash
➜  ~ tree remotefile
remotefile
└── 1
    ├── 10.30.16.60
    │   ├── files.zip
    │   └── gogogo
    └── 10.30.16.90
        ├── files.zip
        └── share
```

## 中文文档

[模块简介-翻译版](https://blog.csdn.net/weixin_44762073?type=blog)