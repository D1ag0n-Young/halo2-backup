---
title: C libray Run Anywhere - Cosmopolitan
id: 120
date: 2024-01-09 20:09:12
auther: yrl
cover: 
excerpt: 前言做2022nctf遇到一个题目是用cosmopolitan编译的，说是可以在任何平台甚至DOS都能运行的程序，赛后来总结下相关知识Cosmopolitan官方的说法，它可以实现像java一样可以跨平台运行，但厉害的是他不像java一样需要解释器或者虚拟机运行，他是编译成可执行程序直接在本地跑的，
permalink: /archives/clibrayrunanywhere-cosmopolitan
categories:
 - re知识点
tags: 
 - cosmopolitan
 - runanywhere
---

# 前言

做2022nctf遇到一个题目是用cosmopolitan编译的，说是可以在任何平台甚至DOS都能运行的程序，赛后来总结下相关知识

# Cosmopolitan

官方的说法，它可以实现像java一样可以跨平台运行，但厉害的是他不像java一样需要解释器或者虚拟机运行，他是编译成可执行程序直接在本地跑的，可以说性能要优越于用gcc编译的c/c++、go等程序。

## cosmopolitan安装

```bash
wget https://justine.lol/cosmopolitan/cosmopolitan-amalgamation-2.2.zip
unzip cosmopolitan-amalgamation-2.2.zip
printf 'main() { printf("hello world\\n"); }\n' >hello.c
gcc -g -Os -static -nostdlib -nostdinc -fno-pie -no-pie -mno-red-zone \
  -fno-omit-frame-pointer -pg -mnop-mcount -mno-tls-direct-seg-refs -gdwarf-4 \
  -o hello.com.dbg hello.c -fuse-ld=bfd -Wl,-T,ape.lds -Wl,--gc-sections \
  -include cosmopolitan.h crt.o ape-no-modify-self.o cosmopolitan.a
objcopy -S -O binary hello.com.dbg hello.com
```
这个是编译好的们可以直接用。hello编译完成之后会生成如下几个文件：
```bash
hello.com
hello.com.dbg
hello.c
```
`hello.com`、`hello.com.dbg`一个是跨平台的去了符号表的可执行程序，一个是带有符号表的程序，看一下文件格式：
```bash
➜  cosmopolitan-amalgamation-2.2 file hello.com           
hello.com: DOS/MBR boot sector; partition 1 : ID=0x7f, active, start-CHS (0x0,0,1), end-CHS (0x3ff,255,63), startsector 0, 4294967295 sectors
```
当然项目中还说了，你可以将这个跨平台的文件转换成当前系统的可执行文件，只需要加上`--assimilate`即可
```bash
➜  cosmopolitan-amalgamation-2.2 file hello.com                  
hello.com: DOS/MBR boot sector; partition 1 : ID=0x7f, active, start-CHS (0x0,0,1), end-CHS (0x3ff,255,63), startsector 0, 4294967295 sectors
➜  cosmopolitan-amalgamation-2.2 bash                            
d1ag0n@d1ag0n-virtual-machine:~/cosmopolitan-amalgamation-2.2$ ./hello.com --assimilate
d1ag0n@d1ag0n-virtual-machine:~/cosmopolitan-amalgamation-2.2$ file hello.com
hello.com: ELF 64-bit LSB executable, x86-64, version 1 (FreeBSD), for OpenBSD, statically linked, no section header
```
看到已经变回elf格式了，这里要注意当前shell最好是**原生bash的shell**，虽然官方说是用`bash -c cmd`的形式可以运行，但是最好不要用zsh，不然很可能运行不起来程序或者转换格式失败。
[项目地址](https://github.com/jart/cosmopolitan)

## 调试

### gdb调试跨平台二进制程序
官方给了gdb的配置，需要加到`~/.gdbinit`中或者在gdb界面手动`source gdbscript.gdb`导入脚本：
```
set host-charset UTF-8
set target-charset UTF-8
set target-wide-charset UTF-8
set osabi none
set complaints 0
set confirm off
set history save on
set history filename ~/.gdb_history
define asm
  layout asm
  layout reg
end
define src
  layout src
  layout reg
end
src

```
是用如下命令加载符号表（假如有的话）
```bash
gdb hello.com -ex 'add-symbol-file hello.com.dbg 0x401000'
```
这里我经过测试peda和pwndbg插件都调试不了跨平台程序，只有gef可以勉强单步调试，但是显示有问题。原生gdb是可以调试的，所以可以使用原生gdb进行调试。

### ida调试
当然也可以像之前的elf一样远程是用ida进行调试

以上两种方法均可以实现对程序的调试，当然也可以直接转换成对应平台的可执行文件进行调试，更方便。

# nctf题目-just run it

[just run it](https://github.com/X1cT34m/NCTF2022/blob/main/Reverse/just_run_it.tar.gz)

[官方wp](https://mp.weixin.qq.com/s/h4-qnsEAP8DaWHy9G-X5_A)