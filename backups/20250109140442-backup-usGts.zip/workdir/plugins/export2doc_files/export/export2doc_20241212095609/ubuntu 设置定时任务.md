---
title: ubuntu 设置定时任务
id: 65
date: 2024-01-09 20:09:11
auther: yrl
cover: 
excerpt: 编辑定时任务sudo crontab -e格式*****cmd分钟小时日月周命令1-59；每分钟*或*/1表示0-231-311-120-6(0为周如)cmd示例*/30表示每30(分钟/小时/日/月/周)，如下：每30分钟执行脚本backup.sh： */30 * * * * /home/bac
permalink: /archives/ubuntu-she-zhi-ding-shi-ren-wu
categories:
 - linux服务
 - linux
tags: 
---

# 编辑定时任务

`sudo crontab -e`
## 格式

| *                         | *    | *    | *    | *            | cmd  |
| ------------------------- | ---- | ---- | ---- | ------------ | ---- |
| 分钟                      | 小时 | 日   | 月   | 周           | 命令 |
| 1-59；每分钟:`*`或`*/1`表示 | 0-23 | 1-31 | 1-12 | 0-6(0为周如) | cmd  |

## 示例

1. `*/30`表示每30(分钟/小时/日/月/周)，如下：
每30分钟执行脚本backup.sh：` */30 * * * * /home/backup.sh`
2. `,`表示列举，如下：
每月的1、10、22号的4点30分重启apache：`30 4 1,10,22 * * /usr/local/etc/rc.d/lighttpd restart`
3. `-`表示时间段内，如下：
每天的18到23点之间每隔30分钟重启apache：`0,30 18-23 * * * /usr/local/etc/rc.d/lighttpd restart`
4. mon-wed代表周一到周三、jan代表一月等

# 重启定时服务

`sudo service cron restart`

# 相关命令

以下是 crontab 的有效选项:

`crontab –e` : 修改 crontab 文件. 如果文件不存在会自动创建。 
`crontab –l` : 显示 crontab 文件。 
`crontab -r` : 删除 crontab 文件。
`crontab -ir `: 删除 crontab 文件前提醒用户。







