---
title: CTF多附件生成脚本
id: 116
date: 2024-01-09 20:09:11
auther: yrl
cover: 
excerpt: 前言用于ctf中多附件快速生成exe/ELF#codingutf8import osimport uuidimport timedef gen_flag(flag,idx)   if not flag.startswith(&#39;flag{&#39;)      raise Excepti
permalink: /archives/ctf%E5%A4%9A%E9%99%84%E4%BB%B6%E7%94%9F%E6%88%90%E8%84%9A%E6%9C%AC
categories:
 - ctf
 - useful
tags: 
 - 多附件生成脚本
---

# 前言

用于ctf中多附件快速生成。

# exe/ELF

```python
#coding:utf8
import os
import uuid
import time

def gen_flag(flag,idx):
   if not flag.startswith('flag{'):
      raise Exception('flag format error')

   f = open('./1000Click.exe','rb')
   content = bytearray(f.read())
   f.close()

   key0_key = str(content[0x1c2568:0x1c2568+38])
   #raw_input()
   
   content[0x1c2568:0x1c2568+38] = flag.encode()
   
   key0_key = str(content[0x1c2568:0x1c2568+38])
   #raw_input()
   print(key0_key)

   f = open('1000Click%d.exe' % idx,'wb')
   f.write(content)
   f.close()
   
for i in range(1,20):
   flag = str(uuid.uuid4()).replace('-','')
   flag = 'flag{%s}' % flag
   print(flag)
   if len(flag) != 38:
      raise Exception('Error')
   gen_flag(flag,i)
   f = open('flag%d.txt' % i,'w')
   f.write(flag)
   f.close()
```
# android

```python
#coding:utf8
from Crypto.Cipher import ARC4
from binascii import b2a_hex, a2b_hex
from Crypto.Cipher import AES
import os
import uuid
import time

def myRC4(data,key):
  rc41 = ARC4.new(key)
  encrypted = rc41.encrypt(data)
  return encrypted

def pad(data):
    pad_data = data
    for i in range(0,16-len(data)):
        pad_data = pad_data + ' '
    return pad_data

def encrypt(key,text):
    text = pad(text)
    cryptos = AES.new(key=key, mode=AES.MODE_ECB)
    cipher_text = cryptos.encrypt(text)
    return cipher_text

def gen_flag(flag,idx):
   if not flag.startswith('flag{'):
      raise Exception('flag format error')
   flag = flag[5:]
   os.system('unzip keygen.apk lib/armeabi-v7a/libkeygen.so -d %d' % idx)
   f = open('%d/lib/armeabi-v7a/libkeygen.so' % idx,'rb')
   content = bytearray(f.read())
   f.close()

   key0 = 'qwntcTf_2022_wel'
   key0_key = str(content[0x7748+1:0x7748+1+0x100])

   flag_key = myRC4(key0,key0_key)
   flag0 = encrypt(flag_key,flag[0:16])

   key1 = 'haVE_FuN_1234567'
   key1_key = str(content[0x185C+1:0x185C+1+0x100])

   flag_key = myRC4(key1,key1_key)
   flag1 = encrypt(flag_key,flag[16:32])

   content[0x1339c:0x1339c+16] = flag0
   content[0x133ad:0x133ad+16] = flag1

   f = open('%d/lib/armeabi-v7a/libkeygen.so' % idx,'wb')
   f.write(content)
   f.close()
   output = 'keygen%d.apk' % idx
   os.system('./update.sh %d %s' % (idx,output))

for i in range(1,16):
   flag = str(uuid.uuid4()).replace('-','')
   flag = 'flag{%s}' % flag
   if len(flag) != 38:
      raise Exception('Error')
   gen_flag(flag,i)
   f = open('flag%d.txt' % i,'w')
   f.write(flag)
   f.close()

```