---
title: Chunk Extend/Overlapping
id: 104
date: 2024-01-09 20:09:11
auther: yrl
cover: 
excerpt: chunk_extend/overlapping在了解堆的基础知识后自己有没有想过在堆中可能存在问题。比如两个chunk有没有可能重合？什么场景可以导致堆块的重合？那么接下就展开说说chunk_extend/overlapping的具体情况。Chunk Extend and Overlappingc
permalink: /archives/chunkextendoverlapping
categories:
 - ctf
 - pwn入门教程
tags: 
 - pwn
---

# chunk_extend/overlapping

在了解堆的基础知识后自己有没有想过在堆中可能存在问题。比如两个chunk有没有可能重合？什么场景可以导致堆块的重合？那么接下就展开说说chunk_extend/overlapping的具体情况。

## Chunk Extend and Overlapping

chunk extend是在漏洞利用过程中非常常用的一种手法，通过extend最终达到chunk overlapping的效果，当然利用需要一些条件，如下：

- 存在堆的漏洞
- 堆的漏洞能够控制chunk的size位

下面给出几个可以导致chunk extend的基本示例，可以供大家参考

## 对正在使用的fastbin进行extend

示例代码如下：

```c
//gcc -g fastbin_extend.c -o fastbin_extend
#include<stdio.h>
int main(void)
{
    void *p, *p1;
    p = malloc(0x10);//分配第一个0x10的chunk
    malloc(0x10);//分配第二个0x10的chunk
    *(long long *)((long long)p - 0x8) = 0x41;// 修改第一个块的size域
    free(p);
    p1 = malloc(0x30);// 实现extend，控制了第二个块的内容
    return 0;
}

```

使用`gcc -g fastbin_extend.c -o fastbin_extend`编译源码,`-g`添加了源码调试，我们可以看一下调试过程中chunk是如何变化的

```
pwndbg>  x/16gx 0x0000000000602000
0x602000:	0x0000000000000000	0x0000000000000021   <---chunk1
0x602010:	0x0000000000000000	0x0000000000000000
0x602020:	0x0000000000000000	0x0000000000000021   <---chunk2
0x602030:	0x0000000000000000	0x0000000000000000
0x602040:	0x0000000000000000	0x0000000000020fc1   <---top
```

堆块的结构分为prev_size、size内容，拿上面这个64位程序举例：malloc(0x10)其中的0x10指得是内容部分申请0x10大小的空间，prev_size和size部分各占8个字节，size记录的是整个堆块的大小，并且size的最后一位用来记录前一个块的状态，所以size = 0x8(prev_size) + 0x8(size) + 0x10(内容) + 0x1(标志位) = 0x21

可以看到第一个申请的0x10的chunk1在0x602000位置，size为0x21。第二个申请的0x10的chunk2在0x602020的位置，size为0x21。接下来我们执行`*(long long *)((long long)p - 0x8) = 0x41`后看看这个位置两个块有什么变化：

```
pwndbg>  x/16gx 0x0000000000602000
0x602000:	0x0000000000000000	0x0000000000000041   <---chunk1
0x602010:	0x0000000000000000	0x0000000000000000
0x602020:	0x0000000000000000	0x0000000000000021   <---chunk2
0x602030:	0x0000000000000000	0x0000000000000000
0x602040:	0x0000000000000000	0x0000000000020fc1   <---top
```
`*(long long *)((long long)p - 0x8) = 0x41`将chunk1的size位修改为0x41（实际可以由堆相关的漏洞来实现），这样一来，chunk1的大小变大了，大到完全可以覆盖chunk2，也就是说chunk1和chunk2同时指向了0x602020这块内存，那么此时将chunk1释放掉会怎么样呢？我们接着往下走，执行完`free(p);`之后，如下：

```
pwndbg> x/16gx 0x602000
0x602000:	0x0000000000000000	0x0000000000000041   <---chunk1
0x602010:	0x0000000000000000	0x0000000000000000
0x602020:	0x0000000000000000	0x0000000000000021   <---chunk2
0x602030:	0x0000000000000000	0x0000000000000000
0x602040:	0x0000000000000000	0x0000000000020fc1   <---top


pwndbg> heapinfo
(0x20)     fastbin[0]: 0x0
(0x30)     fastbin[1]: 0x0
(0x40)     fastbin[2]: 0x602000 --> 0x0
(0x50)     fastbin[3]: 0x0
(0x60)     fastbin[4]: 0x0
(0x70)     fastbin[5]: 0x0
(0x80)     fastbin[6]: 0x0
(0x90)     fastbin[7]: 0x0
(0xa0)     fastbin[8]: 0x0
(0xb0)     fastbin[9]: 0x0
                  top: 0x602040 (size : 0x20fc0) 
       last_remainder: 0x0 (size : 0x0) 
            unsortbin: 0x0

```
执行完chunk1被释放到fastbin中，大小是0x40，说明确实chunk2所在的内存也被chunk1连带释放掉了，也就是说假如现在申请0x30大小的chunk，刚好把0x602000申请出去，记为chunk3，那么chunk3和chunk2就会有一部分内存重合，chunk3和chunk2都可以对其进行操作。再假如此时chunk2是free状态的，那么chunk3就可以控制free链表中的地址，实现任意地址的申请。

## 对正在使用的smallbin进行extend

```c
//gcc -g smallbin_extend.c -o smallbin_extend
#include<stdio.h>
int main(void)
{
    void *p, *p1;
    p = malloc(0x80);//分配第一个0x80的chunk
    malloc(0x10);//分配第二个0x10的chunk
    malloc(0x10);//防止top chunk合并
    *(long long *)((long long)p - 0x8) = 0xb1;// 修改第一个块的size域
    free(p);
    p1 = malloc(0xa0);
}

```

通过调试我们来看看具体的堆块变化，首先申请三个chunk，chunk分布如下：
```
pwndbg> x/30gx 0x602000
0x602000:	0x0000000000000000	0x0000000000000091    <---chunk1
0x602010:	0x0000000000000000	0x0000000000000000
0x602020:	0x0000000000000000	0x0000000000000000
0x602030:	0x0000000000000000	0x0000000000000000
0x602040:	0x0000000000000000	0x0000000000000000
0x602050:	0x0000000000000000	0x0000000000000000
0x602060:	0x0000000000000000	0x0000000000000000
0x602070:	0x0000000000000000	0x0000000000000000
0x602080:	0x0000000000000000	0x0000000000000000
0x602090:	0x0000000000000000	0x0000000000000021   <---chunk2
0x6020a0:	0x0000000000000000	0x0000000000000000
0x6020b0:	0x0000000000000000	0x0000000000000021   <---chunk3
0x6020c0:	0x0000000000000000	0x0000000000000000
0x6020d0:	0x0000000000000000	0x0000000000020f31   <---topchunk

```

执行`*(long long *)((long long)p - 0x8) = 0xb1;`,修改chunk1的size位为0xb1，将chunk1的大小拓展到chunk2，大小为0xb0，此时显然chunk1和chunk2重合了，接着释放chunk1，如下：

```
pwndbg> x/30gx 0x602000
0x602000:	0x0000000000000000	0x00000000000000b1   <---chunk1
0x602010:	0x0000000000000000	0x0000000000000000
0x602020:	0x0000000000000000	0x0000000000000000
0x602030:	0x0000000000000000	0x0000000000000000
0x602040:	0x0000000000000000	0x0000000000000000
0x602050:	0x0000000000000000	0x0000000000000000
0x602060:	0x0000000000000000	0x0000000000000000
0x602070:	0x0000000000000000	0x0000000000000000
0x602080:	0x0000000000000000	0x0000000000000000
0x602090:	0x0000000000000000	0x0000000000000021
0x6020a0:	0x0000000000000000	0x0000000000000000
0x6020b0:	0x0000000000000000	0x0000000000000020   <---chunk3
0x6020c0:	0x0000000000000000	0x0000000000000000
0x6020d0:	0x0000000000000000	0x0000000000020f31

pwndbg> heapinfo
(0x20)     fastbin[0]: 0x0
(0x30)     fastbin[1]: 0x0
(0x40)     fastbin[2]: 0x0
(0x50)     fastbin[3]: 0x0
(0x60)     fastbin[4]: 0x0
(0x70)     fastbin[5]: 0x0
(0x80)     fastbin[6]: 0x0
(0x90)     fastbin[7]: 0x0
(0xa0)     fastbin[8]: 0x0
(0xb0)     fastbin[9]: 0x0
                  top: 0x6020d0 (size : 0x20f30) 
       last_remainder: 0x0 (size : 0x0) 
            unsortbin: 0x602000 (size : 0xb0)  <--- free chunk
```

这里解释一下为什么进的是unsortbin，有两种情况下可以进unsortbin：

- 当一个较大的 chunk 被分割成两半后，如果剩下的部分大于 MINSIZE，就会被放到 unsorted bin 中
- 释放一个不属于 fast bin 的 chunk，并且该 chunk 不和 top chunk 紧邻时，该 chunk 会被首先放到 unsorted bin 中

很显然我们这个例子就满足第二种情况，不属于fastbin中的空闲块，并且不和top chunk相邻。因为chunk1和chunk2合并之后的chunk的大小超过了fast bin的最大接收值，所以不进fast bin，并且chunk3的size标志位变成了0，证明前一个块chunk1是一个释放的状态。接下来再次申请一个0xa0大小的chunk，记为chunk4（chunk1），会从unsort bin中申请，此时chunk4包含chunk2，这样一来再次对chunk4进行操作，从而达到控制chunk2的目的。

## 对free状态的smallbin进行extend

```c
//gcc -o free_smallbin_extend free_smallbin_extend.c -g
#include<stdio.h>
int main()
{
    void *p, *p1;
    p = malloc(0x80);//分配第一个 0x80 的chunk1
    malloc(0x10); //分配第二个 0x10 的chunk2
    free(p);//释放,chunk1进入unsortedbin
    *(long *)((long)p-0x8) = 0xb1;
    p1 = malloc(0xa0);
}

```

还是通过调试来观察chunk的变化，首先malloc两个chunk，如下：

```
pwndbg> x/30gx 0x602000
0x602000:	0x0000000000000000	0x0000000000000091    <---chunk1
0x602010:	0x0000000000000000	0x0000000000000000
0x602020:	0x0000000000000000	0x0000000000000000
0x602030:	0x0000000000000000	0x0000000000000000
0x602040:	0x0000000000000000	0x0000000000000000
0x602050:	0x0000000000000000	0x0000000000000000
0x602060:	0x0000000000000000	0x0000000000000000
0x602070:	0x0000000000000000	0x0000000000000000
0x602080:	0x0000000000000000	0x0000000000000000
0x602090:	0x0000000000000000	0x0000000000000021   <---chunk2
0x6020a0:	0x0000000000000000	0x0000000000000000
0x6020b0:	0x0000000000000000	0x0000000000020f51   <---topchunk
0x6020c0:	0x0000000000000000	0x0000000000000000
 
```
`n`执行`free(p);`,对chunk1进行释放，如下：
```
pwndbg> x/30gx  0x602000
0x602000:	0x0000000000000000	0x0000000000000091   <---freed chunk1
0x602010:	0x00007ffff7dd1b78	0x00007ffff7dd1b78
0x602020:	0x0000000000000000	0x0000000000000000
0x602030:	0x0000000000000000	0x0000000000000000
0x602040:	0x0000000000000000	0x0000000000000000
0x602050:	0x0000000000000000	0x0000000000000000
0x602060:	0x0000000000000000	0x0000000000000000
0x602070:	0x0000000000000000	0x0000000000000000
0x602080:	0x0000000000000000	0x0000000000000000
0x602090:	0x0000000000000090	0x0000000000000020
0x6020a0:	0x0000000000000000	0x0000000000000000
0x6020b0:	0x0000000000000000	0x0000000000020f51
0x6020c0:	0x0000000000000000	0x0000000000000000
0x6020d0:	0x0000000000000000	0x0000000000000000
0x6020e0:	0x0000000000000000	0x0000000000000000
pwndbg> heapinfo
(0x20)     fastbin[0]: 0x0
(0x30)     fastbin[1]: 0x0
(0x40)     fastbin[2]: 0x0
(0x50)     fastbin[3]: 0x0
(0x60)     fastbin[4]: 0x0
(0x70)     fastbin[5]: 0x0
(0x80)     fastbin[6]: 0x0
(0x90)     fastbin[7]: 0x0
(0xa0)     fastbin[8]: 0x0
(0xb0)     fastbin[9]: 0x0
                  top: 0x6020b0 (size : 0x20f50) 
       last_remainder: 0x0 (size : 0x0) 
            unsortbin: 0x602000 (size : 0x90)   <----free chunk

```
可以看到chunk1确实进入到了unsortedbin，chunk2的inuse位变为0，接下来我们对free状态下的chunk修改他的size大小为0xb1，`n`执行`*(long *)((long)p-0x8) = 0xb1;`，
```
pwndbg> x/30gx  0x602000
0x602000:	0x0000000000000000	0x00000000000000b1   <--- chunk1 size = 0xb1
0x602010:	0x00007ffff7dd1b78	0x00007ffff7dd1b78
0x602020:	0x0000000000000000	0x0000000000000000
0x602030:	0x0000000000000000	0x0000000000000000
0x602040:	0x0000000000000000	0x0000000000000000
0x602050:	0x0000000000000000	0x0000000000000000
0x602060:	0x0000000000000000	0x0000000000000000
0x602070:	0x0000000000000000	0x0000000000000000
0x602080:	0x0000000000000000	0x0000000000000000
0x602090:	0x0000000000000090	0x0000000000000020
0x6020a0:	0x0000000000000000	0x0000000000000000
0x6020b0:	0x0000000000000000	0x0000000000020f51
0x6020c0:	0x0000000000000000	0x0000000000000000
0x6020d0:	0x0000000000000000	0x0000000000000000
0x6020e0:	0x0000000000000000	0x0000000000000000
pwndbg> heapinfo
(0x20)     fastbin[0]: 0x0
(0x30)     fastbin[1]: 0x0
(0x40)     fastbin[2]: 0x0
(0x50)     fastbin[3]: 0x0
(0x60)     fastbin[4]: 0x0
(0x70)     fastbin[5]: 0x0
(0x80)     fastbin[6]: 0x0
(0x90)     fastbin[7]: 0x0
(0xa0)     fastbin[8]: 0x0
(0xb0)     fastbin[9]: 0x0
                  top: 0x6020b0 (size : 0x20f50) 
       last_remainder: 0x0 (size : 0x0) 
            unsortbin: 0x602000 (size : 0xb0)  <---大小跟着改变

```
看到各个bin中的存放的是堆块的首地址，大小还是由chunk的size来决定；chunk再次`n`执行malloc操作，结果如下:

```
pwndbg> x/30gx  0x602000
0x602000:	0x0000000000000000	0x00000000000000b1   <---new chunk3
0x602010:	0x00007ffff7dd1b78	0x00007ffff7dd1b78
0x602020:	0x0000000000000000	0x0000000000000000
0x602030:	0x0000000000000000	0x0000000000000000
0x602040:	0x0000000000000000	0x0000000000000000
0x602050:	0x0000000000000000	0x0000000000000000
0x602060:	0x0000000000000000	0x0000000000000000
0x602070:	0x0000000000000000	0x0000000000000000
0x602080:	0x0000000000000000	0x0000000000000000
0x602090:	0x0000000000000090	0x0000000000000020   <---chunk2
0x6020a0:	0x0000000000000000	0x0000000000000000
0x6020b0:	0x0000000000000000	0x0000000000020f51
0x6020c0:	0x0000000000000000	0x0000000000000000
0x6020d0:	0x0000000000000000	0x0000000000000000
0x6020e0:	0x0000000000000000	0x0000000000000000
pwndbg> heapinfo
(0x20)     fastbin[0]: 0x0
(0x30)     fastbin[1]: 0x0
(0x40)     fastbin[2]: 0x0
(0x50)     fastbin[3]: 0x0
(0x60)     fastbin[4]: 0x0
(0x70)     fastbin[5]: 0x0
(0x80)     fastbin[6]: 0x0
(0x90)     fastbin[7]: 0x0
(0xa0)     fastbin[8]: 0x0
(0xb0)     fastbin[9]: 0x0
                  top: 0x6020b0 (size : 0x20f50) 
       last_remainder: 0x0 (size : 0x0) 
            unsortbin: 0x0    <---chunk被申请出去

```
被申请的chunk记为chunk3，可见此时chunk3已经包含了chunk2，也就是说可以实现通过chunk3来控制chunk2的目的。

## extend向后overlapping

这里说的向后指的是向高地址，这里展示先通过extend向后overlapping，这也是经常遇到的情况，通过堆块重合来实现一些其他的漏洞利用。

```c
//ggcc -o bck_overlapping bck_overlapping.c -g
#include<stdio.h>
int main()
{
    void *p, *p1;
    p = malloc(0x10);//分配第一个 0x10 的chunk1
    malloc(0x10); //分配第二个 0x10 的chunk2
    malloc(0x10); //分配第三个 0x10 的chunk3
    malloc(0x10); //分配第四个 0x10 的chunk4
    *(long *)((long)p-0x8) = 0x61;
    free(p);
    p1 = malloc(0x50);
}

```
首先申请4个chunk，然后修改chunk1的size为0x61，此时会造成chunk1和chunk2、chunk3重合，如果将chunk1释放掉，他会进入fastbin，
```
pwndbg> heapinfo
(0x20)     fastbin[0]: 0x0
(0x30)     fastbin[1]: 0x0
(0x40)     fastbin[2]: 0x0
(0x50)     fastbin[3]: 0x0
(0x60)     fastbin[4]: 0x602000 --> 0x0      <---free chunk
(0x70)     fastbin[5]: 0x0
(0x80)     fastbin[6]: 0x0
(0x90)     fastbin[7]: 0x0
(0xa0)     fastbin[8]: 0x0
(0xb0)     fastbin[9]: 0x0
                  top: 0x602080 (size : 0x20f80) 
       last_remainder: 0x0 (size : 0x0) 
            unsortbin: 0x0

```
再次申请0x50的chunk将其申请回来，此时已经构成堆块的重叠，即chunk overlapping;因为chunk2、chunk3都还可以被申请和释放，加入释放掉chunk2，那么可以通过chunk overlapping来控制chunk2->fd指针，从而达到fastbin attack的效果。

## extend向前overlapping

这里说的向后指的是向低地址，主要是通过控制chunk的prev_size和prev_inuse来实现合并相邻低地址的堆块：

```c
//gcc -o fd_extend fd_extend.c -g
#include<stdio.h>
int main(void)
{
    void *p1, *p2, *p3, *p4;
    p1 = malloc(0x80);//smallbin1
    p2 = malloc(0x10);//fastbin1
    p3 = malloc(0x10);//fastbin2
    p4 = malloc(0x80);//smallbin2
    malloc(0x10);//防止与top合并
    free(p1);
    *(int *)((long long)p4 - 0x8) = 0x90;//修改pre_inuse域
    *(int *)((long long)p4 - 0x10) = 0xd0;//修改pre_size域
    free(p4);//unlink进行前向extend
    malloc(0x150);//占位块
}

```

首先，我们申请5个chunk，大小分别是0x80、0x10、0x10、0x80、0x10，如下：
```
pwndbg> parseheap 
addr                prev                size                 status              fd                bk                
0x602000            0x0                 0x90                 Used                None              None <--p1
0x602090            0x0                 0x20                 Used                None              None <--p2
0x6020b0            0x0                 0x20                 Used                None              None <--p3
0x6020d0            0x0                 0x90                 Used                None              None <--p4
0x602160            0x0                 0x20                 Used                None              None

```
将p1释放掉，同时将p4的prev_size改为p1+p2+p3的大小（0xd0），prev_inuse改为0标识低地址处相邻chunk是free状态，如下：

```
pwndbg> parseheap 
addr                prev                size                 status              fd                bk                
0x602000            0x0                 0x90                 Freed     0x7ffff7dd1b78    0x7ffff7dd1b78
0x602090            0x90                0x20                 Used                None              None
0x6020b0            0x0                 0x20                 Freed                0x0               0x0
0x6020d0            0xd0                0x90                 Used                None              None
0x602160            0x0                 0x20                 Used                None              None

```
此时释放p4，根据smallbin的unlink原则，它会检测相邻的chunk是否是free状态的，如果是就会根据prev_size的大小来合并相邻的chunk,如下：

```
pwndbg> parseheap 
addr                prev                size                 status              fd                bk                
0x602000            0x0                 0x160                Freed     0x7ffff7dd1b78    0x7ffff7dd1b78
0x602160            0x160               0x20                 Used                None              None

```
可以看到p2、p3已经被合并到新的free块（记为p5）中了，如上图的0x602000内存块中，此时就造成了p5和p2、p3的堆块重叠，可以实现通过p5来控制p2、p3的目的了。

## 例题

[HITCON Trainging lab13](https://github.com/ctf-wiki/ctf-challenges/tree/master/pwn/heap/chunk-extend-shrink/hitcontraning_lab13)

