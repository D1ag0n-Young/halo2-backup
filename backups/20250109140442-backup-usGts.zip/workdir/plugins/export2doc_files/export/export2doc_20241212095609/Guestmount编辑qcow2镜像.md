---
title: Guestmount编辑qcow2镜像
id: 101
date: 2024-01-09 20:09:11
auther: yrl
cover: 
excerpt: 
permalink: /archives/guestmount-bian-ji-qcow2-jing-xiang
categories:
 - linux
tags: 
 - qcow2
---

# 安装gusetmount
guestmount工具包含在libguestfs工具集内，所以先执行 yum install libguestfs libguestfs-tools -y安装

# 使用
`guestmount -a <qcow2镜像文件> -m <镜像内的磁盘分区> <宿主机上的挂载目录>`

挂在前也可以用`virt-filesystems`工具来查看镜像里的磁盘分区信息
```
$ virt-filesystems -a centos7.qcow2 
/dev/sda1
/dev/sda3
```

# 挂载
sudo到root用户下执行
```
# guestmount -a centos7.qcow2 -m /dev/sda3 /mnt
libguestfs: error: could not create appliance through libvirt.


Try running qemu directly without libvirt using this environment variable:
export LIBGUESTFS_BACKEND=direct


Original error from libvirt: Cannot access storage file '/root/centos7.qcow2' (as uid:52479, gid:52479): Permission denied [code=38 int1=13]
```
报上面的错，是因为libvirt环境异常，按提示执行下面的语句
```
# export LIBGUESTFS_BACKEND=direct
```
再重新执行guestmount，命令行执行成功
```
# guestmount -a centos7.qcow2 -m /dev/sda3 /mnt
```
这时，centos7.qcow2的/dev/sda3分区就挂载到宿主机的/mnt目录了，cd /mnt/进去后可以看到镜像文件里的文件系统，接下来就可以对里面的文件进行改写了
```
# cd /mnt/
# ls
bin  boot  dev  etc  home  lib  lib64  lost+found  media  mnt  opt  proc  root  run  sbin  srv  sys  tmp  usr  var
```
按需要改写，比如我当时的一个需求是在镜像里增加ttyS1设备
```
# echo ttyS1 >> etc/securetty
# 修改 boot/grub2/grub.cfg 
```
完成后，卸载
```
# guestunmount /mnt
```