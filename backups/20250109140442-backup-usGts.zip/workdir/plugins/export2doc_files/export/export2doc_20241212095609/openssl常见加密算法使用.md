---
title: openssl常见加密算法使用
id: 105
date: 2024-01-09 20:09:11
auther: yrl
cover: 
excerpt: openssl MD5#include &lt;openssl/md5.h&gt;#include &lt;stdio.h&gt;#include &lt;string.h&gt;void md5hexToString(unsigned char *md,char *result){    // c
permalink: /archives/openssl-chang-jian-jia-mi-suan-fa-shi-yong
categories:
 - useful
 - cc
tags: 
 - 密码
---

# openssl MD5

```c
#include <openssl/md5.h>
#include <stdio.h>
#include <string.h>
void md5hexToString(unsigned char *md,char *result){
    // char tmp[3];
    for (size_t i = 0; i <= 15; i++){
        sprintf(result+i*2,"%02x",md[i]);
    }
    return;
}
int main(int argc, char const *argv[])
{	
    //存储md5的hex结果
    unsigned char md[16] = {0};
    //存储hex对应的字符串结果
    char result[33] = {0};
    
    MD5_CTX c;
    MD5_Init(&c);
    MD5_Update(&c,"helloworld1",strlen("helloworld1"));
    MD5_Final(md,&c);
    
    md5hexToString(md,result);
    printf("%s",result);
    return 0;
}

```