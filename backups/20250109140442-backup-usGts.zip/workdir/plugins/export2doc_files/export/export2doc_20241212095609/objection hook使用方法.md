---
title: objection hook使用方法
id: 883dc267-16f5-4ba6-9e26-6ff1f8bfa28b
date: 2024-06-05 11:50:37
auther: yrl
cover: 
excerpt: objection hook 简单说就是把frida客户端的功能使用python封装成工具，一些基本的hook操作可以快速使用命令行实现，如hook java层的函数参数、返回值、调用栈、内存漫游等操的集成 安装 pip3 install objection 如下返回则安装成功 shell # 
permalink: /archives/objection_hook
categories:
 - 工具使用
tags: 
 - hook
 - objection
---

# objection hook

简单说就是把frida客户端的功能使用python封装成工具，一些基本的hook操作可以快速使用命令行实现，如hook java层的函数参数、返回值、调用栈、内存漫游等操的集成

## 安装

```bash
pip3 install objection

```
如下返回则安装成功
```
shell # objection version
objection: 1.11.0
```

## 使用方法

首先确保frida、frida-server安装成功，且两者版本匹配，在模拟器或真机上将frida-server运行起来后，在pc端运行
```
objection -g com.xxx.xxx explore
```
会进入objection终端，可以执行hook命令

## 常用功能命令

### 启动相关

```bash
#列出手机里安装的所有应用
frida-ps -U
#使用objection注入“xxx”应用
objection -g com.piaoyou.piaoxing explore
#启动objection，同时执行--startup-command指定的命令
objection -g com.piaoyou.piaoxing explore --startup-command "android hooking watch class_method java.io.File.$init  --dump-args"
objection -g com.piaoyou.piaoxing explore -s "android hooking watch class_method java.io.File.$init --dump-args --dump-return"
#启动objection，同时执行-c指定的文件，文件里包含多条objection命令，文件中一行就是一条objection命令
objection -g com.piaoyou.piaoxing explore -c "d:/hook/objection-command.txt"
#启动objection，同时执行-S指定的文件，文件里包含的是frida脚本
objection -g com.piaoyou.piaoxing explore -S "d:/hook/frida-hook.js"

objection -N -h IP地址 -p 端口号 -g 包名 explore    # 指定ip和端口的连接
 
# spawn启动前就Hook某个类
objection -N -h 192.168.1.3 -p 9999 -g 包名 explore --startup-command "android hooking watch class '包名.类名'"
 
# spawn启动前就Hook某个方法打印参数、返回值、函数调用栈
objection -N -h 192.168.1.3 -p 9999 -g 包名 explore --startup-command "android hooking watch class_method '包名.类名.方法' --dump-args --dump-return --dump-backtrace"
```

### 内置命令

```bash
# Memory 指令
memory list modules									

#枚举当前进程模块
memory list exports [lib_name]							#查看指定模块的导出函数
memory list exports libart.so --json /root/libart.json	#将结果保存到json文件中
memory search --string --offsets-only					#搜索内存
    
# activity 和 service 操作
android hooking list activities					#枚举activity
android intent launch_activity [activity_class]	#启动activity
android hooking list services					#枚举services
android intent launch_service [services_class]	#启动services

# android heap 指令
android heap search instances com.xx.xx.class	#堆内存中搜索指定类的实例, 可以获取该类的实例id
android heap execute [ins_id] [func_name]		#直接调用指定实例下的方法
android heap evaluate [ins_id]					#自定义frida脚本, 执行实例的方法

# android 指令
android root disable				#尝试关闭app的root检测
android root simulate				#尝试模拟root环境
android ui screenshot [image.png]	#截图
android ui FLAG_SECURE false		#设置FLAG_SECURE权限

# 内存漫游
android hooking list classes					#列出内存中所有的类[search_name]	#在内存中所有已加载的类中搜索包含特定关键词的类
android hooking search methods [search_name]	#在内存中所有已加载的方法中搜索包含特定关键词的方法
android hooking generate simple [class_name]	#直接生成hook代码

# hook方法
android hooking watch class com.xxx.xxx			#hook指定类, 会打印该类下的所有调用
# hook指定方法, 如果有重载会hook所有重载，打印详细信息通过下面参数：
# --dump-args : 打印参数
# --dump-backtrace : 打印调用栈
# --dump-return : 打印返回值
android hooking watch class_method com.xxx.xxx.methodName --dump-args --dump-backtrace --dump-return
android hooking set return_value com.xxx.xxx.methodName false	#设置返回值(只支持bool类型)

# 任务管理器
jobs list			#查看任务列表
jobs kill [task_id]	#关闭任务

# 抓包
android sslpinning disable	#关闭ssl校验

# 执行命令行
android shell_exec [command]

#查看内存中加载的库
memory list modules
#查看库的导出函数
memory list exports libssl.so
#将结果保存到json文件中
memory list exports libart.so --json /root/libart.json  
#搜索是否存在着该类的实例
android heap search instances java.net.HttpURLConnection
#调用实例的方法,0x2526是上一个命令输出的实例的hashcode
android heap execute 0x2526 getPreferenceScreenResId
#在实例上执行js代码，输入以下命令后，会进入一个迷你编辑器环境，输入console.log("evaluate result:"+clazz.getPreferenceScreenResId())这串脚本，按ESC退出编辑器，然后按回车，即会开始执行这串脚本，输出结果
android heap evaluate 0x2526
#列出内存中所有的类
android hooking list classes
#内存中搜索所有的类
android hooking search classes RealCall
#内存中搜索所有的方法
android hooking search methods display
#列出类的所有方法
android hooking list class_methods com.android.org.conscrypt.OpenSSLSocketImpl
#直接生成hook代码，参数没有填上，还是需要自己后续补充
android hooking generate simple com.android.org.conscrypt.OpenSSLSocketImpl
#hook类的所有方法，在使用jobs list命令可以看到objection为我们创建的Hooks数，也就是将com.android.org.conscrypt.OpenSSLSocketImpl类下的所有方法都hook了
android hooking watch com.android.org.conscrypt.OpenSSLSocketImpl
#hook方法的参数、返回值和调用栈
android hooking watch class_method android.bluetooth.BluetoothDevice.getName --dump-args --dump-return --dump-backtrace

#直接将SSL pinning给disable掉
android sslpinning disable
#用File类的构造器
android hooking watch class_method java.io.File.$init --dump-args
#查看内存中加载的os库
memory list modules
#查看库的导出函数
memory list exports libssl.so
#将结果保存到json文件中
memory list exports libart.so --json /root/libart.json  
#导入外部js脚本并执行,frida_hook.js需要上传到pwd输出的目录，或者其他目录
import frida_hook.js

#直接启动activity
android intent launch_activity com.android.settings.DisplaySettings
#查看当前可用的activity
android hooking list activities
```