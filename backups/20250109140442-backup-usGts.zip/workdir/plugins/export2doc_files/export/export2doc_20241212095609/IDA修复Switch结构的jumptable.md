---
title: IDA修复Switch结构的jumptable
id: 108
date: 2024-01-09 20:09:11
auther: yrl
cover: 
excerpt: 前言在逆向的过程中经常出现ida反编译的switch结构异常，如何恢复原来的switch呢？如下：  while ( 1 )  {    __isoc99_scanf(&amp;unk_2004, &amp;v4, envp);    if ( v4 &lt;= 5 )      break;   
permalink: /archives/ida%E4%BF%AE%E5%A4%8Dswitch%E7%BB%93%E6%9E%84%E7%9A%84jumptable
categories:
 - 工具使用
 - ida
tags: 
 - ida
---

# 前言

在逆向的过程中经常出现ida反编译的switch结构异常，如何恢复原来的switch呢？如下：
```c
  while ( 1 )
  {
    __isoc99_scanf(&unk_2004, &v4, envp);
    if ( v4 <= 5 )
      break;
    printf("what's your input?");
  }
  __asm { jmp     rax }
  return result;
```
# 编译器优化switch原理

出于对代码执行效率的考虑，编译器会对源程序中的 switch 语句进行优化，而这种优化可能导致 IDA Pro 工具无法正确理解程序中的 switch 语句，从而影响我们进行逆向分析。编译器对 switch 语句的优化按照 case labels 是否紧凑和连续分为多种情况，本文只讨论 case labels 紧凑连续时被优化成跳转表的情况。

本文中所使用的环境为：
- OS：Ubuntu 20.04 amd64
- GCC：gcc version 9.4.0 
- IDA Pro: 7.5 for Windows

我们先来看一个例子,看看他是怎么被编译器优化的，例子有6个分支（包含默认分支）如下:
```c
#include <stdio.h>

int main() {
    int input;
    while (1) {
        scanf("%d", &input);
        switch(input) {
            case 1:
                printf("your input is 1");
                break;
            case 2:
                printf("your input is 2");
                break;
            case 3:
                printf("your input is 3");
                break;
            case 4:
                printf("your input is 4");
                break;
            case 5:
                printf("your input is 5");
                break;
            default:
                printf("what's your input?");
        }
    }
}
```
`gcc -S switch.c`可获得汇编代码，如下，可以看到最上面的`.LC0-.LC6`是程序相关的字符串的标识，我们可以根据这个标识定位switch的case，接着是main函数的汇编代码，从`__isoc99_scanf`之后就是switch的开头，最后根据跳转表jmp到各个case；接着就是跳转表了，跳转表中定义了 6 个 .long 类型（4 字节）的数据，每一个数据的值都是 Ln-L4 这样的形式，不难推测出跳转表中存储的是 6 个 case 对应目标代码与跳转表之间的相对偏移；标签 L8、L7、L6、L5、L3、L2 处分别对应 6 个 case 的目标代码，其中 L2 标签是 default case 的情况。可以看到，程序汇编代码从上到下分别是字符串常量、main代码、跳转表、switch分支。

```asm
	.file	"switch.c"
	.text
	.section	.rodata
; --------------------
;     字符串常量定义    
; --------------------
.LC0:
	.string	"%d"
.LC1:
	.string	"your input is 1"
.LC2:
	.string	"your input is 2"
.LC3:
	.string	"your input is 3"
.LC4:
	.string	"your input is 4"
.LC5:
	.string	"your input is 5"
.LC6:
	.string	"what's your input?"
	.text
	.globl	main
	.type	main, @function

; --------------------
;     main 函数代码    
; --------------------

main:
.LFB0:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%fs:40, %rax
	movq	%rax, -8(%rbp)
	xorl	%eax, %eax
.L10:					; 由于 while(1)循环，程序的结尾会跳回 L10 标签
	leaq	-12(%rbp), %rax
	movq	%rax, %rsi
	leaq	.LC0(%rip), %rdi
	movl	$0, %eax
	call	__isoc99_scanf@PLT
	movl	-12(%rbp), %eax	; switch 语句的第一条指令
	cmpl	$5, %eax
	ja	.L2			; 如果输入值大于 5 则跳转到 L2，即 default case
	movl	%eax, %eax
	leaq	0(,%rax,4), %rdx	; rdx <- &(ds:[rax*4])
	leaq	.L4(%rip), %rax	; rax <- &(rip + .L4) 跳转表地址
	movl	(%rdx,%rax), %eax	; eax <- [rax + rdx] 取出跳转表中元素
	cltq				; 将 4 字节带符号扩展为 8 字节（Convert Long To Quad）
					; rax <- sign-extend of eax
	leaq	.L4(%rip), %rdx	; rdx <- &(rip + .L4) 跳转表地址
	addq	%rdx, %rax		; rax <- rax + rdx 计算得到跳转目标地址
	notrack jmp	*%rax		; 跳转到目标地址
	.section	.rodata
	.align 4
	.align 4
.L4:
	.long	.L2-.L4		; 跳转表，每一个元素字长是 4 字节,存储的是各个case相对于L4的偏移
	.long	.L8-.L4
	.long	.L7-.L4
	.long	.L6-.L4
	.long	.L5-.L4
	.long	.L3-.L4
	.text
.L8:
	leaq	.LC1(%rip), %rdi	; case 1 入口
	movl	$0, %eax
	call	printf@PLT
	jmp	.L9
.L7:
	leaq	.LC2(%rip), %rdi	; case 2 入口
	movl	$0, %eax
	call	printf@PLT
	jmp	.L9
.L6:
	leaq	.LC3(%rip), %rdi	; case 3 入口
	movl	$0, %eax
	call	printf@PLT
	jmp	.L9
.L5:
	leaq	.LC4(%rip), %rdi	; case 4 入口
	movl	$0, %eax
	call	printf@PLT
	jmp	.L9
.L3:
	leaq	.LC5(%rip), %rdi	; case 5 入口
	movl	$0, %eax
	call	printf@PLT
	jmp	.L9
.L2:
	leaq	.LC6(%rip), %rdi	; default 入口
	movl	$0, %eax
	call	printf@PLT
.L9:
	jmp	.L10			; while(1)
	.cfi_endproc
.LFE0:
	.size	main, .-main
	.ident	"GCC: (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	 1f - 0f
	.long	 4f - 1f
	.long	 5
0:
	.string	 "GNU"
1:
	.align 8
	.long	 0xc0000002
	.long	 3f - 2f
2:
	.long	 0x3
3:
	.align 8
4:
```

接着我们来阅读一下 main 函数中的关键代码，在 main 函数中，调用完 scanf 函数之后，就开始了 switch 语句的部分（ida恢复结构时比较重要），首先从栈中取出 input 变量放到 eax 寄存器中，对输入进行判断，如果大于 5 则跳出到 L2 标签（default case），否则继续向下执行。这里注意，跳转的时候很巧妙地用了ja（Jump Above）这个指令，它把操作数都当做无符号数进行比较，也就是说，如果取到 eax 寄存器里的是一个负值，比如 -1，即 0xffffffff，是远大于 5 的，所以同样会跳出到 L2 标签。

然后程序把数据段 rax*4 得到的地址放到 rdx 寄存器中，rax是我们输入的case，这实际上就是跳转表的索引；接着将跳转表地址取到 rdx 寄存器中，取出跳转表中元素的值放到 eax 寄存器并带符号扩展为 8 个字节。之后取跳转表基址到 rdx 寄存器，两者相加得到跳转目标的地址。

# IDA 中恢复 switch 语句

首先，将我们的例子编译成elf文件，`gcc -o switch switch.c ` 生成switch文件。使用 IDA 加载程序，反汇编得到的代码如下，汇编代码除指令格式外，基本和switch.s相同。可以注意到 0x11c8 地址处有一个 `db 3Eh` 没有被解析，这实际上就是 notrack 指令，IDA暂不能识别出这个指令，不过没有任何影响。

```asm
.text:0000000000001197                 call    ___isoc99_scanf
.text:000000000000119C                 mov     eax, [rbp+var_C]
.text:000000000000119F                 cmp     eax, 5
.text:00000000000011A2                 ja      loc_122A
.text:00000000000011A8                 mov     eax, eax
.text:00000000000011AA                 lea     rdx, ds:0[rax*4]
.text:00000000000011B2                 lea     rax, unk_206C
.text:00000000000011B9                 mov     eax, [rdx+rax]
.text:00000000000011BC                 cdqe
.text:00000000000011BE                 lea     rdx, unk_206C
.text:00000000000011C5                 add     rax, rdx
.text:00000000000011C8                 db      3Eh
.text:00000000000011C8                 jmp     rax
.text:00000000000011CB ; ---------------------------------------------------------------------------
.text:00000000000011CB                 lea     rdi, aYourInputIs1 ; "your input is 1"
.text:00000000000011D2                 mov     eax, 0
.text:00000000000011D7                 call    _printf
.text:00000000000011DC                 jmp     short loc_123B
.text:00000000000011DE ; ---------------------------------------------------------------------------
.text:00000000000011DE                 lea     rdi, aYourInputIs2 ; "your input is 2"
.text:00000000000011E5                 mov     eax, 0
.text:00000000000011EA                 call    _printf
.text:00000000000011EF                 jmp     short loc_123B
.text:00000000000011F1 ; ---------------------------------------------------------------------------
.text:00000000000011F1                 lea     rdi, aYourInputIs3 ; "your input is 3"
.text:00000000000011F8                 mov     eax, 0
.text:00000000000011FD                 call    _printf
.text:0000000000001202                 jmp     short loc_123B
.text:0000000000001204 ; ---------------------------------------------------------------------------
.text:0000000000001204                 lea     rdi, aYourInputIs4 ; "your input is 4"
.text:000000000000120B                 mov     eax, 0
.text:0000000000001210                 call    _printf
.text:0000000000001215                 jmp     short loc_123B
.text:0000000000001217 ; ---------------------------------------------------------------------------
.text:0000000000001217                 lea     rdi, aYourInputIs5 ; "your input is 5"
.text:000000000000121E                 mov     eax, 0
.text:0000000000001223                 call    _printf
.text:0000000000001228                 jmp     short loc_123B
.text:000000000000122A ; ---------------------------------------------------------------------------
.text:000000000000122A
.text:000000000000122A loc_122A:                               ; CODE XREF: main+39↑j
.text:000000000000122A                 lea     rdi, format     ; "what's your input?"
.text:0000000000001231                 mov     eax, 0
.text:0000000000001236                 call    _printf
.text:000000000000123B
.text:000000000000123B loc_123B:                               ; CODE XREF: main+73↑j
.text:000000000000123B                                         ; main+86↑j ...
.text:000000000000123B                 jmp     loc_1184
.text:000000000000123B ; } // starts at 1169
.text:000000000000123B main            endp

```
可以看到unk_206C是跳转表的地址，数据如下：
```
.rodata:000000000000206C byte_206C       db 0BEh                 ; DATA XREF: main+49↑o
.rodata:000000000000206C                                         ; main+55↑o
.rodata:000000000000206D                 db 0F1h
.rodata:000000000000206E                 db 0FFh
.rodata:000000000000206F                 db 0FFh
.rodata:0000000000002070                 db  5Fh ; _
.rodata:0000000000002071                 db 0F1h
.rodata:0000000000002072                 db 0FFh
.rodata:0000000000002073                 db 0FFh
.rodata:0000000000002074                 db  72h ; r
.rodata:0000000000002075                 db 0F1h
.rodata:0000000000002076                 db 0FFh
.rodata:0000000000002077                 db 0FFh
.rodata:0000000000002078                 db  85h
.rodata:0000000000002079                 db 0F1h
.rodata:000000000000207A                 db 0FFh
.rodata:000000000000207B                 db 0FFh
.rodata:000000000000207C                 db  98h
.rodata:000000000000207D                 db 0F1h
.rodata:000000000000207E                 db 0FFh
.rodata:000000000000207F                 db 0FFh
.rodata:0000000000002080                 db 0ABh
.rodata:0000000000002081                 db 0F1h
.rodata:0000000000002082                 db 0FFh
.rodata:0000000000002083                 db 0FFh
.rodata:0000000000002083 _rodata         ends
```
这里可以下改一下显示格式，尽量接近switch.s的形式，首先把数据变成4字节dd形式：
```
.rodata:000000000000206C dword_206C      dd 0FFFFF1BEh, 0FFFFF15Fh, 0FFFFF172h, 0FFFFF185h
.rodata:000000000000206C                                         ; DATA XREF: main+49↑o
.rodata:000000000000206C                                         ; main+55↑o
.rodata:000000000000206C                 dd 0FFFFF198h, 0FFFFF1ABh
```
ida修改数据类型：`Edit` -> `Operand type` -> `Offset` -> `Offset (user-defined)`，`Base address` 填入跳转表自身的地址 0x206c
![image](/upload/2022/11/image.png)

```
.rodata:000000000000206C off_206C        dd offset loc_122A - $, offset loc_11CB - $, offset loc_11DE - $, offset loc_11F1 - $
.rodata:000000000000206C                                         ; DATA XREF: main+49↑o
.rodata:000000000000206C                                         ; main+55↑o
.rodata:000000000000206C                 dd offset loc_1204 - $, offset loc_1217 - $
.rodata:000000000000206C _rodata         ends
```
可以看到数据都变成了各个case相对于跳转表的偏移，此操作可选，这里只是为了更清晰的看到跳转表的格式。

进入正题，怎么恢复跳转表呢？ida提供了`Specify switch idiom`功能恢复出 switch 语句。将光标点在 switch 语句的起始地址 0x119c 处，点击 `Edit` -> `Other` -> `Specify switch idiom`，配置如下：
![image-1668671687226](/upload/2022/11/image-1668671687226.png)

参数解释：

- Address of jump table：跳转表的地址。
- Number of elements：跳转表中元素的个数。
- Size of table element：跳转表中每个元素的字长（1/2/4/8）。
- Element shift amount：一般情况下保持默认的 0 即可。除非跳转表中存储的元素并不是跳转的目标地址，而是需要通过 `target = base +/- (table_element << shift)` 这个公式计算得出，这种情况需要作为 shift 的值提供。
- Element base value：与` Address of jump table` 保持相同的值，对应上述公式中的 base。
- Start of the switch idiom：switch 语句的首个指令的地址（比如上面例子中的 0x199c），在打开`Specify switch idiom`窗口时，光标处的地址会被自动填写到这里，这就是前面把光标点在地址 0x199c 处的原因。
- Input register of switch：存储 switch 语句输入的寄存器，即存储 `switch(input) {...} `中input变量的寄存器。
- First(lowest) input value：最小的 case 值，比如 case 有 1、2、3、4、5，则填写 0，因为 default 占用了 case 0。
- Default jump address：default case 的跳转目标地址，可以不指定，不指定时对于 default case 以 case 0 的形式显示。
- Signed jump table elements：跳转表中的元素是有符号值时需要勾选。
- Subtract table elements：计算跳转表元素时用减法而不是用加法。
- Table element is insn：跳转表中存储的不是目标地址而直接是指令时需要勾选。

恢复完如下：
```
int __cdecl main(int argc, const char **argv, const char **envp)
{
  int v4; // [rsp+4h] [rbp-Ch] BYREF
  unsigned __int64 v5; // [rsp+8h] [rbp-8h]

  v5 = __readfsqword(0x28u);
  while ( 1 )
  {
    switch ( (unsigned int)__isoc99_scanf(&unk_2004, &v4, envp) )
    {
      case 1u:
        printf("your input is 1");
        break;
      case 2u:
        printf("your input is 2");
        break;
      case 3u:
        printf("your input is 3");
        break;
      case 4u:
        printf("your input is 4");
        break;
      case 5u:
        printf("your input is 5");
        break;
      default:
        printf("what's your input?");
        break;
    }
  }
}
```