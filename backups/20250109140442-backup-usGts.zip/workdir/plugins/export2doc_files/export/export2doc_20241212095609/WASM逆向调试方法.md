---
title: WASM逆向调试方法
id: 110
date: 2024-01-09 20:09:11
auther: yrl
cover: 
excerpt: 前言比赛做题过程中发现WASM的逆向题越来越常见，所以大概看一下WASM怎么去逆向。什么是WASM？WebAssembly是什么？WebAssembly即WASM， WebAssembly是一种新的编码格式并且可以在浏览器中运行，WASM可以与JavaScript并存，WASM更类似一种低级的汇编语
permalink: /archives/wasm%E9%80%86%E5%90%91%E8%B0%83%E8%AF%95%E6%96%B9%E6%B3%95
categories:
 - wasm
tags: 
 - wasm反编译
---

# 前言

比赛做题过程中发现WASM的逆向题越来越常见，所以大概看一下WASM怎么去逆向。

# 什么是WASM？

WebAssembly是什么？WebAssembly即WASM， WebAssembly是一种新的编码格式并且可以在浏览器中运行，WASM可以与JavaScript并存，WASM更类似一种低级的汇编语言。

WebAssembly（又名wasm）是一种高效的，低级别的编程语言。 它让我们能够使用JavaScript以外的语言（例如C，C ++，Rust或其他）编写程序，然后将其编译成WebAssembly，进而生成一个加载和执行速度非常快的Web应用程序。

Wasm 具有运行高效、内存安全、无未定义行为和平台独立等特点，经过了编译器和标准化团队多年耕耘，目前已经有了成熟的社区。

# 用C/C++生成wasm

## 安装emcc
首先要安装官方推荐方式，先下载 emsdk:
```
git clone https://github.com/emscripten-core/emsdk.git
cd emsdk
# 下载并安装最新的 SDK 工具.
./emsdk install latest
# 为当前用户激活最新的 SDK. (写入 .emscripten 配置文件)
./emsdk activate latest
# 激活当前 PATH 环境变量
source ./emsdk_env.sh
```
注意在Windows上运行emsdk，而不是`./emsdk`；emsdk_env.bat而不是`source ./emsdk_env.sh`
会安装`sdk-release-upstream, node.js `等，因为是从
`https://storage.googleapis.com/ `上下载相应的软件包，如果您因网络原因不能直接访问这个域名，则可能需要设置代理下载。

注意：`source ./emsdk_env.sh`只是在当前终端有效，每次使用需要重新运行该命令，官方建议使用此方式，因为依赖东西较多，如果依赖的东西路径变了可能导致使用异常。


## 验证安装

```
➜  wasmtest emcc -v                                     
emcc (Emscripten gcc/clang-like replacement + linker emulating GNU ld) 3.1.25 (febd44b21ecaca86e2cb2a25ef3ed4a0a2076365)
clang version 16.0.0 (https://github.com/llvm/llvm-project effd75bda4b1a9b26e554c1cda3e3b4c72fa0aa8)
Target: wasm32-unknown-emscripten
Thread model: posix

```
即安装成功。

## 示例测试（helloWorld）

首先C/C++写一个例子：
```
# include <stdio.h>
# include <string.h>

int main() {
    printf("hello world！input:");
    char name[20];
    scanf("%s",name);
    if (!strcmp(name,"flag")){
    	printf("you are good！\n");
    }else{
    	printf("fuck！\n");
    }
    return 0;
}
```
**编译**
可以分别以以下两种情况进行编译：
1. 第一种情况：`emcc hello.c`
2. 第二种情况：`emcc -O2 hello.c -o hello.wasm`
感受一下差异。

[在线编译工具](https://mbebenita.github.io/WasmExplorer/)
### 情况1

编译默认会生成一个2500多行的JavaScript文件 a.out.js和一个可反编译成文本wat格式的近1万行代码的 a.out.wasm 文件. 是太了点，不过不用怕，后面我们会告诉你如何让他们变小。
a.out.js是一坨胶水，用来在不同条件下为wasm搭建一个执行环境。先不管他究竟是啥，先试试运行看看：
```
➜  node a.out.js
hello world！input:fuck！
```
### 情况2

emcc有两个常用的编译参数，`-O/o`,  `O `指定优化级别，`o `指定输出文件和类型。
优化级别有 `-O0, -O1, -O2, -O3 -Os`这五种级别。不指定视为 `-O0`, 即没有优化，开发时一般指定为 `-O0` 或 `-O1`， 这样编译速度快，调试方便。 正式发布时可以是 `-O2 `或 `-O3`，这时代码会优化，执行更快。`-Os` 不光是执行快，同时优化大小，可生成更小的执行文件。
`emcc -o `选项指定输出文件类型有： `js`，`wasm` 和 `html`。
让我们来试试生成html:
`emcc -o hello.html hello.c`
这回会生成三个文件： hello.html, hello.js, hello.wasm

### 运行

python开启http服务：`python3 -m http.server 8000`

浏览器访问`http://127.0.0.1:8000/hello.html`
![image-1668700261230](/upload/2022/11/image-1668700261230.png)

# 反编译及调试WASM

## 静态反编译
反编译WASM有几种方式，官方提供有工具、ida、jeb、ghidra。

### 官方工具
官方提供的工具是[wabt-ubuntu](https://github.com/WebAssembly/wabt/releases/download/1.0.31/wabt-1.0.31-ubuntu.tar.gz)、
[wabt-win](https://github.com/WebAssembly/wabt/releases/download/1.0.31/wabt-1.0.31-windows.tar.gz)
wabt/bin/下有各种工具，可以将wasm文件反编译成c文件、.o文件、wat格式的文件：
```bash
wasm2c wasm.wasm -o wasm.c  #反编译成c
wasm2wat wasm.wasm -o wasm.wat #反编译成wasm字节码
wasm-decompile wasm.wasm -o wasm.o #反编译成wasm汇编代码
```
但是这些工具反编译出来的体量太大，很难看出程序逻辑。所以这里我选择强大的JEB4支持的WASM反编译。

### JEB反编译
[JEB4](https://pan.baidu.com/s/1W5FxPb8BvX1W9F6pIe23KA?pwd=wvwq)只需要替换jeb.jar即可，认证选择在线认证即可。

JEB4支持wasm的静态反编译，但是反编译的结果并不能像反编译c那样准确直观，如下：
![image-1668701745459](/upload/2022/11/image-1668701745459.png)
但是仍能辅助我们理解逻辑。
### ghidra反编译

通过ghidra的[ghidra-wasm-plugin](https://github.com/nneonneo/ghidra-wasm-plugin/releases/tag/v2.0.0)插件可以实现对wasm的反编译。将插件放到ghidra的插件拓展目录下即可。注意下载的插件版本要和ghidra的版本一致。

插件目录`$ghidrahome/Extensions/Ghidra`，插件zip包不需要解压，放到目录后，在ghidra菜单->Install Extensions中勾选，并重启ghidra。

## patch-wasm

如果想patch wasm的字节码，在ghidra中`ctrl+shift+G` patch好之后,将光标放到patch的指令上（如果有多条指令，可以选择其实地址和size进行指定）
![image-1671048525238](/upload/2022/12/image-1671048525238.png)
运行Save_Patch.py脚本(点击绿色按钮，选择脚本)即可将patch后的文件保存。

注：脚本需要放到固定目录`$userhome\ghidra_scripts`	，也可以新添加一个你自己的脚本目录。
![image-1671048745144](/upload/2022/12/image-1671048745144.png)
脚本[下载地址](https://github.com/schlafwandler/ghidra_SavePatch)

## 动态调试
我们可以通过动态调试wasm字节码来理解算法逻辑，python开启http服务，F12之后在wasm源代码下断点即可动态调试。
![image-1668702078666](/upload/2022/11/image-1668702078666.png)

调试过程中注意观察作用域下的var变量，如果是指针，value就是变量地址，如果是立即数，value就是立即数的值；当知道地址后，在模块->memories->memory->buffer下对应地址去寻找数据。数据分为int8、uint8、int16、int32四种类型，可按需选择。
![image-1668702290304](/upload/2022/11/image-1668702290304.png)
如此可根据jeb和动态调试来理解程序逻辑。

# WASM字节码

调试过程中应该大概了解WASM字节码含义，函数参数设置，常见如下：
```
    i32.const 48
    local.set $var1

    i32.const 1116
    local.set $var17
```
给var变量赋值，函数调用从左到右依次给变量赋值：
```
    i32.const 1069
    local.set $var13
    local.get $var12
    local.get $var13
    call $func14
```
含义为func14(var12,var13),需要注意的是**JEB反编译参数的顺序和真正的相反**
```
i32.add  //+
i32.xor  // ^
i32.sub // -

i32.eqz //相等则跳转label
br_if $label0
```
其他可参考x86汇编相关。

# 参考题目

2022RCTF-分站赛RE题目[webrun](https://gitee.com/yrlgitee/competition/blob/master/2022RCTF/webrun.zip)
[webrun WP]()