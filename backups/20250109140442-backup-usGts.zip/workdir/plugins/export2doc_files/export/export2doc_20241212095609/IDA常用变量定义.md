---
title: IDA常用变量定义
id: 114
date: 2024-01-09 20:09:11
auther: yrl
cover: 
excerpt: ida变量定义ida反编译生成的伪代码是比较准确的，甚至都可以拿来直接运行，但是ida本身存在很多他自己的宏定义的数据结构，导致直接复制到VS中报错，所以我这里记录了一个常用的ida的变量宏定义，会不断的补充。typedef unsigned char   uint8;typedef unsigne
permalink: /archives/ida-chang-yong-bian-liang-ding-yi
categories:
 - ida
tags: 
 - ida
---

# ida变量定义

ida反编译生成的伪代码是比较准确的，甚至都可以拿来直接运行，但是ida本身存在很多他自己的宏定义的数据结构，导致直接复制到VS中报错，所以我这里记录了一个常用的ida的变量宏定义，会不断的补充。可以将下面内容作为header.h加入到项目中。

```c
/*

   This file contains definitions used by the Hex-Rays decompiler output.
   It has type definitions and convenience macros to make the
   output more readable.

   Copyright (c) 2007-2011 Hex-Rays

*/

#if defined(__GNUC__)
  typedef          long long ll;
  typedef unsigned long long ull;
  #define __int64 long long
  #define __int32 int
  #define __int16 short
  #define __int8  char
  #define MAKELL(num) num ## LL
  #define FMT_64 "ll"
#elif defined(_MSC_VER)
  typedef          __int64 ll;
  typedef unsigned __int64 ull;
  #define MAKELL(num) num ## i64
  #define FMT_64 "I64"
#elif defined (__BORLANDC__)
  typedef          __int64 ll;
  typedef unsigned __int64 ull;
  #define MAKELL(num) num ## i64
  #define FMT_64 "L"
#else
  #error "unknown compiler"
#endif
typedef unsigned int uint;
typedef unsigned char uchar;
typedef unsigned short ushort;
typedef unsigned long ulong;

typedef          char   int8;
typedef   signed char   sint8;
typedef unsigned char   uint8;
typedef          short  int16;
typedef   signed short  sint16;
typedef unsigned short  uint16;
typedef          int    int32;
typedef   signed int    sint32;
typedef unsigned int    uint32;
typedef ll              int64;
typedef ll              sint64;
typedef ull             uint64;

// Partially defined types:
#define _BYTE  uint8
#define _WORD  uint16
#define _DWORD uint32
#define _QWORD uint64
#if !defined(_MSC_VER)
#define _LONGLONG __int128
#endif

#ifndef _WINDOWS_
typedef int8 BYTE;
typedef int16 WORD;
typedef int32 DWORD;
typedef int32 LONG;
#endif
typedef int64 QWORD;
#ifndef __cplusplus
typedef int bool;       // we want to use bool in our C programs
#endif

// Some convenience macros to make partial accesses nicer
// first unsigned macros:
#define LOBYTE(x)   (*((_BYTE*)&(x)))   // low byte
#define LOWORD(x)   (*((_WORD*)&(x)))   // low word
#define LODWORD(x)  (*((_DWORD*)&(x)))  // low dword
#define HIBYTE(x)   (*((_BYTE*)&(x)+1))
#define HIWORD(x)   (*((_WORD*)&(x)+1))
#define HIDWORD(x)  (*((_DWORD*)&(x)+1))
#define BYTEn(x, n)   (*((_BYTE*)&(x)+n))
#define WORDn(x, n)   (*((_WORD*)&(x)+n))
#define BYTE1(x)   BYTEn(x,  1)         // byte 1 (counting from 0)
#define BYTE2(x)   BYTEn(x,  2)
#define BYTE3(x)   BYTEn(x,  3)
#define BYTE4(x)   BYTEn(x,  4)
#define BYTE5(x)   BYTEn(x,  5)
#define BYTE6(x)   BYTEn(x,  6)
#define BYTE7(x)   BYTEn(x,  7)
#define BYTE8(x)   BYTEn(x,  8)
#define BYTE9(x)   BYTEn(x,  9)
#define BYTE10(x)  BYTEn(x, 10)
#define BYTE11(x)  BYTEn(x, 11)
#define BYTE12(x)  BYTEn(x, 12)
#define BYTE13(x)  BYTEn(x, 13)
#define BYTE14(x)  BYTEn(x, 14)
#define BYTE15(x)  BYTEn(x, 15)
#define WORD1(x)   WORDn(x,  1)
#define WORD2(x)   WORDn(x,  2)         // third word of the object, unsigned
#define WORD3(x)   WORDn(x,  3)
#define WORD4(x)   WORDn(x,  4)
#define WORD5(x)   WORDn(x,  5)
#define WORD6(x)   WORDn(x,  6)
#define WORD7(x)   WORDn(x,  7)

// now signed macros (the same but with sign extension)
#define SLOBYTE(x)   (*((int8*)&(x)))
#define SLOWORD(x)   (*((int16*)&(x)))
#define SLODWORD(x)  (*((int32*)&(x)))
#define SHIBYTE(x)   (*((int8*)&(x)+1))
#define SHIWORD(x)   (*((int16*)&(x)+1))
#define SHIDWORD(x)  (*((int32*)&(x)+1))
#define SBYTEn(x, n)   (*((int8*)&(x)+n))
#define SWORDn(x, n)   (*((int16*)&(x)+n))
#define SBYTE1(x)   SBYTEn(x,  1)
#define SBYTE2(x)   SBYTEn(x,  2)
#define SBYTE3(x)   SBYTEn(x,  3)
#define SBYTE4(x)   SBYTEn(x,  4)
#define SBYTE5(x)   SBYTEn(x,  5)
#define SBYTE6(x)   SBYTEn(x,  6)
#define SBYTE7(x)   SBYTEn(x,  7)
#define SBYTE8(x)   SBYTEn(x,  8)
#define SBYTE9(x)   SBYTEn(x,  9)
#define SBYTE10(x)  SBYTEn(x, 10)
#define SBYTE11(x)  SBYTEn(x, 11)
#define SBYTE12(x)  SBYTEn(x, 12)
#define SBYTE13(x)  SBYTEn(x, 13)
#define SBYTE14(x)  SBYTEn(x, 14)
#define SBYTE15(x)  SBYTEn(x, 15)
#define SWORD1(x)   SWORDn(x,  1)
#define SWORD2(x)   SWORDn(x,  2)
#define SWORD3(x)   SWORDn(x,  3)
#define SWORD4(x)   SWORDn(x,  4)
#define SWORD5(x)   SWORDn(x,  5)
#define SWORD6(x)   SWORDn(x,  6)
#define SWORD7(x)   SWORDn(x,  7)


// Helper functions to represent some assembly instructions.

#ifdef __cplusplus

// Fill memory block with an integer value
inline void memset32(void *ptr, uint32 value, int count)
{
  uint32 *p = (uint32 *)ptr;
  for ( int i=0; i < count; i++ )
    *p++ = value;
}

// Generate a reference to pair of operands
template<class T>  int16 __PAIR__( int8  high, T low) { return ((( int16)high) << sizeof(high)*8) | uint8(low); }
template<class T>  int32 __PAIR__( int16 high, T low) { return ((( int32)high) << sizeof(high)*8) | uint16(low); }
template<class T>  int64 __PAIR__( int32 high, T low) { return ((( int64)high) << sizeof(high)*8) | uint32(low); }
template<class T> uint16 __PAIR__(uint8  high, T low) { return (((uint16)high) << sizeof(high)*8) | uint8(low); }
template<class T> uint32 __PAIR__(uint16 high, T low) { return (((uint32)high) << sizeof(high)*8) | uint16(low); }
template<class T> uint64 __PAIR__(uint32 high, T low) { return (((uint64)high) << sizeof(high)*8) | uint32(low); }

// rotate left
template<class T> T __ROL__(T value, uint count)
{
  const uint nbits = sizeof(T) * 8;
  count %= nbits;

  T high = value >> (nbits - count);
  value <<= count;
  value |= high;
  return value;
}

// rotate right
template<class T> T __ROR__(T value, uint count)
{
  const uint nbits = sizeof(T) * 8;
  count %= nbits;

  T low = value << (nbits - count);
  value >>= count;
  value |= low;
  return value;
}

// carry flag of left shift
template<class T> int8 __MKCSHL__(T value, uint count)
{
  const uint nbits = sizeof(T) * 8;
  count %= nbits;

  return (value >> (nbits-count)) & 1;
}

// carry flag of right shift
template<class T> int8 __MKCSHR__(T value, uint count)
{
  return (value >> (count-1)) & 1;
}

// sign flag
template<class T> int8 __SETS__(T x)
{
  if ( sizeof(T) == 1 )
    return int8(x) < 0;
  if ( sizeof(T) == 2 )
    return int16(x) < 0;
  if ( sizeof(T) == 4 )
    return int32(x) < 0;
  return int64(x) < 0;
}

// overflow flag of subtraction (x-y)
template<class T, class U> int8 __OFSUB__(T x, U y)
{
  if ( sizeof(T) < sizeof(U) )
  {
    U x2 = x;
    int8 sx = __SETS__(x2);
    return (sx ^ __SETS__(y)) & (sx ^ __SETS__(x2-y));
  }
  else
  {
    T y2 = y;
    int8 sx = __SETS__(x);
    return (sx ^ __SETS__(y2)) & (sx ^ __SETS__(x-y2));
  }
}

// overflow flag of addition (x+y)
template<class T, class U> int8 __OFADD__(T x, U y)
{
  if ( sizeof(T) < sizeof(U) )
  {
    U x2 = x;
    int8 sx = __SETS__(x2);
    return ((1 ^ sx) ^ __SETS__(y)) & (sx ^ __SETS__(x2+y));
  }
  else
  {
    T y2 = y;
    int8 sx = __SETS__(x);
    return ((1 ^ sx) ^ __SETS__(y2)) & (sx ^ __SETS__(x+y2));
  }
}

// carry flag of subtraction (x-y)
template<class T, class U> int8 __CFSUB__(T x, U y)
{
  int size = sizeof(T) > sizeof(U) ? sizeof(T) : sizeof(U);
  if ( size == 1 )
    return uint8(x) < uint8(y);
  if ( size == 2 )
    return uint16(x) < uint16(y);
  if ( size == 4 )
    return uint32(x) < uint32(y);
  return uint64(x) < uint64(y);
}

// carry flag of addition (x+y)
template<class T, class U> int8 __CFADD__(T x, U y)
{
  int size = sizeof(T) > sizeof(U) ? sizeof(T) : sizeof(U);
  if ( size == 1 )
    return uint8(x) > uint8(x+y);
  if ( size == 2 )
    return uint16(x) > uint16(x+y);
  if ( size == 4 )
    return uint32(x) > uint32(x+y);
  return uint64(x) > uint64(x+y);
}

#else
// The following definition is not quite correct because it always returns
// uint64. The above C++ functions are good, though.
#define __PAIR__(high, low) (((uint64)(high)<<sizeof(high)*8) | low)
// For C, we just provide macros, they are not quite correct.
#define __ROL__(x, y) __rotl__(x, y)      // Rotate left
#define __ROR__(x, y) __rotr__(x, y)      // Rotate right
#define __CFSHL__(x, y) invalid_operation // Generate carry flag for (x<<y)
#define __CFSHR__(x, y) invalid_operation // Generate carry flag for (x>>y)
#define __CFADD__(x, y) invalid_operation // Generate carry flag for (x+y)
#define __CFSUB__(x, y) invalid_operation // Generate carry flag for (x-y)
#define __OFADD__(x, y) invalid_operation // Generate overflow flag for (x+y)
#define __OFSUB__(x, y) invalid_operation // Generate overflow flag for (x-y)
#endif

// No definition for rcl/rcr because the carry flag is unknown
#define __RCL__(x, y)    invalid_operation // Rotate left thru carry
#define __RCR__(x, y)    invalid_operation // Rotate right thru carry
#define __MKCRCL__(x, y) invalid_operation // Generate carry flag for a RCL
#define __MKCRCR__(x, y) invalid_operation // Generate carry flag for a RCR
#define __SETP__(x, y)   invalid_operation // Generate parity flag for (x-y)

// In the decompilation listing there are some objects declarared as _UNKNOWN
// because we could not determine their types. Since the C compiler does not
// accept void item declarations, we replace them by anything of our choice,
// for example a char:

#define _UNKNOWN char

#ifdef _MSC_VER
#define snprintf _snprintf
#define vsnprintf _vsnprintf
#endif
```
# 例子

该例子是中国工业互联网 “电信运营商行业”赛道赛的一个赛题，当时就是直接copy ida伪代码直接爆破出来的。期间运用了一些ida的宏定义变量，脚本如下
```c
#define _CRT_SECURE_NO_DEPRECATE 
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include "header.h"
#include <string.h>

typedef unsigned char   uint8;
typedef unsigned short   uint16;
typedef unsigned long DWORD_PTR;
#define BYTE  uint8
#define WORD  uint16
#define DWORD unsigned long
#define LOBYTE(w)           ((BYTE)(((DWORD_PTR)(w)) & 0xff))
#define HIBYTE(w)           ((BYTE)((((DWORD_PTR)(w)) >> 8) & 0xff))
#define BYTEn(x, n)   (*((BYTE*)&(x)+n))
#define WORDn(x, n)   (*((WORD*)&(x)+n))
#define BYTE0(x)   BYTEn(x,  0)         // byte 0 (counting from 0)  添加此宏定义
#define BYTE1(x)   BYTEn(x,  1)         // byte 1 (counting from 0)
#define BYTE2(x)   BYTEn(x,  2)
#define BYTE3(x)   BYTEn(x,  3)
#define BYTE4(x)   BYTEn(x,  4)

typedef          long long ll;
typedef unsigned long long ull;
#define __int64 long long
#define __int32 int
#define __int16 short
#define __int8  char
typedef __int64 ll;
typedef unsigned __int64 ull;
typedef unsigned int uint;
typedef unsigned char uchar;
typedef unsigned short ushort;
typedef unsigned long ulong;
typedef          char   int8;
typedef   signed char   sint8;
typedef unsigned char   uint8;
typedef          short  int16;
typedef   signed short  sint16;
typedef unsigned short  uint16;
typedef          int    int32;
typedef   signed int    sint32;
typedef unsigned int    uint32;
typedef ll              int64;
typedef ll              sint64;
typedef ull             uint64;


#define _BYTE  uint8
#define _WORD  uint16
#define _DWORD uint32
#define _QWORD uint64

_QWORD* __fastcall sub_1289(_QWORD* a1)
{
    _QWORD* result; // rax

    *a1 = 0LL;
    a1[1] = 0LL;
    a1[2] = 0x7380166FLL;
    a1[3] = 0x4914B2B9LL;
    a1[4] = 0x172442D7LL;
    a1[5] = 0xDA8A0600LL;
    a1[6] = 0xA96F30BCLL;
    a1[7] = 0x163138AALL;
    a1[8] = 0xE38DEE4DLL;
    result = a1;
    a1[9] = 0xDEADBEEFLL;
    return result;
}
unsigned __int64 __fastcall sub_1313(_QWORD* a1, unsigned __int8* a2)
{
    int i; // [rsp+14h] [rbp-6BCh]
    int j; // [rsp+14h] [rbp-6BCh]
    int k; // [rsp+14h] [rbp-6BCh]
    int m; // [rsp+14h] [rbp-6BCh]
    int n; // [rsp+14h] [rbp-6BCh]
    int ii; // [rsp+14h] [rbp-6BCh]
    unsigned __int64 v9; // [rsp+18h] [rbp-6B8h]
    unsigned __int64 v10; // [rsp+20h] [rbp-6B0h]
    __int64 v11; // [rsp+28h] [rbp-6A8h]
    __int64 v12; // [rsp+30h] [rbp-6A0h]
    __int64 v13; // [rsp+38h] [rbp-698h]
    unsigned __int64 v14; // [rsp+40h] [rbp-690h]
    __int64 v15; // [rsp+48h] [rbp-688h]
    __int64 v16; // [rsp+50h] [rbp-680h]
    unsigned __int64 v17; // [rsp+58h] [rbp-678h]
    unsigned __int64 v18; // [rsp+58h] [rbp-678h]
    __int64 v19; // [rsp+68h] [rbp-668h]
    __int64 v20; // [rsp+68h] [rbp-668h]
    unsigned __int64 v21; // [rsp+70h] [rbp-660h]
    unsigned __int64 v22; // [rsp+70h] [rbp-660h]
    unsigned __int64 v23; // [rsp+88h] [rbp-648h]
    __int64 v24[128]; // [rsp+A0h] [rbp-630h]
    __int64 v25[69]; // [rsp+4A0h] [rbp-230h]
    unsigned __int64 v26; // [rsp+6C8h] [rbp-8h]

    for (i = 0; i <= 15; ++i)
        v24[i + 64] = 2043430169LL;
    for (j = 16; j <= 63; ++j)
        v24[j + 64] = 2055708042LL;
    v25[0] = ((unsigned __int64)a2[2] << 8) | ((unsigned __int64)a2[1] << 16) | ((unsigned __int64)*a2 << 24) | a2[3];
    v25[1] = ((unsigned __int64)a2[6] << 8) | ((unsigned __int64)a2[5] << 16) | ((unsigned __int64)a2[4] << 24) | a2[7];
    v25[2] = ((unsigned __int64)a2[10] << 8) | ((unsigned __int64)a2[9] << 16) | ((unsigned __int64)a2[8] << 24) | a2[11];
    v25[3] = ((unsigned __int64)a2[14] << 8) | ((unsigned __int64)a2[13] << 16) | ((unsigned __int64)a2[12] << 24) | a2[15];
    v25[4] = ((unsigned __int64)a2[18] << 8) | ((unsigned __int64)a2[17] << 16) | ((unsigned __int64)a2[16] << 24) | a2[19];
    v25[5] = ((unsigned __int64)a2[22] << 8) | ((unsigned __int64)a2[21] << 16) | ((unsigned __int64)a2[20] << 24) | a2[23];
    v25[6] = ((unsigned __int64)a2[26] << 8) | ((unsigned __int64)a2[25] << 16) | ((unsigned __int64)a2[24] << 24) | a2[27];
    v25[7] = ((unsigned __int64)a2[30] << 8) | ((unsigned __int64)a2[29] << 16) | ((unsigned __int64)a2[28] << 24) | a2[31];
    v25[8] = ((unsigned __int64)a2[34] << 8) | ((unsigned __int64)a2[33] << 16) | ((unsigned __int64)a2[32] << 24) | a2[35];
    v25[9] = ((unsigned __int64)a2[38] << 8) | ((unsigned __int64)a2[37] << 16) | ((unsigned __int64)a2[36] << 24) | a2[39];
    v25[10] = ((unsigned __int64)a2[42] << 8) | ((unsigned __int64)a2[41] << 16) | ((unsigned __int64)a2[40] << 24) | a2[43];
    v25[11] = ((unsigned __int64)a2[46] << 8) | ((unsigned __int64)a2[45] << 16) | ((unsigned __int64)a2[44] << 24) | a2[47];
    v25[12] = ((unsigned __int64)a2[50] << 8) | ((unsigned __int64)a2[49] << 16) | ((unsigned __int64)a2[48] << 24) | a2[51];
    v25[13] = ((unsigned __int64)a2[54] << 8) | ((unsigned __int64)a2[53] << 16) | ((unsigned __int64)a2[52] << 24) | a2[55];
    v25[14] = ((unsigned __int64)a2[58] << 8) | ((unsigned __int64)a2[57] << 16) | ((unsigned __int64)a2[56] << 24) | a2[59];
    v25[15] = ((unsigned __int64)a2[62] << 8) | ((unsigned __int64)a2[61] << 16) | ((unsigned __int64)a2[60] << 24) | a2[63];
    for (k = 16; k <= 67; ++k)
    {
        v23 = ((v25[k - 3] << 15) & 0x7FFFFFFF8000LL | ((unsigned __int64)v25[k - 3] >> 17)) ^ v25[k - 16] ^ v25[k - 9];
        v25[k] = (((unsigned __int64)v25[k - 13] >> 25) | (v25[k - 13] << 7) & 0x7FFFFFFF80LL) ^ v25[k - 6] ^ v23 ^ ((v23 << 15) & 0x7FFFFFFF8000LL | (v23 >> 17)) ^ ((v23 << 23) & 0x7FFFFFFF800000LL | (v23 >> 9));
    }
    for (m = 0; m <= 63; ++m)
        v24[m] = v25[m + 4] ^ v25[m];
    v9 = a1[2];
    v10 = a1[3];
    v11 = a1[4];
    v12 = a1[5];
    v13 = a1[6];
    v14 = a1[7];
    v15 = a1[8];
    v16 = a1[9];
    for (n = 0; n <= 15; ++n)
    {
        v17 = ((((v9 >> 20) | (v9 << 12) & 0xFFFFFFFF000LL)
            + v13
            + (((unsigned __int64)(unsigned int)v24[n + 64] << n) | ((unsigned __int64)v24[n + 64] >> (32 - (unsigned __int8)n)))) << 7) & 0x7FFFFFFF80LL | ((((v9 >> 20) | (v9 << 12) & 0xFFFFFFFF000LL) + v13 + (((unsigned __int64)(unsigned int)v24[n + 64] << n) | ((unsigned __int64)v24[n + 64] >> (32 - (unsigned __int8)n)))) >> 25);
        v19 = (v17 ^ ((v9 << 12) & 0xFFFFFFFF000LL | (v9 >> 20))) + v12 + (v11 ^ v10 ^ v9) + v24[n];
        v21 = v17 + v16 + (v15 ^ v14 ^ v13) + v25[n];
        v12 = v11;
        v11 = (v10 << 9) & 0x1FFFFFFFE00LL | (v10 >> 23);
        v10 = v9;
        v9 = v19;
        v16 = v15;
        v15 = (v14 << 19) & 0x7FFFFFFF80000LL | (v14 >> 13);
        v14 = v13;
        v13 = v21 ^ ((v21 << 9) & 0x1FFFFFFFE00LL | (v21 >> 23)) ^ ((v21 << 17) & 0x1FFFFFFFE0000LL | (v21 >> 15));
    }
    for (ii = 16; ii <= 63; ++ii)
    {
        v18 = ((((v9 >> 20) | (v9 << 12) & 0xFFFFFFFF000LL)
            + v13
            + (((unsigned __int64)(unsigned int)v24[ii + 64] << ii) | ((unsigned __int64)v24[ii + 64] >> (32 - (unsigned __int8)ii)))) << 7) & 0x7FFFFFFF80LL | ((((v9 >> 20) | (v9 << 12) & 0xFFFFFFFF000LL) + v13 + (((unsigned __int64)(unsigned int)v24[ii + 64] << ii) | ((unsigned __int64)v24[ii + 64] >> (32 - (unsigned __int8)ii)))) >> 25);
        v20 = (v18 ^ ((v9 << 12) & 0xFFFFFFFF000LL | (v9 >> 20))) + v12 + (v11 & v10 | v9 & (v11 | v10)) + v24[ii];
        v22 = v18 + v16 + (v15 & ~v13 | v14 & v13) + v25[ii];
        v12 = v11;
        v11 = (v10 << 9) & 0x1FFFFFFFE00LL | (v10 >> 23);
        v10 = v9;
        v9 = v20;
        v16 = v15;
        v15 = (v14 << 19) & 0x7FFFFFFF80000LL | (v14 >> 13);
        v14 = v13;
        v13 = v22 ^ ((v22 << 9) & 0x1FFFFFFFE00LL | (v22 >> 23)) ^ ((v22 << 17) & 0x1FFFFFFFE0000LL | (v22 >> 15));
    }
    a1[2] ^= v9;
    a1[3] ^= v10;
    a1[4] ^= v11;
    a1[5] ^= v12;
    a1[6] ^= v13;
    a1[7] ^= v14;
    a1[8] ^= v15;
    a1[9] ^= v16;
    return 0;
}
__int64 __fastcall sub_2399(_QWORD* data, char* inputn_ptr, int len_1)
{
    __int64 result; // rax
    int v4; // [rsp+Ch] [rbp-24h]
    char* src; // [rsp+10h] [rbp-20h]
    int v6; // [rsp+24h] [rbp-Ch]
    __int64 v7; // [rsp+28h] [rbp-8h]

    src = inputn_ptr;
    v4 = len_1;
    if (len_1 > 0)
    {
        v7 = *data & 0x3FLL;
        v6 = 64 - v7;
        *data += len_1;
        *data = (unsigned int)*data;
        result = len_1;
        if (*data < (unsigned __int64)len_1)
        {
            result = (__int64)data;
            ++data[1];
        }
        if (v7)
        {
            result = (unsigned int)len_1;
            if (len_1 >= v6)
            {
                memcpy((char*)data + v7 + 80, inputn_ptr, v6);
                sub_1313(data, (unsigned __int8*)data + 80);
                src = &inputn_ptr[v6];
                result = (unsigned int)v6;
                v4 -= v6;
                v7 = 0LL;
            }
        }
        while (v4 > 63)
        {
            result = sub_1313(data, (unsigned __int8*)src);
            src += 64;
            v4 -= 64;
        }
        if (v4 > 0)
            return (__int64)memcpy((char*)data + v7 + 80, src, v4);
    }
    return result;
}

unsigned __int64 __fastcall sub_24D7(_QWORD* a1, char* a2)
{
    int v2; // eax
    __int64 v4; // [rsp+10h] [rbp-30h]
    __int64 v5; // [rsp+18h] [rbp-28h]
    unsigned __int64 v6; // [rsp+20h] [rbp-20h]
    char v7[8]; // [rsp+30h] [rbp-10h] BYREF
    unsigned __int64 v8; // [rsp+38h] [rbp-8h]
    char byte_4020[64] =
    {
      '\x80',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0',
      '\0'
    };

    v4 = (*a1 >> 29) | (8LL * a1[1]);
    v5 = 8LL * *a1;
    v7[0] = ((unsigned int)(*a1 >> 29) | (8 * *((unsigned long*)a1 + 2))) >> 24;
    v7[1] = BYTE2(v4);
    v7[2] = BYTE1(v4);
    v7[3] = v4;
    v7[4] = BYTE3(v5);
    v7[5] = BYTE2(v5);
    v7[6] = BYTE1(v5);
    v7[7] = v5;
    v6 = *a1 & 0x3FLL;
    if (v6 > 0x37)
        v2 = 120 - v6;
    else
        v2 = 56 - v6;
    sub_2399(a1, byte_4020, v2);
    sub_2399(a1, v7, 8);
    *a2 = BYTE3(a1[2]);
    a2[1] = BYTE2(a1[2]);
    a2[2] = BYTE1(a1[2]);
    a2[3] = a1[2];
    a2[4] = BYTE3(a1[3]);
    a2[5] = BYTE2(a1[3]);
    a2[6] = BYTE1(a1[3]);
    a2[7] = a1[3];
    a2[8] = BYTE3(a1[4]);
    a2[9] = BYTE2(a1[4]);
    a2[10] = BYTE1(a1[4]);
    a2[11] = a1[4];
    a2[12] = BYTE3(a1[5]);
    a2[13] = BYTE2(a1[5]);
    a2[14] = BYTE1(a1[5]);
    a2[15] = a1[5];
    a2[16] = BYTE3(a1[6]);
    a2[17] = BYTE2(a1[6]);
    a2[18] = BYTE1(a1[6]);
    a2[19] = a1[6];
    a2[20] = BYTE3(a1[7]);
    a2[21] = BYTE2(a1[7]);
    a2[22] = BYTE1(a1[7]);
    a2[23] = a1[7];
    a2[24] = BYTE3(a1[8]);
    a2[25] = BYTE2(a1[8]);
    a2[26] = BYTE1(a1[8]);
    a2[27] = a1[8];
    a2[28] = BYTE3(a1[9]);
    a2[29] = BYTE2(a1[9]);
    a2[30] = BYTE1(a1[9]);
    a2[31] = a1[9];
    return 0;
}

__int64 __fastcall sub_55C3E5C45DDD(__int64 a1, __int64 a2)
{
    int i; // [rsp+1Ch] [rbp-4h]

    for (i = 0; i <= 31 && *(_BYTE*)(i + a1) == *(_BYTE*)(i + a2); ++i)
        ;
    return (unsigned int)i;
}

int main() {
    char v7[40];
    char a1[40] = { "flag{xxxxxxxxxxxxxxxxxxxxx}"};
    FILE* stream;
    __int64 ptr[27*4];
    _QWORD data[34];
    int v6;
    stream = fopen("./out.bin", "rb");
    memset(ptr, 0, sizeof(ptr));
    for (int i = 0; i <= 27*4; i+=4)
    {
        fread(&ptr[i], 1uLL, 0x20uLL, stream);
    }


    for (int i = 26; i > 0; --i)
    {
        for (int j = 32; j < 127; j++) {
            a1[i] = (char)j;
            sub_1289(data);
            sub_2399(data, &a1[i], 1LL);
            sub_24D7(data, v7);
            memset(data, 0, sizeof(data));
            if ((unsigned int)sub_55C3E5C45DDD((__int64)&ptr[i * 4], (__int64)v7) == 32) {
                a1[i] = (char)j;
                puts(a1);
                break;
            }
        }

    }
    return 1LL;
               
   
}
```
其中fopen会报不安全错误，这时在程序开头，注意是最开头加入`#define _CRT_SECURE_NO_DEPRECATE `即可。


