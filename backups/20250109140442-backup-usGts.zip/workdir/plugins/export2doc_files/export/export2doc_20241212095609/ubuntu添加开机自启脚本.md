---
title: ubuntu添加开机自启脚本
id: 34
date: 2024-01-09 20:09:11
auther: yrl
cover: 
excerpt: 创建rc.local文件touch /etc/rc.local &amp;&amp; chmod +x  /etc/rc.localtouch /etc/rc.localecho &#39;#!/bin/sh&#39; &gt; /etc/rc.localecho &#39;sh /start.sh
permalink: /archives/ubuntu-tian-jia-kai-ji-zi-qi-jiao-ben
categories:
 - linux服务
 - linux
 - useful
tags: 
 - 常用功能
---

# 0x1 添加service实现开机自启

较高版本的ubuntu可以用添加service的方式注册守护进程服务实现开机启动脚本

1. 打开终端并创建一个新的 Systemd unit 文件，比如说 myscript.service，可以使用如下命令：
```bash
sudo vim /etc/systemd/system/myscript.service
```
内容如下，目标是启动start.sh：

```bash
[Unit]
Description=My Script Service
After=network.target

[Service]
Type=simple
User=<username>
ExecStart=/bin/bash -c "/start.sh"
ExecStop=/bin/bash -c "/stop.sh"

[Install]
WantedBy=multi-user.target

```

start.sh样例如下:

```bash
#!/bin/bash

systemctl stop sshd.service
cd /root && docker-compose up

```
stop.sh样例如下:

```bash
#!/bin/bash

cd /root && docker-compose down

```
注意start.sh应该保持阻塞，不然status会显示异常，样例中`docker-compose up`保持阻塞;stop.sh是停止服务所执行的命令

2. 使用以下命令重新加载 Systemd 配置，启用自启动项并启动服务：

```bash
sudo systemctl daemon-reload
sudo systemctl enable myscript.service
sudo systemctl start myscript.service
```
3. 检查服务状态
```bash 
systemctl status docker_run.service
```
4. 停止服务并禁用自启动项
```bash
sudo systemctl stop docker_run.service
sudo systemctl disable docker_run.service
```

# 0x2 rc.local文件实现开机自启

1. 创建rc.local文件，并赋予执行权限，指定运行的命令或脚本
```bash
touch /etc/rc.local && chmod +x  /etc/rc.local
touch /etc/rc.local
echo '#!/bin/sh' > /etc/rc.local
echo 'sh /start.sh' >> /etc/rc.local
echo 'echo "start.sh success!" > /usr/local/test.log' >> /etc/rc.local
echo 'exit 0' >> /usr/local/test.log
```
2. 创建软连接

`ln -s /lib/systemd/system/rc-local.service /etc/systemd/system/rc-local.service`

重启即可。
