---
title: frida基础用法
id: 112
date: 2024-01-09 20:09:11
auther: yrl
cover: 
excerpt: frida原理frida是一个动态注入插桩的工具，它相对于xposed比较便捷，可随时修改代码逻辑，跨平台支持，支持java层和so层的hook操作。frida使用使用frida Hook会用到两个工具：frida-server（服务端程序）、frida（客户端程序）frida可通过python安装
permalink: /archives/frida%E5%9F%BA%E7%A1%80%E7%94%A8%E6%B3%95
categories:
 - android
 - frida
tags: 
 - frida
---

# frida原理

frida是一个动态注入插桩的工具，它相对于xposed比较便捷，可随时修改代码逻辑，跨平台支持，支持java层和so层的hook操作。

# frida使用

使用frida Hook会用到两个工具：frida-server（服务端程序）、frida（客户端程序）

frida可通过python安装，最新版本如下：
```bash
pip install frida-tools -i https://pypi.tuna.tsinghua.edu.cn/simple
```
旧版本如下：
```bash
pip install frida==12.8.0 frida-tools==5.3.0 -i https://pypi.tuna.tsinghua.edu.cn/simple

```
frida-server去[官方github](https://github.com/frida/frida/releases/)上下载，选择需要的平台版本，注意server和client版本要一致。

将frida-server放到手机的/data/local/tmp目录下，赋权运行：
```
adb push frida-server /data/local/tmp
adb root
adb shell chmod +x /data/local/tmp/frida-server
adb shell /data/local/tmp/frida-server -l 0.0.0.0:1234  # -l 0.0.0.0:1234为指定端口，不写默认27042端口
```
客户端：
`frida-ps -U`查看通过usb连接的android手机上的进程，通过grep过滤就可以找到我们想要的包名。

客户端执行`frida -U -f packagename -l script.js ` 

frida参数`-f`是以spawn启动，也就是重启app注入js；`-U`连接到USB设备；`-l`js脚本；`--pause`启动frida后让主线程暂停，通过`%resume`唤醒主线程。

[快速开始](https://frida.re/docs/quickstart/)
[fridaHOOK基础](https://zhuanlan.zhihu.com/p/157603104)
[fridaHOOK笔记](https://zhuanlan.zhihu.com/p/157604388)
应学会如何快速有效的编写frida脚本。

# frida反反调试及相关脚本

常见frida检测

1. 检测frida-server文件名
1. 检测27042默认端口
1. 检测D-Bus
1. 检测/proc/pid/maps映射文件
1. 检测/proc/pid/tast/tid/stat或/proc/pid/tast/tid/status
1. 双进程保护
 
前两种可以通过修改frida-server文件名，改默认端口绕过。双进程可以通过-f spawn模式启动绕过。其他的需要去hook修改。
`D-Bus`协议是frida通信协议，app常会使用D-bus协议向每个端口发送请求包，哪个回应了就说明存在frida注入。
`检测/proc/pid/maps映射文件`是根据frida进程会在maps中有re.frida相关字样，只要检测到就说明存在frida注入。
`检测/proc/pid/tast/tid/stat或/proc/pid/tast/tid/status`,其中traceID标志这是否在调试状态。

## frida脱壳脚本

编写脚本并把libart.so拿出来.然后IDA逆向OpenMemory的对应签名函数名

```js
Interceptor.attach(Module.findExportByName("libart.so", "_ZN3art7DexFile10OpenMemoryEPKhjRKNSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEEjPNS_6MemMapEPKNS_10OatDexFileEPS9_"), {

    onEnter: function (args) {

        //dex起始位置

        var begin = args[1]

        //打印magic

        console.log("magic : " + Memory.readUtf8String(begin))

        //dex fileSize 地址

        var address = parseInt(begin,16) + 0x20

        //dex 大小

        var dex_size = Memory.readInt(ptr(address))

        console.log("dex_size :" + dex_size)

        var packageName = "com.********" 

        var file = new File("/data/data/"+packageName+"/" + dex_size + ".dex", "wb")

        file.write(Memory.readByteArray(begin, dex_size))

        file.flush()

        file.close()

    },

    onLeave: function (retval) {

        if (retval.toInt32() > 0) {

            /* do something */

        }

    }

});
```

另外，frida-dexdump工具也可以脱部分壳，`frida-dexdump -FU`即可脱最上层应用的壳。

## frida反反调试脚本

这里当挂上frida后对应的maps文件中会出现`re.frida.server`之类的特征，这是在使用frida server的时候自动创建的，其中存放着frida的功能模块，可以在载入so的hook脚本输出中能看到最后也是断在frida-agent.so

这里要绕过这个检测，我是通过备份一个正常启动时的maps文件（这里前面也讲到app不使用frida是能正常启动不闪退的）。然后frida启动后将maps文件指向备份的文件接可，脚本如下：

```js
function main() {
  const openPtr = Module.getExportByName('libc.so', 'open');
  const open = new NativeFunction(openPtr, 'int', ['pointer', 'int']);
  var readPtr = Module.findExportByName("libc.so", "read");
  var read = new NativeFunction(readPtr, 'int', ['int', 'pointer', "int"]);
  var fakePath = "/data/data/com.app/maps";
  var file = new File(fakePath, "w");
  var buffer = Memory.alloc(512);
  Interceptor.replace(openPtr, new NativeCallback(function (pathnameptr, flag) {
      var pathname = Memory.readUtf8String(pathnameptr);
      var realFd = open(pathnameptr, flag);
      if (pathname.indexOf("maps") >= 0) {
          while (parseInt(read(realFd, buffer, 512)) !== 0) {
              var oneLine = Memory.readCString(buffer);
              if (oneLine.indexOf("tmp") === -1) {
                  file.write(oneLine);
              }
          }
          var filename = Memory.allocUtf8String(fakePath);
          return open(filename, flag);
      }
      var fd = open(pathnameptr, flag);
      return fd;
  }, 'int', ['pointer', 'int']));
}
setImmediate(main
```
这个脚本只能过部分检测maps文件的情况。

[stringR-frida-android](https://github.com/hzzheyang/strongR-frida-android) 可以过部分反调试。