---
title: ubuntu20.04 server 拓容磁盘（cmd方式）
id: 33
date: 2024-01-09 20:09:10
auther: yrl
cover: 
excerpt: ubuntu拓展磁盘安装ubuntu server后给虚拟机分配了20G，但是实际df -h只有10G，还有一部分是free状态的，现在就要把所有free的都拓展到mapper磁盘。在Ubuntu 执行分区扩容sudo fdisk /dev/sdap 查看分区情况，d 删除需要扩容的分区需要看下操作
permalink: /archives/ubuntu2004server%E6%8B%93%E5%AE%B9%E7%A3%81%E7%9B%98cmd%E6%96%B9%E5%BC%8F
categories:
 - linux磁盘扩容
 - linux
tags: 
 - linux磁盘
---

# ubuntu拓展磁盘
安装ubuntu server后给虚拟机分配了20G，但是实际`df -h`只有10G，还有一部分是free状态的，现在就要把所有free的都拓展到mapper磁盘。
# 在Ubuntu 执行分区扩容
`sudo fdisk /dev/sda`

p 查看分区情况，
d 删除需要扩容的分区
需要看下操作提示：Partition number (1,2, default 2): 2
完成之后不需要 w 写操作。
继续创建分区：
n
如果你不懂那些参数就默认吧。（First和Last sector）
最后 w 写入。

# 为 ubuntu扩容
登陆主机核实一下：
`df -h`
查看磁盘，我的主要是 /dev/mapper/ubuntu–vg-ubuntu–lv 这个磁盘快满了。
所以我需要对他扩容。
执行 `sudo vgdisplay`
里面有两个参数，一个是 Alloc PE ， 另一个 Free PE
我们需要将free容量扩容到上面的磁盘中。
`sudo lvextend -l +100%FREE /dev/mapper/ubuntu--vg-ubuntu--lv`
可以看到100%的free，如果想具体加入多少单位，可以自定义。 例如：100G
执行完成后，需要重新计算磁盘。
`sudo resize2fs /dev/mapper/ubuntu--vg-ubuntu--lv`
最后看下结果 `df -h`
发现已经拓展成功。