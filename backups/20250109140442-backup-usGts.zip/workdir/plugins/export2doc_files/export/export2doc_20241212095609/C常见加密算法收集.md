---
title: C常见加密算法收集
id: 115
date: 2024-01-09 20:09:11
auther: yrl
cover: 
excerpt: SM3/* * sm3.h * * 为使此算法兼容32位、64位下Linux或Windows系统， * 选择 int 来表示 32 位整数。 * 消息长度最大限定为 2**32 - 1（单位：比特）， * 且为 8 的倍数（消息的最小单元为字节）。 */#ifndef _SM3_H_#define 
permalink: /archives/c%E5%B8%B8%E8%A7%81%E5%8A%A0%E5%AF%86%E7%AE%97%E6%B3%95%E6%94%B6%E9%9B%86
categories:
 - useful
 - cc
 - 密码
tags: 
 - sm3
 - tea
 - smx
---

# SM3
```c
/*
 * sm3.h
 *
 * 为使此算法兼容32位、64位下Linux或Windows系统，
 * 选择 int 来表示 32 位整数。
 * 消息长度最大限定为 2**32 - 1（单位：比特），
 * 且为 8 的倍数（消息的最小单元为字节）。
 */
#ifndef _SM3_H_
#define _SM3_H_

/*
 * SM3算法产生的哈希值大小（单位：字节）
 */
#define SM3_HASH_SIZE 32 

/*
 * SM3上下文
 */
typedef struct SM3Context
{
    unsigned int intermediateHash[SM3_HASH_SIZE / 4];
    unsigned char messageBlock[64];
} SM3Context;

/*
 * SM3计算函数
 */
unsigned char *SM3Calc(const unsigned char *message, 
        unsigned int messageLen, unsigned char digest[SM3_HASH_SIZE]);

#endif // _SM3_H_
```

```c
/*
 * sm3.c
 */
#include <stdio.h>
#include <memory.h>
#include "sm3.h"

/*
 * 判断运行环境是否为小端
 */
static const int endianTest = 1;
#define IsLittleEndian() (*(char *)&endianTest == 1)

/*
 * 向左循环移位
 */
#define LeftRotate(word, bits) ( (word) << (bits) | (word) >> (32 - (bits)) )

/*
 * 反转四字节整型字节序
 */
unsigned int *ReverseWord(unsigned int *word)
{
    unsigned char *byte, temp;

    byte = (unsigned char *)word;
    temp = byte[0];
    byte[0] = byte[3];    
    byte[3] = temp;

    temp = byte[1];
    byte[1] = byte[2];
    byte[2] = temp;
    return word;
}

/*
 * T
 */
unsigned int T(int i)
{
    if (i >= 0 && i <= 15)
        return 0x79CC4519;
    else if (i >= 16 && i <= 63)
        return 0x7A879D8A;
    else
        return 0;
}

/*
 * FF
 */
unsigned int FF(unsigned int X, unsigned int Y, unsigned int Z, int i)
{
    if (i >= 0 && i <= 15)
        return X ^ Y ^ Z;
    else if (i >= 16 && i <= 63)
        return (X & Y) | (X & Z) | (Y & Z);
    else
        return 0;
}

/*
 * GG
 */
unsigned int GG(unsigned int X, unsigned int Y, unsigned int Z, int i)
{
    if (i >= 0 && i <= 15)
        return X ^ Y ^ Z;
    else if (i >= 16 && i <= 63)
        return (X & Y) | (~X & Z);
    else
        return 0;
}

/*
 * P0
 */
unsigned int P0(unsigned int X)
{
    return X ^ LeftRotate(X, 9) ^ LeftRotate(X, 17);
}

/*
 * P1
 */
unsigned int P1(unsigned int X)
{
    return X ^ LeftRotate(X, 15) ^ LeftRotate(X, 23);
}

/*
 * 初始化函数
 */
void SM3Init(SM3Context *context)
{
    context->intermediateHash[0] = 0x7380166F;
    context->intermediateHash[1] = 0x4914B2B9;
    context->intermediateHash[2] = 0x172442D7;
    context->intermediateHash[3] = 0xDA8A0600;
    context->intermediateHash[4] = 0xA96F30BC;
    context->intermediateHash[5] = 0x163138AA;
    context->intermediateHash[6] = 0xE38DEE4D;
    context->intermediateHash[7] = 0xB0FB0E4E;
}

/*
 * 处理消息块
 */
void SM3ProcessMessageBlock(SM3Context *context)
{
    int i;
    unsigned int W[68];
    unsigned int W_[64];
    unsigned int A, B, C, D, E, F, G, H, SS1, SS2, TT1, TT2;

    /* 消息扩展 */
    for (i = 0; i < 16; i++)
    {
        W[i] = *(unsigned int *)(context->messageBlock + i * 4);
        if (IsLittleEndian())
            ReverseWord(W + i);
        //printf("%d: %x\n", i, W[i]);    
    }
    for (i = 16; i < 68; i++)
    {
        W[i] = P1(W[i - 16] ^ W[i - 9] ^ LeftRotate(W[i - 3], 15)) 
                ^ LeftRotate(W[i - 13], 7) 
                ^ W[i - 6];
        //printf("%d: %x\n", i, W[i]);    
    }
    for (i = 0; i < 64; i++)
    {
        W_[i] = W[i] ^ W[i + 4];
        //printf("%d: %x\n", i, W_[i]);    
    }

    /* 消息压缩 */
    A = context->intermediateHash[0];
    B = context->intermediateHash[1];
    C = context->intermediateHash[2];
    D = context->intermediateHash[3];
    E = context->intermediateHash[4];
    F = context->intermediateHash[5];
    G = context->intermediateHash[6];
    H = context->intermediateHash[7];
    for (i = 0; i < 64; i++)
    {
        SS1 = LeftRotate((LeftRotate(A, 12) + E + LeftRotate(T(i), i)), 7);
        SS2 = SS1 ^ LeftRotate(A, 12);
        TT1 = FF(A, B, C, i) + D + SS2 + W_[i];
        TT2 = GG(E, F, G, i) + H + SS1 + W[i];
        D = C;
        C = LeftRotate(B, 9);
        B = A;
        A = TT1;
        H = G;
        G = LeftRotate(F, 19);
        F = E;
        E = P0(TT2);
    }
    context->intermediateHash[0] ^= A;
    context->intermediateHash[1] ^= B;
    context->intermediateHash[2] ^= C;
    context->intermediateHash[3] ^= D;
    context->intermediateHash[4] ^= E;
    context->intermediateHash[5] ^= F;
    context->intermediateHash[6] ^= G;
    context->intermediateHash[7] ^= H;
}

/*
 * SM3算法主函数
 */
unsigned char *SM3Calc(const unsigned char *message, 
        unsigned int messageLen, unsigned char digest[SM3_HASH_SIZE])
{
    SM3Context context;
    unsigned int i, remainder, bitLen;

    /* 初始化上下文 */
    SM3Init(&context);

    /* 对前面的消息分组进行处理 */
    for (i = 0; i < messageLen / 64; i++)
    {
        memcpy(context.messageBlock, message + i * 64, 64);
        SM3ProcessMessageBlock(&context);
    }

    /* 填充消息分组，并处理 */
    bitLen = messageLen * 8;
    if (IsLittleEndian())
        ReverseWord(&bitLen);
    remainder = messageLen % 64;
    memcpy(context.messageBlock, message + i * 64, remainder);
    context.messageBlock[remainder] = 0x80;
    if (remainder <= 55)
    {
        /* 长度按照大端法占8个字节，该程序只考虑长度在 2**32 - 1（单位：比特）以内的情况，
         * 故将高 4 个字节赋为 0 。*/
        memset(context.messageBlock + remainder + 1, 0, 64 - remainder - 1 - 8 + 4);
        memcpy(context.messageBlock + 64 - 4, &bitLen, 4);    
        SM3ProcessMessageBlock(&context);
    }
    else
    {
        memset(context.messageBlock + remainder + 1, 0, 64 - remainder - 1);
        SM3ProcessMessageBlock(&context);
        /* 长度按照大端法占8个字节，该程序只考虑长度在 2**32 - 1（单位：比特）以内的情况，
         * 故将高 4 个字节赋为 0 。*/
        memset(context.messageBlock, 0, 64 - 4);
        memcpy(context.messageBlock + 64 - 4, &bitLen, 4);    
        SM3ProcessMessageBlock(&context);
    }

    /* 返回结果 */
    if (IsLittleEndian())
        for (i = 0; i < 8; i++)
            ReverseWord(context.intermediateHash + i);
    memcpy(digest, context.intermediateHash, SM3_HASH_SIZE);

    return digest;
}
```

[SMx集合](https://github.com/NEWPLAN/SMx.git)

# tea
## tea
```c
#include <stdio.h>
#include <stdint.h>

//加密函数
void encrypt(uint32_t* v, uint32_t* k) {
	uint32_t v0 = v[0], v1 = v[1], sum = 0, i;
	uint32_t delta = 0x9e3779b9;
	uint32_t k0 = k[0], k1 = k[1], k2 = k[2], k3 = k[3];
	for (i = 0; i < 32; i++) {
		sum += delta;
		v0 += ((v1 << 4) + k0) ^ (v1 + sum) ^ ((v1 >> 5) + k1);
		v1 += ((v0 << 4) + k2) ^ (v0 + sum) ^ ((v0 >> 5) + k3);
	}
	v[0] = v0; v[1] = v1;
}

//解密函数
void decrypt(uint32_t* v, uint32_t* k) {
	uint32_t v0 = v[0], v1 = v[1], sum = 0xC6EF3720, i;
	uint32_t delta = 0x9e3779b9;
	uint32_t k0 = k[0], k1 = k[1], k2 = k[2], k3 = k[3];
	for (i = 0; i<32; i++) {
		v1 -= ((v0 << 4) + k2) ^ (v0 + sum) ^ ((v0 >> 5) + k3);
		v0 -= ((v1 << 4) + k0) ^ (v1 + sum) ^ ((v1 >> 5) + k1);
		sum -= delta;
	}
	v[0] = v0; v[1] = v1;
}

int main()
{
	// v为要加解密的数据，两个32位无符号整数
	uint32_t v[2] = { 1,2 };
	// k为加解密密钥，4个32位无符号整数，密钥长度为128位
	uint32_t k[4] = { 1,2,3,4 };
	int n = sizeof(v) / sizeof(uint32_t);
	printf("加密前原始数据：0x%x 0x%x\n", v[0], v[1]);
	encrypt(v, k);
	printf("加密后的数据：0x%x 0x%x\n", v[0], v[1]);
	decrypt(v, k);
	printf("解密后的数据：0x%x 0x%x\n", v[0], v[1]);
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < sizeof(uint32_t)/sizeof(uint8_t); j++)
		{
			printf("%c", (v[i] >> (j * 8)) & 0xFF);
		}
	}
	printf("\n");
	return 0;
}

```

单纯tea解密脚本：
```c
#include <stdio.h>
#include <stdint.h>

//加密函数
void encrypt(uint32_t* v, uint32_t* k) {
    uint32_t v0 = v[0], v1 = v[1], sum = 0, i;
    uint32_t delta = 0x9e3779b9;
    uint32_t k0 = k[0], k1 = k[1], k2 = k[2], k3 = k[3];
    for (i = 0; i < 32; i++) {
        sum += delta;
        v0 += ((v1 << 4) + k0) ^ (v1 + sum) ^ ((v1 >> 5) + k1);
        v1 += ((v0 << 4) + k2) ^ (v0 + sum) ^ ((v0 >> 5) + k3);
    }
    v[0] = v0; v[1] = v1;
}

//解密函数
void decrypt(uint32_t* v, uint32_t* k) {
    uint32_t v0 = v[0], v1 = v[1], sum = 0xC6EF3720, i;
    uint32_t delta = 0x9e3779b9;
    uint32_t k0 = k[0], k1 = k[1], k2 = k[2], k3 = k[3];
    for (i = 0; i<32; i++) {
        v1 -= ((v0 << 4) + k2) ^ (v0 + sum) ^ ((v0 >> 5) + k3);
        v0 -= ((v1 << 4) + k0) ^ (v1 + sum) ^ ((v1 >> 5) + k1);
        sum -= delta;
    }
    v[0] = v0; v[1] = v1;
}

int main()
{
    // v为要加解密的数据，两个32位无符号整数
    uint32_t v[8] = { 0x85a6892d, 0xa177b6bd, 0x89422515, 0x159ae870, 0x5bc09e5d, 0xc13f293e, 0x25b7084f, 0xadb12a4c };
    // k为加解密密钥，4个32位无符号整数，密钥长度为128位
    uint32_t k[4] = { 0xdfe3, 0x113e, 0x5897, 0x3654 };
    int n = sizeof(v) / sizeof(uint32_t);
    // printf("加密前原始数据：0x%x 0x%x\n", v[0], v[1]);
    // encrypt(v, k);
    // printf("加密后的数据：0x%x 0x%x\n", v[0], v[1]);
    for(int i = 0;i<n/2;i++){

        decrypt(v+(i*2), k);
        printf("解密后的数据：0x%x 0x%x\n", v[0], v[1]);
    }
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < sizeof(uint32_t)/sizeof(uint8_t); j++)
        {
            printf("%c", (v[i] >> (j * 8)) & 0xFF);
        }
    }
    printf("\n");
    return 0;
}

```

## xtea
```c
#include <stdint.h>
#include <stdio.h>
#include <string.h>


/* take 64 bits of data in v[0] and v[1] and 128 bits of key[0] - key[3] */
void encipher(unsigned int num_rounds, uint32_t v[2], uint32_t const key[4]) {
  unsigned int i;
  uint32_t v0=v[0], v1=v[1], sum=0, delta=0x9E3779B9;
  for (i=0; i < num_rounds; i++) {
    v0 += (((v1 << 4) ^ (v1 >> 5)) + v1) ^ (sum + key[sum & 3]);
    sum += delta;
    v1 += (((v0 << 4) ^ (v0 >> 5)) + v0) ^ (sum + key[(sum>>11) & 3]);
  }
  v[0]=v0; v[1]=v1;
}


void decipher(unsigned int num_rounds, uint32_t v[2], uint32_t const key[4]) {
  unsigned int i;
  uint32_t v0=v[0], v1=v[1], delta=0x9E3779B9, sum=delta*num_rounds;
  while(sum) {
    v1 -= (((v0 << 4) ^ (v0 >> 5)) + v0) ^ (sum + key[(sum>>11) & 3]);
    sum -= delta;
    v0 -= (((v1 << 4) ^ (v1 >> 5)) + v1) ^ (sum + key[sum & 3]);
  }
  v[0]=v0; v[1]=v1;
}


/*intializing Buffering stack*/
volatile int p =0;
volatile uint8_t buffer[100];
void push(const uint32_t b) {
  buffer[p] = (uint8_t)b;
  p++;
  buffer[p] = '\0';
}
/*Ending buffering stack*/


void writeBuffer(uint32_t v[2]) {  
  push(v[0] & 0x000000ff);
  push((v[0] & 0x0000ff00) >> 8);
  push((v[0] & 0x00ff0000) >> 16);
  push((v[0] & 0xff000000) >> 24);

  push(v[1] & 0x000000ff);
  push((v[1] & 0x0000ff00) >> 8);
  push((v[1] & 0x00ff0000) >> 16);
  push((v[1] & 0xff000000) >> 24);
}

void doBlock(uint8_t *d, uint8_t *key, int isEncrypt) {
  uint32_t k[4];
  k[0] = key[3]<<24 | key[2]<<16 | key[1]<<8 | key[0];
  k[1] = key[7]<<24 | key[6]<<16 | key[5]<<8 | key[4];
  k[2] = key[11]<<24 | key[10]<<16 | key[9]<<8 | key[8];
  k[3] = key[15]<<24 | key[14]<<16 | key[13]<<8 | key[12];
  int i=0;
  int n=0;
  uint32_t v[2];
  /* printf("\n encripting: %*s\n", 57, d); */
  int len = strlen(d);
  for (i=0; i < len; i = i+4) {
    if ((i+3) < len) {
      if (n == 0) {
        v[0] = d[i+3]<<24 | d[i+2]<<16 | d[i+1]<<8 | d[i];
        n = 1;
      } else if (n == 1) {
        v[1] = d[i+3]<<24 | d[i+2]<<16 | d[i+1]<<8 | d[i];
        n = 0;
        if(isEncrypt) {
          encipher(32, v, k);
        } else {
          decipher(32, v, k);
        }
        writeBuffer(v);
      }
    } else {
      int empty = (i + 3) - len;
      switch (empty) {
      case 1: {
        if (n==0) {
          v[0] = 0<<24 | d[i+2]<<16 | d[i+1]<<8 | d[i];
          v[1] = 0;
        } else {
          v[0] = 0;
          v[1] = 0<<24 | d[i+2]<<16 | d[i+1]<<8 | d[i];
        }
        break;
      }
      case 2: {
        if (n==0) {
          v[0] = 0<<24 | 0<<16 | d[i+1]<<8 | d[i];
          v[1] = 0;
        } else {
          v[0] = 0;
          v[1] = 0<<24 | 0<<16 | d[i+1]<<8 | d[i];
        }
        break;
      }
      case 3: {
        if (n==0) {
          v[0] = 0<<24 | 0<<16 | 0<<8 | d[i];
          v[1] = 0;
        } else {
          v[0] = 0;
          v[1] = 0<<24 | 0<<16 | 0<<8 | d[i];
        }
        break;
      }          
      default:
        v[0] = 0;
        v[1] = 0;
        break;
      }
      if(isEncrypt) {
        encipher(32, v, k);
      } else {
        decipher(32, v, k);
      }
      writeBuffer(v);
    }

  }

  printf("encrypted/decrepted string is:\n");
  printf("HEX:\n");
  for(i=0;i<32;i++) {
    printf("%0x ", buffer[i]);
  }
  printf("\n");
  printf("Chars:\n");
  for(i=0;i<32;i++) {
    printf("%c", buffer[i]);
  }
  printf("\n");
}


void encrypt(uint8_t *d, uint8_t *key) {
  doBlock(d, key, 1);
}

void decrypt(uint8_t *d, uint8_t *key) {
  doBlock(d, key, 0);
}
int main() {

  uint8_t *d = "This is a sample encryption TEXT";
  //  
  /* uint8_t d[] = {af1b916ca51b3c46b7bc5d397c71d7317656933577a222e49e5e4f28637a67239252df062b4a43a7}; */
  /* uint8_t d[] = {0xaf, 0x1b, 0x91, 0x6c, 0xa5, 0x1b, 0x3c, 0x46, 0xb7, 0xbc, 0x5d, 0x39, 0x7c, 0x71, 0xd7, 0x31, 0x76, 0x56, 0x93, 0x35, 0x77, 0xa2, 0x22, 0xe4, 0x9e, 0x5e, 0x4f, 0x28, 0x63, 0x7a, 0x67, 0x23, 0x92, 0x52, 0xdf, 0x06, 0x2b, 0x4a, 0x43, 0xa7,}; */
  
  /* uint8_t *key = "mmmmmmmmmmmmmmmm"; */
  // ed 10 b7 40 1c d3 4f c1 b2 26 97 d7 f6 16 47 a2
  // 54 49 31 38 32 34 33 35 36 37 33 34 39 31 53 5f
  uint8_t key[] = {0x54, 0x49, 0x31, 0x38, 0x32, 0x34, 0x33, 0x35, 0x36, 0x37, 0x33, 0x34, 0x39, 0x31, 0x53, 0x5f,};
  p=0;
  encrypt(d, key);
  uint8_t e_data[100];
  int i=0;
  /* int len = strlen(d); */
  for (i=0;i<32;i++) {
    e_data[i] = buffer[i];
  }
  p=0;
  decrypt(e_data, key);

  printf("ThankYou!");
  return 0;
}
```
## xxtea
```c
// #include"pch.h"
#include<stdio.h>
#include<stdint.h>
#define DELTA 0x9E3779B9
#define MX (((z>>5^y<<2)+(y>>3^z<<4))^((sum^y)+(k[(p&3)^e]^z)))
void btea(uint32_t *v, int n, uint32_t const k[4])
{
	uint32_t y, z, sum;
	unsigned p, rounds, e;
	if (n > 1)
	{
		rounds = 6 + 52 / n;	//这里可以说是预定义值，n=2是rounds=32
		sum = 0;
		z = v[n - 1];
		do
		{
			sum += DELTA;
			e = (sum >> 2) & 3;
			for (p = 0; p < n - 1; p++)        //注意这里的p是从0~n-1
			{
				y = v[p + 1];
				z = v[p] += MX;
			}
			y = v[0];
			z = v[n - 1] += MX;        //这里的MX中传入的p=n-1
		} while (--rounds);
	}
	else if (n < -1)
	{
		n = -n;
		rounds = 6 + 52 / n;
		sum = rounds * DELTA;
		y = v[0];
		do
		{
			e = (sum >> 2) & 3;
			for (p = n - 1; p > 0; p--)    //注意这里的p是从n-1~0,和上面是反过来的
			{
				z = v[p - 1];
				y = v[p] -= MX;
			}
			z = v[n - 1];
			y = v[0] -= MX;    //这里的MX中传入的 p=0
			sum -= DELTA;
		} while (--rounds);
	}
}
void xxteaencrypt(uint32_t*v, uint32_t len, uint32_t*k) {
	uint32_t n = len - 1;
	uint32_t z = v[n], y = v[0], p, q = 6 + 52 / (n + 1), sum = 0, e;
	if (n < 1) {
		return;
	}
	while (0 < q--) {
		sum += DELTA;
		e = sum >> 2 & 3;
		for (p = 0; p < n; p++) {
			y = v[p + 1];
			z = v[p] += MX;
		}
		y = v[0];
		z = v[n] += MX;
	}
}
 
void xxteadecrypt(uint32_t*v, uint32_t len, uint32_t*k) {
	if (len == 0)
		return;
	uint32_t n = len - 1;
	uint32_t z = v[n], y = v[0], p, q = 6 + 52 / (n + 1), sum = q * DELTA, e;
	if (n < 1) {
		return;
	}
	while (sum != 0) {
		e = sum >> 2 & 3;
		for (p = n; p > 0; p--) {
			z = v[p - 1];
			y = v[p] -= MX;
		}
		z = v[n];
		y = v[0] -= MX;
		sum -= DELTA;
	}
}
int main()
{
	unsigned char v[] = { 0x63,0x68,0x75,0x61,0x6E,0x67,0x71,0x69,0x61,0x6E,0x6D,0x69,0x6E,0x67,0x79,0x75,0x65,0x67,0x75,0x61,0x6E,0x67,0x31,0x31,0x31,0x31,0x31,0x68,0x61,0x68,0x61,0x61 };//需要加密或者解密的数据
	unsigned char k[] = { 0x98, 0xff, 0x34, 0x8c, 0x0c, 0x9d,0xac, 0x6e, 0xc9, 0x86, 0xd3, 0x90, 0xdc, 0x22,
	0xc4, 0xb3 };//秘钥
	int n = (sizeof(v) / sizeof(char)) / 4;
	xxteaencrypt((uint32_t*)v, n, (uint32_t*)k);//可以顺利加密
	xxteadecrypt((uint32_t*)v, n, (uint32_t*)k);//可以顺利解密
    for(int i = 0; i < 4*n; i++)
    {
        printf("%c", ((unsigned char *)&v)[i]);
    }
	printf("测试第二种\n");
	btea((uint32_t*)v, n, (uint32_t*)k);//可以顺利加密，n为正，加密，n为负，解密
	btea((uint32_t*)v, -n, (uint32_t*)k);//可以顺利解密
    for(int i = 0; i < 4*n; i++)
    {
        printf("%c", ((unsigned char *)&v)[i]);
    }
	return 0;
}
```
## xxtea1

```c

#include <stdio.h>
#include <stdint.h>
#define DELTA 0x67616C66            //固定的一个常量
#define MX (((z>>5^y<<2) + (y>>3^z<<4)) ^ ((sum^y) + (key[(p&3)^e] ^ z)))   //固定的运算

unsigned int get_sum(int n, unsigned int delat)
{
  unsigned int sum = 0;

  for(int i = 0; i < 52/n+6; i++)
    sum += delat;

  return sum;
}


void btea(uint32_t *v, int n, uint32_t const key[4])   //v是要加密的两个元素的数组
{                                                      //n为数组的长度
    uint32_t y, z, sum;                                //无符号整型     
    unsigned p, rounds, e;                            
    if (n > 1)            /* Coding Part */   
    {
        rounds = 6 + 52/n;               //固定的得出轮数
        sum = 0;                        
        z = v[n-1];                     
        do
        {
            sum += DELTA;                //每次进行叠加
            e = (sum >> 2) & 3;          //固定运算
            for (p=0; p<n-1; p++)       
            {
                y = v[p+1];
                v[p] += MX;
                      z = v[p];     
                        }
            y = v[0];
            z = v[n-1] += MX;
        }
        while (--rounds);
    }
    else if (n < -1)      /* Decoding Part */
    {
        n = -n;
        rounds = 6 + 52/n;
        sum = get_sum(n, DELTA); 
        //sum = rounds*DELTA;
        y = v[0];
        do
        {
            e = (sum >> 2) & 3;
            for (p=n-1; p>0; p--)
            {
                z = v[p-1];
                y = v[p] -= MX;
            }
            z = v[n-1];
            y = v[0] -= MX;
            sum -= DELTA;
        }
        while (--rounds);
    }
}

int main()
{
    uint32_t v[]= {0xC883B3AA, 0x7FB3950, 0x75BC5959, 0x7AB57E27, 0xC0249800, 0xADA35753, 0xBF1D493F, 0x6E14AF04, 0x468312C4};
    uint32_t const k[4]= {0x000004DB, 0xE, 0x00000017, 0x2A6};
    int n = 9; 

    btea(v, -n, k);
    printf("解密后的数据：\n");

    for(int i = 0; i < 4*n; i++)
    {
        printf("%c", ((unsigned char *)&v)[i]);
    }
    return 0;
}
```
## xxtea2
```c
#include <stdio.h>
#include <stdint.h>
#include <string.h>

#define DELTA 0x67616C66            // 固定的一个常量
#define MX (((z>>5^y<<2) + (y>>3^z<<4)) ^ ((sum^y) + (key[(p&3)^e] ^ z)))   // 固定的运算

unsigned int get_sum(int n, unsigned int delat)
{
    unsigned int sum = 0;
    for (int i = 0; i < 52 / n + 6; i++)
        sum += delat;

    return sum;
}

void btea(uint32_t *v, int n, uint32_t const key[4])   // v是要加密的两个元素的数组
{                                                      // n为数组的长度
    uint32_t y, z, sum;                                // 无符号整型     
    unsigned p, rounds, e;                            

    if (n > 1)            /* Coding Part */   
    {
        rounds = 6 + 52 / n;               // 固定的得出轮数
        sum = 0;                        
        z = v[n - 1];                     

        do
        {
            sum += DELTA;                // 每次进行叠加
            e = (sum >> 2) & 3;          // 固定运算
            for (p = 0; p < n - 1; p++)       
            {
                y = v[p + 1];
                v[p] += MX;
                z = v[p];     
            }
            y = v[0];
            z = v[n - 1] += MX;
        } while (--rounds);
    }
    else if (n < -1)      /* Decoding Part */
    {
        n = -n;
        rounds = 6 + 52 / n;
        sum = get_sum(n, DELTA); 

        y = v[0];
        do
        {
            e = (sum >> 2) & 3;
            for (p = n - 1; p > 0; p--)
            {
                z = v[p - 1];
                y = v[p] -= MX;
            }
            z = v[n - 1];
            y = v[0] -= MX;
            sum -= DELTA;
        } while (--rounds);
    }
}

int main()
{
    // 输入数据定义为 unsigned char 数组
    unsigned char v_char[] = {
        0xAA, 0xB3, 0x83, 0xC8,
        0x50, 0x39, 0xFB, 0x07,
        0x59, 0x59, 0xBC, 0x75,
        0x27, 0x7E, 0xB5, 0x7A,
        0x00, 0x98, 0x24, 0xC0,
        0x53, 0x57, 0xA3, 0xAD,
        0x3F, 0x49, 0x1D, 0xBF,
        0x04, 0xAF, 0x14, 0x6E,
        0xC4, 0x12, 0x83, 0x46
    };

    unsigned char k_char[] = {
        // 变换后的 k_char 数组:
        0xDB, 0x04, 0x00, 0x00,
        0x0E, 0x00, 0x00, 0x00,
        0x17, 0x00, 0x00, 0x00,
        0xA6, 0x02, 0x00, 0x00
    };

    int n = 9;  // v 数组中 32 位元素的个数

    // 将 unsigned char 数组转换为 uint32_t 数组
    uint32_t v[9];  // 9 个 32 位元素
    uint32_t key[4]; // 4 个 32 位元素

    memcpy(v, v_char, sizeof(v));
    memcpy(key, k_char, sizeof(key));

    // 调用解密函数
    btea(v, -n, key);
    printf("解密后的数据：\n");

    // 打印解密后的数据，转换为 unsigned char
    unsigned char *v_result = (unsigned char *)v;
    for (int i = 0; i < 4 * n; i++)
    {
        printf("%c", v_result[i]);
    }
    printf("\n");

    return 0;
}

```
## speck

```c
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <x86intrin.h>

#define ROR _lrotr /* in x86intrin.h */
#define ROL _lrotl /* in x86intrin.h */
#define R(x, y, k) (x = ROR(x, 8), x += y, x ^= k, y = ROL(y, 3), y ^= x) /* encryption round */
#define D(x, y, k) (y ^= x, y = ROR(y, 3), x ^= k, x -= y, x = ROL(x, 8)) /* inverse round */
#define ROUNDS 32

/* ******************************************
 * given a 128-bit key, extend it for       *
 * 32 rounds and save in a buffer for later *
 * use   .                                  *
 ********************************************/
void key_extend(uint64_t kb[static 2*ROUNDS], 
                 uint64_t const K[static 2]) 
{
    uint64_t i, a, b;
    b = K[1], a = K[0];
    for (i = 0; i<ROUNDS; i++) {
        kb[i*2] = b;
        kb[i*2+1] = a;
        R(b, a, i); /* key expansion uses encryption round */
   }
} /* end of key extend */


/*******************************************
 * encrypt a block with an expanded key    *
 ******************************************/
void encrypt(uint64_t const pt[static 2],
             uint64_t ct[static 2],
             uint64_t K[static ROUNDS*2])
{
   uint64_t y = pt[0], x = pt[1], i;
   
   for (i = 0; i < ROUNDS; i++) {
      R(x, y, K[i*2+1]);
   }

   ct[0] = y;
   ct[1] = x;
} /* end encrypt */

/*******************************************
 * encrypt a block with a key and perform  *
 * the key expansion in place (slower).    *
 ******************************************/
void encrypt_ext(uint64_t const pt[static 2],
             uint64_t ct[static 2],
             uint64_t const K[static 2])
{
   uint64_t y = pt[0], x = pt[1], b = K[1], a = K[0], i=0;
   
   for (i = 0; i < ROUNDS; i++) {
	  R(x, y, a);
      R(b, a, i);
   }

   ct[0] = y;
   ct[1] = x;
} /* end encrypt_ext */

/*******************************************
 * decrypt a block with a key and perform  *
 * the key expansion in place (slower).    *
 ******************************************/
void decrypt_ext(uint64_t const ct[static 2],
             uint64_t pt[static 2],
             uint64_t const K[static 2])
{
   uint64_t y = ct[0], x = ct[1], b = K[1], a = K[0];
   uint64_t Kext[ROUNDS*2];
   int i;

   for (i = 0; i<ROUNDS; i++) {
     Kext[i*2] = b;
     Kext[i*2+1] = a;
     R(b, a, i);

   }
   
   for (i = ROUNDS - 1; i >= 0; i--) {
	  D(x, y, Kext[i*2+1]);
   }

   pt[0] = y;
   pt[1] = x;
} /* end decrypt_ext */

/*******************************************
 * decrypt a block with an expanded key    *
 ******************************************/
void decrypt(uint64_t const ct[static 2],
             uint64_t pt[static 2],
             uint64_t K[static ROUNDS*2])
{
   uint64_t y = ct[0], x = ct[1];
   int i;
   
   for (i = ROUNDS - 1; i >= 0; i--) {
      D(x, y, K[i*2+1]);
   }

   pt[0] = y;
   pt[1] = x;
} /* end decrypt */

int main(int argc, char **argv) 
{
    uint64_t fileKey[2]; /* hold key from input file */
    uint64_t ct[2]; /* will always be results buffer */
    uint64_t Kext[ROUNDS*2]; /* holds extended key */

    /* Below this line - Test vectors from the NSA paper */
    /* and early testing code */
    uint64_t const K[2]  = {0x0706050403020101, 0x0f0e0d0c0b0a0908};/* 128-bit key */
    uint64_t const pt[2] = {0x7469206564616d20, 0x6c61766975716520};/* plaintext vector */
    uint64_t const rt[2] = { 0x6b9829732f670d6e,0x17f3af667525a950};/* enciphered text vector */    

    key_extend(&Kext[0], &K[0]);
   
    encrypt(&pt[0], &ct[0], &Kext[0]);
	printf("enc ext: ");
    printf("0x%0lx ", ct[0]);
    printf("0x%0lx\n ", ct[1]);
   
    decrypt(&rt[0], &ct[0], &Kext[0]);
	printf("dec: ");
    printf("0x%0lx ", ct[0]);
    printf("0x%0lx\n", ct[1]);

    return 0;
} /* end of main */

```

# RC4

```c
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
 
void swap(unsigned char *a, unsigned char *b) {
    unsigned char t = *a;
    *a = *b;
    *b = t;
}
 
void key_schedule(unsigned char s[256], unsigned char key[], int key_length) {
    int i, j, t;
    unsigned char tmp[256];
 
    memset(tmp, 0, 256);
    for (i = 0; i < 256; i++) {
        s[i] = i;
        tmp[i] = key[i % key_length];
    }
 
    j = t = 0;
    for (i = 0; i < 256; i++) {
        t = (t + s[i] + tmp[i]) % 256;
        swap(&s[i], &s[t]);
    }
}
 
void rc4(unsigned char s[256], unsigned char *data, int data_length, int num_rounds) {
    int i, j, t, k;
    unsigned char tmp;
 
    i = j = 0;
    for (k = 0; k < data_length; k++) {
        i = (i + 1) % 256;
        j = (j + s[i]) % 256;
        swap(&s[i], &s[j]);
        t = (s[i] + s[j]) % 256;
        tmp = s[t];
        data[k] ^= tmp;
    }
}
 
void rc4_encrypt(unsigned char *data, int data_length, unsigned char key[], int key_length) {
    unsigned char s[256];
    key_schedule(s, key, key_length);
    rc4(s, data, data_length, 16); // RC4 has no real "rounds" parameter, 16 is a common value
}
 
void rc4_decrypt(unsigned char *data, int data_length, unsigned char key[], int key_length) {
    unsigned char s[256];
    key_schedule(s, key, key_length);
    rc4(s, data, data_length, 16); // RC4 has no real "rounds" parameter, 16 is a common value
}
 
int main() {
    unsigned char key[] = "secret_key";
    unsigned char data[] = "Hello, World!";
    unsigned char encrypted[50];
    unsigned char decrypted[50];
    int data_length = strlen((const char *)data);
    int key_length = strlen((const char *)key);
 
    // Encrypt
    rc4_encrypt(data, data_length, key, key_length);
    memcpy(encrypted, data, data_length);
    printf("Encrypted: %s\n", encrypted);
    for (int i = 0; i < data_length; i++) {
        printf("%02x ", encrypted[i]);
    }
    printf("\n");
 
    // Decrypt
    rc4_decrypt(encrypted, data_length, key, key_length);
    memcpy(decrypted, encrypted, data_length);
    printf("Decrypted: %s\n", decrypted);
 
    return 0;
}
```