---
title: Nexus 5X刷android8.1、Root
id: 113
date: 2024-01-09 20:09:11
auther: yrl
cover: 
excerpt: 前言android6好多应用安装不了，索性安装一个nexus5x能支持的最高到Android8.1，记录一下，踩了点坑。下载刷机工具adb、fastbootapt install adb即可。fastboot此工具在android SDK的platform-tools中，若果没有，请提前下载plat
permalink: /archives/nexus5x%E5%88%B7android81root
categories:
 - android
 - 刷机
tags: 
 - 刷机
---

# 前言

android6好多应用安装不了，索性安装一个nexus5x能支持的最高到Android8.1，记录一下，踩了点坑。

# 下载刷机工具adb、fastboot

`apt install adb`即可。
fastboot此工具在android SDK的platform-tools中，若果没有，请提前下载platform-tools

注意坑点：
platform-tools版本要适配android版本，不能太高，否则在刷入系统时会出现`unknown command`等错误。如果需要暂时调整platform-tools版本，[官网下载](https://developer.android.com/studio/releases/platform-tools)好platform-tools后，将原有的platform-tools改个名字，用旧的platform-tools替换掉原有的platform-tools即可。刷入系统的时候使用platform-tools中的fastboot。


# 下载官方刷机包

[刷机包](https://dl.google.com/dl/android/aosp/bullhead-opm7.181205.001-factory-5f189d84.zip)
目前基于nexus5X能支持的最新的刷机包了。

查看sha256，验证完整性：
```
$ openssl dgst -sha256 bullhead-opm7.181205.001-factory-5f189d84.zip
SHA256(bullhead-opm7.181205.001-factory-5f189d84.zip)= 5f189d84781a26b49aca0de84a941a32ae0150da0aab89f1d7709d56c31b3c0a
```
随后，首先将手机进入fastboot状态，操作流程如下：
1. 将USB线断开，并确保手机有80%左右的电量；
1. 将手机完全关机；
1. 同时按住音量向下键和开机键；
1. 手机将进入fastboot状态；

注：手机如果未unlock，需提前unlock，方法如下：
```bash
adb reboot bootloader
fastboot devices
fastboot oem unlock
```
开始刷机：

```bash
unzip bullhead-opm7.181205.001-factory-5f189d84.zip
cd bullhead-opm7.181205.001
./flash-all.sh
```
刷机完成后，手机会自动重启，重启完成后即可自动进入系统。进入系统后，打开关于手机，三击版本号即可进入开发者模式，打开USB调试选项。

# 刷入Twrp
**注：** 如果Magisk使用安装apk，patch boot.img的方式，刷入Twrp可省略。

下载对应手机型号的[Trwp](https://dl.twrp.me/bullhead/),然后将手机设置到fastboot模式，使用fastboot命令将镜像刷进去。
```bash
$ fastboot flash recovery twrp-3.7.0_9-0-bullhead.img
target reported max download size of 536870912 bytes
sending 'recovery' (16289 KB)...
OKAY [  0.499s]
writing 'recovery'...
OKAY [  0.275s]
finished. total time: 0.774s
```
刷完之后，在手机上按两次音量向下键，选择Recovery mode，按电源键进入。稍等片刻之后，就会进入twrp 3.2.3-0系统。直接滑开即可，意味着允许修改系统。此时就刷入成功。

# 刷入Magisk

目前Magisk推荐安装apk，patch image来获取root权限，相对于Twrp，卡刷zip包方便，去Magisk官网下载[Magisk apk](https://github.com/topjohnwu/Magisk/releases/tag/v25.2)

## 准备刷入文件

下载安装Magisk，运行，在主界面你会看到`ramdisk ： yes`,说明设备有启动 ramdisk，请在下载的刷机包里获取一份boot.img，如果设备不支持ramdisk，获取一份recovery.img

接下来，判断设备是否有单独的vbmeta分区，

- 如果你的官方固件包包含vbmeta.img，那么你的设备有一个单独的vbmeta分区
- 您还可以通过将设备连接到 PC 并运行命令来进行检查：`adb shell ls -l /dev/block/by-name`
如果您发现vbmeta、vbmeta_a或vbmeta_b，那么您的设备有一个单独的vbmeta分区;否则，您的设备没有单独的vbmeta分区。

到此，你应该准备了：

1. 您的设备是否有启动 ramdisk
2. 您的设备是否有单独的vbmeta分区
3. 一个boot.img或recovery.img基于（1）

## 修补镜像

- 将`boot/recovery` image复制到您的设备目录：`adb push boot.img /sdcard/Download/`
- 按Magisk 界面的安装按钮
  - 如果您正在修补recovery映像，请选中“恢复模式”选项
  - 如果您的设备没有单独的vbmeta分区，请选中“Patch vbmeta in boot image”选项
- 方法中选择“Select and Patch a File”，选择boot/recovery image
- 开始安装，并使用 ADB 将修补后的映像复制到您的 PC：
- `adb pull /sdcard/Download/magisk_patched_[random_strings].img .`
- 将修补后的boot/recovery image 刷到您的设备。
- 对于大多数设备，重启进入快速启动模式并使用命令刷入：
- `fastboot flash boot /path/to/magisk_patched.img`或
- `fastboot flash recovery /path/to/magisk_patched.img`
- （可选）如果您的设备有单独的分区，您可以使用命令vbmeta修补分区：
- `fastboot flash vbmeta --disable-verity --disable-verification vbmeta.img`
- 重新启动手机即可。

## 卸载magisk

卸载 Magisk 的最简单方法是直接通过 Magisk 应用程序。如果您坚持使用custom recoveries，请将 Magisk APK 重命名为uninstall.zip，并像任何其他普通的可flash的 zip 一样flash它。

详情查阅：[install magisk](https://topjohnwu.github.io/Magisk/install.html)

# 获取Root权限

获取root权限，相对于刷机简单很多：
```bash
adb shell
su

或

adb root
adb shell

```
此时Magisk会弹出申请权限窗口，点击确定即可。

# 参考

[nexus5X刷android8.1](https://github.com/r0ysue/AndroidSecurityStudy/blob/master/FRIDA/A01/README.md)