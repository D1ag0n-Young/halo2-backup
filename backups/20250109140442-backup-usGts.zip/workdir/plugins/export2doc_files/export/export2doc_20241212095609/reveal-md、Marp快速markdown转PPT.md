---
title: reveal-md、Marp快速markdown转PPT
id: 128
date: 2024-01-09 20:09:12
auther: yrl
cover: 
excerpt: 前言对于程序员来说，写文档必备的就是markdown了，有时需要将自己的markdown转换成PPT，需要复制粘贴到Power Point，这里尝试了两种工具，各有优点，总体实现都是js+css渲染的html，最后导出成pdf。总观体验了两种工具Marp、reveal-md，总体感受（仅个人感受）如
permalink: /archives/reveal-mdmarp%E5%BF%AB%E9%80%9Fmarkdown%E8%BD%ACppt
categories:
 - 工具使用
 - markdown转ppt
tags: 
 - reveal-md
---

# 前言

对于程序员来说，写文档必备的就是markdown了，有时需要将自己的markdown转换成PPT，需要复制粘贴到Power Point，这里尝试了两种工具，各有优点，总体实现都是js+css渲染的html，最后导出成pdf。

# 总观

体验了两种工具Marp、reveal-md，总体感受（仅个人感受）如下：

Marp: 
优点：是有命令行工具marp-cli，有vscode插件，支持vscode预览同步修改md和PPT效果，可以根据自己已有的PPT模板，自定义编写css来生成特定格式的PPT，支持演讲者试图
缺点：只能生成pdf，没有切换特效，自定义的css在导出pdf后代码显示不出来，可能和css编写有关系

Reveal-md：
优点：基于revealjs开发的便捷工具，没有revealjs繁琐的操作，在原有reveal基础上，支持多种安装使用方式、自定义PPT分隔符、导出pdf等，相对于marp最主要优点就是内置主题多、有ppt切换特效、对代码支持好，css写的好的话会有非常不错的PPT动画体验；
缺点：但是如果你想自定义css样式的话，你得先看懂revealjs中css定义的格式，大项目css是可配置的，对刚接触的人可能不太友好，需要先build下再查看css。

# Marp for Vscode 


## 安装及使用
1. 下载地址：https://marp.app/#get-started
2. 下载marp-cli，放到path中，确保你可以在命令行中访问到它
3. 安装vscode 插件:https://marketplace.visualstudio.com/items?itemName=marp-team.marp-vscode
4. **设置vscode中使用对应的主题css文件**

命令行运行 `marp slide.md --theme theme/theme.css -p`,即可播放ppt，更多参数`-h`发现：

```bash
Usage:
marp [options] <files...>
marp [options] -I <dir>

Basic Options:
  -v, --version                      Show versions                     [boolean]
  -h, --help                         Show help                         [boolean]
  -o, --output                       Output file path (or directory when
                                     input-dir is passed)               [string]
  -I, --input-dir                    The base directory to find markdown and
                                     theme CSS                          [string]
  -c, --config-file, --config        Specify path to a configuration file
                                                                        [string]
      --no-config-file, --no-config  Prevent looking up for a configuration file
                                                                       [boolean]
  -w, --watch                        Watch input markdowns for changes [boolean]
  -s, --server                       Enable server mode                [boolean]
  -p, --preview                      Open preview window               [boolean]

Converter Options:
      --pdf                Convert slide deck into PDF                 [boolean]
      --pptx               Convert slide deck into PowerPoint document [boolean]
      --notes              Convert slide deck notes into a text file   [boolean]
      --image              Convert the first slide page into an image file
                                               [string] [choices: "png", "jpeg"]
      --images             Convert slide deck into multiple image files
                                               [string] [choices: "png", "jpeg"]
      --image-scale        The scale factor for rendered images
                                [number] [default: 1 (or 2 for PPTX conversion)]
      --jpeg-quality       Set JPEG image quality         [number] [default: 85]
      --allow-local-files  Allow to access local files from Markdown while
                           converting PDF, PPTX, or image (NOT SECURE) [boolean]

Template Options:
      --template            Choose template
                        [string] [choices: "bare", "bespoke"] [default: bespoke]
      --bespoke.osc         [Bespoke] Use on-screen controller
                                                       [boolean] [default: true]
                                                       [boolean] [default: true]
      --pdf-outlines.headings  Make outlines from Markdown headings
                                                       [boolean] [default: true]

Metadata Options:
      --title        Define title of the slide deck                     [string]
      --description  Define description of the slide deck               [string]
      --author       Define author of the slide deck                    [string]
      --keywords     Define comma-separated keywords for the slide deck [string]
      --url          Define canonical URL                               [string]
      --og-image     Define Open Graph image URL                        [string]

Marp / Marpit Options:
      --engine     Select Marpit based engine by module name or path    [string]
      --html       Enable or disable HTML tags                         [boolean]
      --theme      Override theme by name or CSS file                   [string]
      --theme-set  Path to additional theme CSS files                    [array]
```
## 使用
安装完成后，vscode在工作区的.vscode下的settings.json中添加
```json
{
    "markdown.marp.themes": [
      "./theme/league.css"
    ]
}
```
主题开头指定主题名称：
```css
/*! 
* @theme yourtheme
* @auto-scaling true 
* @size 16:9 1280px 720px
* @size 4:3 960px 720px
*/
```

在markdown开头指定主题：

```markdown
---
theme: default
paginate: true
footer: 你的页脚
---

```
### PPT分割符

默认以 `\n---\n`分割，可自定义。Vscode自带预览`CTRL+SHIFT+V`（如果安装了markdown preview，请先卸载），详见官方文档。

```markdown
# Title

- Point 1
- Point 2

---

## Second slide

> Best quote ever.

Note: speaker notes FTW!
```

### 插入图片

`![option](imgpath)` 其中option指定图片位置、大小等。

```markdown
![](./img1.png) 默认
![w:300 h:300](./img1.png) 指定图片宽高
![bg right 50%](./img1.png) 背景图片，靠右，缩放50%
![bg auto](./img1.png) 图片自动
![bg fit](./img1.png) 图片适应
![bg cover](./img1.png) 图片填满

多图平铺：
![bg fit](./img1.png) 
![bg fit](./img2.png) 
![bg fit](./img3.png) 
```

### 更改全局主题
Marp 渲染得到的幻灯片默认为白底蓝/黑字，如果你不喜欢默认的样式，可以在 Markdown 文件的开头，更改 theme 字段的值，来更改幻灯片的全局主题。

theme 字段有 3 个值：

- default（默认值，可省略）
- uncover
- gaia

### 自定义主题

如果你觉得上面的内容并不能满足你的需求，那你可能需要自定义CSS文件来改变Slide样式。

#### CSS文件配置
如果想要使用自己的CSS主题文件，你首先需要在当前md文件夹下新建.vscode 文件夹，在该文件夹下新建settings.json文件，添加如下内容。
```json
{
    "markdown.marp.themes": [
      "https://example.com/foo/bar/custom-theme.css",
      "custom theme.css path",
    ]
  }
```
`custom theme.css path `要添加自定义主题文件的路径，例如 `./themes/UCASSimple.css`

#### CSS文件内容

除去上面的文件，在CSS 文件头部需要添加` /* @theme <custom theme name>*/ `来声明是这是一个Marp主题，这样在编写.md 文件时就可以借助 `theme: <custom theme name> `使用自定义的主题了。

随后CSS文件中需要利用@import 导入已有的主题文件，目前Marp官方有default gaia uncover 三款主题。

接着就可以编写CSS文件自定义主题了。

### CSS文件示例

```css
/* @theme Theme */

@charset "UTF-8";
@import 'uncover';

section {
   font-size: 25px;
   padding: 50px;
   text-align: left;
   font-family:Arial, Helvetica, sans-serif;
   background:whitesmoke;
  }
 
h1 {
   text-align:left;
   color: rgb(60, 112, 198);
   margin-top: 150px;
   margin-bottom: 0px;
   font-size:72px;
}

header {
    left: 50px;
    right: 50px;
    top: 10px;
    height: 50px;
    background-image: url("./images/logo.png"); 
    background-position: right top;
    background-repeat: no-repeat;
    background-size: 200px;
    text-align:left;
    color: rgb(60, 112, 198);
    font-weight: bold;
    font-size:36px;
}
```

### 更换单个幻灯片的背景和文字颜色

在想要更改幻灯片背景色的页面开头，加上 `<!-- _backgroundColor: 颜色-->` 字段，就可以更改页面的背景色。

更改文本内容的颜色，需要在下面多配置一个选项 `<!-- _color: 颜色-->`，就能自定义文本的颜色。

### 将幻灯片导出为PDF

如何把你做好的PPT分享给其他人？
方法如下：
点击 `Marp Markdown` 文件右上角的 Marp 图标（三角形图标），在弹出的面板，选择`「Export Slide Deck」`，就可以将 PPT 导出为 PDF 。

### Refer

[官方文档](https://marpit.marp.app/)
[神级插件Marp](https://zhuanlan.zhihu.com/p/582872955)

# Reveal-md

需要nodejs环境，确认有npm命令，自行百度安装。

## 安装及运行
### 本地安装

`npm install -g reveal-md` 全局安装
### docker
先`docker pull webpronl/reveal-md`将镜像下载到本地,运行以下命令即可：
```bash
docker run --rm -p 1948:1948 -v <path-to-your-slides>:/slides webpronl/reveal-md:latest
docker run --rm -p 1948:1948 -v <path-to-your-slides>:/slides webpronl/reveal-md:latest --help
```

使用
```bash
reveal-md .\pwnbase.md --theme ./theme/league.css -w  # 播放ppt实时刷新
```
更多参数：
```bash
Usage: cli <slides.md> [options]

See https://github.com/webpro/reveal-md for more details.

Options:
  -V, --version                               output the version number
      --title <title>                         Title of the presentation
  -s, --separator <separator>                 Slide separator [default: 3 dashes (---) surrounded by two blank lines]
  -S, --vertical-separator <separator>        Vertical slide separator [default: 4 dashes (----) surrounded by two blank lines]
  -t, --theme <theme>                         Theme [default: black]
      --highlight-theme <theme>               Highlight theme [default: zenburn]
      --css <files>                           CSS files to inject into the page
      --scripts <files>                       Scripts to inject into the page
      --assets-dir <dirname>                  Defines assets directory name [default: _assets]
      --preprocessor <script>                 Markdown preprocessor script
      --template <filename>                   Template file for reveal.js
      --listing-template <filename>           Template file for listing
      --glob <pattern>                        Glob pattern to select markdown files for listing and conversion [default: **/*.md]
      --print [filename]                      Print to PDF file
      --static [dir]                          Export static html to directory [_static]. Incompatible with --print.
      --static-dirs <dirs>                    Extra directories to copy into static directory. Only used in conjunction with --static.
  -w, --watch                                 Watch for changes in markdown file and livereload presentation
      --disable-auto-open                     Disable auto-opening your web browser
      --host <host>                           Host [default: localhost]
      --port <port>                           Port [default: 1948]
      --featured-slide <num>                  Capture snapshot from this slide (numbering starts from 1) and use it as og:image for static build. Defaults to first slide. Only used with --static.
      --absolute-url <url>                    Define url used for hosting static build. This is included in OpenGraph metadata. Only used with --static.
      --print-size                            Paper size to use in exported PDF files
      --puppeteer-launch-args <args>          Customize how Puppeteer launches Chromium. The arguments are specified as a space separated list (for example --puppeteer-launch-args="--no-sandbox --disable-dev-shm-usage"). Needed for some CI setups.
      --puppeteer-chromium-executable <path>  Customize which Chromium executable puppeteer will launch. Allows to use a globally installed version of Chromium.
  -h, --help                                  output usage information
```
## 使用

和Marp相同的就不说了，这里就说一点不一样的。
### 代码高亮

代码高亮就和md代码一样，指定语言即可，某行高亮可指定，您可以突出显示一行、多行或两者：
````markdown
```python [1|3-6]
n = 0
while n < 10:
  if n % 2 == 0:
    print(f"{n} is even")
  else:
    print(f"{n} is odd")
  n += 1
```
````
### 主题

和revealjs支持一样的主题，查看[支持主题](https://github.com/hakimel/reveal.js/tree/master/css/theme/source)
```bash
reveal-md slides.md --theme solarized
```
自带的主题字体较大，适用于代码展示等少量文字的展示。

效果[参考](https://revealjs.com/themes/)

### 自定义主题
使用本地主题：
```bash
reveal-md slides.md --theme theme/my-custom.css
```
用远程主题覆盖显示主题（使用 rawgit.com 因为 url 必须允许跨站点访问）：
```bash
reveal-md slides.md --theme https://rawgit.com/puzzle/pitc-revealjs-theme/master/theme/puzzle.css
```
注：
自定义主题可以在原有的css上修改，也可以自己重新写。原有的是scss的（高度模块化）需要编译成css

首先需要clone revealjs：

```bash
git clone https://github.com/hakimel/reveal.js.git
cd reveal.js
npm install
npm run build -- css-themes
```

编译好后会有dist文件夹，下面有编译好的css文件。将css文件和它以来的文件(font文件夹)拷贝到自己markdown所在目录即可，CSS可以自行进行调整。

```css
:root {
  --r-background-color: #2b2b2b;
  --r-main-font: Lato, sans-serif;
  --r-main-font-size: 25px;   <!-- 字体大小 -->
  --r-main-color: #eee;
  --r-block-margin: 10px;
  --r-heading-margin: 0 0 15px 0;
  --r-heading-font: League Gothic, Impact, sans-serif;
  --r-heading-color: #eee;
  --r-heading-line-height: 1.2;
  --r-heading-letter-spacing: normal;
  --r-heading-text-transform: uppercase;
  --r-heading-text-shadow: 0px 0px 6px rgba(0, 0, 0, 0.2);
  --r-heading-font-weight: normal;
  --r-heading1-text-shadow: 0 1px 0 #ccc, 0 2px 0 #c9c9c9, 0 3px 0 #bbb, 0 4px 0 #b9b9b9, 0 5px 0 #aaa, 0 6px 1px rgba(0, 0, 0, 0.1), 0 0 5px rgba(0, 0, 0, 0.1), 0 1px 3px rgba(0, 0, 0, 0.3), 0 3px 5px rgba(0, 0, 0, 0.2), 0 5px 10px rgba(0, 0, 0, 0.25), 0 20px 20px rgba(0, 0, 0, 0.15);
  --r-heading1-size: 3.17em;
  --r-heading2-size: 2.11em;
  --r-heading3-size: 1.55em;
  --r-heading4-size: 1em;
  --r-code-font: monospace;
  --r-link-color: #13DAEC;
  --r-link-color-dark: #0d99a5;
  --r-link-color-hover: #71e9f4;
  --r-selection-background-color: #5e9cff;
  --r-selection-color: #fff;
}
```
以上定义了css主题的大部分属性，可自行更改。

### 自定义slide分割符

覆盖幻灯片分隔符（默认值`\n---\n`，横向切屏
```
reveal-md slides.md --separator "^\n\n\n"
```
覆盖垂直/嵌套幻灯片分隔符（默认值`\n----\n`），纵向切屏
```
reveal-md slides.md --vertical-separator "^\n\n"
```

### 自定义slide属性

设置背景色或背景图
```css
<!-- .slide: data-background="#fff" -->
<!-- .slide: data-background="./bg.png" -->
<!-- .slide: data-background-image="https://xxx.jpg" data-background-opacity=.1 data-background-repeat="no-repeat" -->
```
示例：将第二张幻灯片设置为以 PNG 图像作为背景：
```markdown
# slide1

This slide has no background image.

---

<!-- .slide: data-background="./image1.png" -->

# slide2

This one does!

---

# slide3

This is a video demo

<!-- .slide: data-background-video="./all.mov" -->

```
以下css可实现图片居中,markdown中直接`<div id="imgcenter">context</div>`

```css
#imgcenter {
  width:90%;
  text-align:center;
  padding-top:5px;
}
```


### 演讲者备注

以`Note:`开头的行会显示为注释，在播放过程中按`s`即可打开演讲者视图。
按`f`全屏，`Esc`退出。
按`o`概览模式，`Esc`退出。

### slide前言、切换动画

```markdown
---
title: Foobar
separator: <!--s-->
verticalSeparator: <!--v-->
theme: solarized
revealOptions:
  transition: 'fade'
---

Foo

Note: test note

<!--s-->

# Bar

<!--v-->
```
transition为动画效果：
| 名称    | 效果                                         |
| ------- | -------------------------------------------- |
| none    | 瞬间切换背景                                 |
| fade    | 交叉淡入淡出 - 背景转换的默认值              |
| slide   | 在背景之间滑动 — 幻灯片过渡的默认设置        |
| convex  | 以凸角滑动                                   |
| concave | 以凹角滑动                                   |
| zoom    | 向上缩放传入的幻灯片，使其从屏幕中心向内扩展 |

### 双例模式

上面说的都是单例模式，有时候双例模式比较方便，诸如ppt有左右两页，在css中添加以下代码
```
/*********************************************
 * Biexample mode
 *********************************************/
#left {
  margin: 10px 0 15px 20px;
  text-align: left;
  float: left;
  z-index:-10;
  width:48%;
  font-size: 0.85em;
  line-height: 1.5; 
}
  
#right {
  margin: 10px 0 15px 0;
  float: right;
  text-align: left;
  z-index:-10;
  width:49%;
  font-size: 0.85em;
  line-height: 1.5; 
}
```
然后在markdown中使用div指定：
```markdown
<div id="left">
 
## Left column
- Bullet 1
- Bullet 2
- Bullet 3 
- Even [links](https://www.google.com)
 
</div>
 
<div id="right">
 
## Right colum
1. List
2. List
3. ![Icon](https://cdn3.iconfinder.com/data/icons/ballicons-free/128/graph.png)
 
</div>

```
### 导出为PDF

#### Puppeteer
这个导出功能不太好用，当时用自己的css时，只有导出A4的可以使用，其他都导出不全
```bash
reveal-md slides.md --print slides.pdf --print-size 1024x768   # in pixels when no unit is given
reveal-md slides.md --print slides.pdf --print-size 210x297mm  # valid units are: px, in, cm, mm
reveal-md slides.md --print slides.pdf --print-size A4         # valid formats are: A0-6, Letter, Legal, Tabloid, Ledger
```
推荐使用官方提供的方法，在url后面添加`?print-pdf`，使用chrome自带的打印导出pdf。选择横向，无边距打印保存。只是这这种方法无法改变每一页pdf的尺寸。

#### Docker & DeckTape

提供了docker去导出pdf，但是这个docker在最后导出的时候报错，直接没了，这里我们直接用DeckTape本地导出，不差这一个工具了。


```bash
npm install -g decktape #安装
decktape -h #查看参数
```
使用
```bash
decktape automatic --slides 1-45 -s '1280x720' http://192.168.2.131:1948/pwnbase.md slides.pdf --chrome-arg=--no-sandbox
```
这种方法，可能会有一些格式问题。

[decktape](https://github.com/astefanutti/decktape)

如果对slide尺寸没啥要求的话，建议chrome的方法导出。

### refer
[reveal.js](https://revealjs.com/installation/)
[reveal-md](https://github.com/webpro/reveal-md)
## Refer
附一个[CSS学习链接](https://www.runoob.com/cssref/pr-class-display.html)
[CSS渐变背景](https://blog.csdn.net/m0_64231944/article/details/127706916)
