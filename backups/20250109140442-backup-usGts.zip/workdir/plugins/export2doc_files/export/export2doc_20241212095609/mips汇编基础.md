---
title: mips汇编基础
id: 139
date: 2024-01-09 20:09:13
auther: yrl
cover: 
excerpt: mips汇编基础有 32 个通用寄存器，三个特殊寄存器。编号名称描述0zero0号寄存器，始终是0；（为0提供简洁的形式）1$at保留寄存器2~3v0 v0~v0 v1values，保存表达式或函数的返回结果4~7$a0~a3arguments，函数的前4个参数8~15$t0~t7temporari
permalink: /archives/mips-hui-bian-ji-chu
categories:
 - 汇编
 - mips
tags: 
 - 汇编
 - mips
---

# mips汇编基础
**有 32 个通用寄存器，三个特殊寄存器。**
|编号         |        名称          |            描述|
|  ----  | ----  |----|
|0              |    zero               |     0号寄存器，始终是0；（为0提供简洁的形式）|
|1              |     $at                |     保留寄存器|
|2~3           |        $v0 - $v1  |               values，保存表达式或函数的返回结果|
|4~7            |      $a0 - a3       |           arguments，函数的前4个参数|
|8~15           |    $t0 - t7            |      temporaries，汇编程序的临时寄存器|
|16~23         |       $s0 - s7         |         saved values，子函数使用时需要提前保存的值|
|24~25        |       $t8 - $t9          |       temporaries 临时，补充t0~t7|
|26~27       |         $k0 - $k7        |         保留，中断处理函数使用|
|28            |      $gp                 |    global pointer，全局指针|
|29            |      $sp                |     stack pointer，堆栈指针，指向栈顶|
|30          |          $fp             |        frame poniter，保存栈帧指针|
|31        |         $ra              |       return address，函数返回地址|
|pc      |               |                       程序计数器|
|HI    |                   |                     高位、余数|
|LO |                    |                       低位，商|
**字节序**
- 大端序、小端序；file 指令查看 (MSB 或者 LSB)

**寻址方式**

- 寄存器寻址   多用于 load/store 两种
- PC 寻址   多用于转移指令
- 立即数寻址   多用于寻找变量
## mips汇编特点
**mips指令**
- 固定 4 字节长度

- 内存中的数据访问必须严格对齐（4byte）

- 流水线效应
以下指令的，strchr 函数的参数来自 $s0 而不是 $s2
```asm
mov $a0, $s2
jalr strchr
move $a0, $s0
```
- 指令格式
```
R型指令    Opcode(6)   Rs(5)   Rt(5)   Rd(5)   Shamt(5)    Funct(6)
I型指令   Opcode(6)   Rs(5)   Rt(5)   Immediate(16)
J型指令  Opcode(6)   Address(26)
```
**mips常用指令**
`i`表示立即数相关，`u`表示无符号相关。
- load/store 指令
la指令：将地址或者标签存入一个寄存器   eg:`la $t0,val_1`复制val_l的地址到$t0中，val_1是一个Label
- li指令，将立即数存入通用寄存器   eg:`li $t1, 40`                    $t1 = 40
- lw指令，从指定的地址加载一个word类型的值到一个寄存器   eg:`lw $s0, 0($sp)         $s0=MEM[$sp+0]`
- sw指令，将寄存器的值，存于指定的地址word类型  eg:`sw $a0, 0($sp)         MEM[$sp+0] = $a0`
- move指令，寄存器传值   eg：`move $t5, $t2                $t5 = $t2`
**算数指令**
算术指控得所有操作都是寄存器，不能是 RAM 地址或间接寻址。且操作数大小都是 word（4byte）
```asm
add $t0, $t1, $t2         $t0=$t1+$t2；  带符号数相加
sub $t0, $t1, $t2          $t0=$t1-$t2；  带符号数相减
addi $t0, $t1, 5           $t0=$t1+5；        有立即数的加法
addu $t0, $t1, $t2          $t0=$t1+$t2     无符号数的加法
subu $t0, $t1, $t2          $t0=$t1-$t2；  带符号数相减
mult $t3, $t3              (HI, LO) = $t3 * $t4
div $t5, $t6             $Hi=$t5 mod $t6
mfhi $t0                  $t0 = $Hi
mflo $t1                    $t1 = $Lo
```
**SYSCALL**

- 产生一个软化中断，实现系统调用；系统调用号存放在 $v0 中，参数在 $a0 - $a3 中；

返回值在 $v0 中，如果出错，在 $a3 中返回错误号；在编写 shellcode 时，用到该指令机制

- Write(1, “ABCn”, 5) 实现如下

```asm
addiu $sp, $sp, -32
li $a0, 1
lui $t6, 0x4142
ori $t6, $t6, 0x430a
sw  $t6, $0($sp)
addiu $a1, $sp, 0
li $a2, 5
li $v0, 4004
syscall
```
**分支跳转指令**

- 分支跳转指令本身可以通过比较两个寄存器决定如何跳转；如果想要实现与立即数的比较跳转，需要结合类跳转指令实现

```asm
b target                  无条件跳转到target处
beq   $t0, $t1, target        如果"$t0 == $t1”，跳转到target
blt $t0, $t1, target       如果“$t0 < $t1”，跳转到target
ble $t0, $t1, target       如果“$t0 <= $t1” 跳转到target
bgt
blt
bne                         类比上
```
**跳转指令**

```asm
j target              无条件跳转target
jr $t3                  跳转到$t3指向的地址处(Jump Register)
jal target              跳转到target，并保存返回地址到$ra中
```
**子函数的调用**

```asm
jal   sub_routine_label
    复制当前PC的值到$ra中，（当前PC值就是返回地址）
  程序跳转到sub_routine_label
```
**子函数的返回**

```asm
jr    $ra
如果子函数重复嵌套，则将$ra的值保存在堆栈中，因为$ra总是保存当前执行的子函数的返回地址
```