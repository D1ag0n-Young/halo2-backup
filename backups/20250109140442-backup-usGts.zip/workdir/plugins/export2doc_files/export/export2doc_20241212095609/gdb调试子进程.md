---
title: gdb调试子进程
id: de99579b-1bc3-465b-942e-1991ce1e7bea
date: 2024-09-05 18:03:55
auther: yrl
cover: 
excerpt: gdb默认情况下，父进程fork一个子进程，gdb只会继续调试父进程而不会管子进程的运行。 在一部分系统中(基于2.6内核的CentOS，支持follow-fork和detach-on-fork模式)，比
permalink: /archives/1725530636951
categories:
 - gdb
tags: 
 - gdb调试
---

gdb默认情况下，父进程fork一个子进程，gdb只会继续调试父进程而不会管子进程的运行。

在一部分系统中(基于2.6内核的CentOS，支持follow-fork和detach-on-fork模式)，比如HP-UX11.x之后的版本，Linux2.5.60之后的版本，可以使用以下的方法来达到方便的进行多进程调试功能。

**1.** 跟踪子进程进行调试，可以使用set follow-fork-mode mode来设置fork跟随模式。

  
**1.1 show follow-fork-mode**  
进入gdb以后，我们可以使用show follow-fork-mode来查看目前的跟踪模式。

**1.2 set follow-fork-mode parent**  
gdb只跟踪父进程，不跟踪子进程，这是默认的模式。

**1.3 set follow-fork-mode child**  
gdb在子进程产生以后只跟踪子进程，放弃对父进程的跟踪。

**2.** 想同时调试父进程和子进程，以上的方法就不能满足了。Linux提供了set detach-on-fork mode命令来供我们使用  
**2.1 show detach-on-fork**  
show detach-on-fork显示了目前是的detach-on-fork模式  
  
**2.2 set detach-on-fork on**  
只调试父进程或子进程的其中一个(根据follow-fork-mode来决定)，这是默认的模式。

**2.3 set detach-on-fork off**  
父子进程都在gdb的控制之下，其中一个进程正常调试(根据follow-fork-mode来决定),另一个进程会被设置为暂停状态。

**3.具体示例**  
show follow-fork-mode  
**set follow-fork-mode child**  
show detach-on-fork  
**set detach-on-fork off**

**4.其他方式**

使用gdb调试多进程时，如果想要在进程间进行切换，那么就需要在fork调用前设置： set detach-on-fork off ，  
然后使用 info inferiors 来查看进程信息，得到的信息可以看到最前面有一个进程编号，使用 inferior num 来进行进程切换。  
那么为什么要使用 set detache-on-fork off 呢？它的意思是在调用fork后相关进程的运行行为是怎么样的，是detache on/off ?  
也就是说分离出去独立运行，不受gdb控制还是不分离，被阻塞住。这里还涉及到一个设置 set follow-fork-mode [parents/child] ,  
就是fork之后，gdb的控制落在谁身上，如果是父进程，那么分离的就是子进程，反之亦然。如果detache-on-fork被off了，  
那么未受控的那个进程就会被阻塞住，进程状态为T，即处于调试状态。