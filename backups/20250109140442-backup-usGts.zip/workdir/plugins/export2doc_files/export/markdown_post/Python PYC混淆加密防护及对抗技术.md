---
title: Python PYC混淆加密防护及对抗技术
id: 119
date: 2024-01-09 20:09:12
auther: yrl
cover: 
excerpt: 前言本篇文章主要记录下python代码的混淆、防护机制以及对抗技术。混淆加密防护pyc防护技术扰码算法真正的应用代码可以被加密存储在pyc文件的一个或者多个字符串常量中，程序执行时首先有一段解扰代码对加密存储的应用代码进行解扰，然后真正的应用代码被执行。下面给出一个简单的扰码算法例子：import 
permalink: /archives/pythonpyc-hun-xiao-jia-mi-fang-hu-ji-dui-kang-ji-shu
categories:
 - re知识点
 - python
tags: 
 - 混淆
 - pyinject
---

# 前言

本篇文章主要记录下python代码的混淆、防护机制以及对抗技术。

# python/pyc防护技术

## 打包成exe/elf

打包工具有[pyinstaller](https://github.com/pyinstaller/pyinstaller)、[Nuitka](https://github.com/Nuitka/Nuitka)

- pyinstaller是把python以来的所有库都打包到一起，所以程序会很大，也容易被反编译从而得到源码
- Nuitka是将Python代码编译成C代码，然后再编译成可执行文件。这个过程涉及到代码的优化和转换，使得原始的Python代码和生成的可执行文件之间没有直接的、可逆的对应关系，所以逆向困难，运行速度和体积较pyinstaller的小很多。

## 编译成库pyd/so

pythohn代码可以编译成python的拓展库，win上为pyd（dll）、linux上为so，其原理是将python代码转换成c代码然后将其编译成动态库，代码会变得异常巨大，逆向困难

编译方法：

1. 编辑.pyx即源码文件

```python
# test.py
def checkFlag(flag_t: str):
    print("nice")
```
2. 设置setup.py文件

```python
from setuptools import setup, Extension
from Cython.Build import cythonize

extensions = [
    Extension(
        "checkFlag",
        ["checkFlag.pyx"],
        extra_compile_args=["-O3"],
        extra_link_args=["-s"],
    ),
]

setup(
    ext_modules=cythonize(extensions),
)

```

3. 编译

命令：`python setup.py build_ext --inplace`
当前目录会生成pyd/so二进制文件，和对应的c代码

把拓展放到同级目录，一定要用同版本的python才能够进行导入，如下
```bash
>>> import test
>>> print(test.checkFlag("12345"))
nice
```

## 扰码算法

真正的应用代码可以被加密存储在pyc文件的一个或者多个字符串常量中，程序执行时首先有一段解扰代码对加密存储的应用代码进行解扰，然后真正的应用代码被执行。下面给出一个简单的扰码算法例子：

```python
import marshal  
fd = open('sample.pyc', 'rb')  # sample.pyc为要加密的pyc文件
fd.seek(0x10)  
co = marshal.load(fd)  
fd.close()  
code_string = marshal.dumps(co)  
scrambled_code = code_string.encode('zlib').encode('base64')  
print scrambled_code  
# eJxLZoACRiB2AOJifiBRyMaQ8v9/CgODu0cKI0OwBhNIghtIeKTm5OQrhOcX5aT4aYC0oRHFXCAi  
MbcgJ9VIr6CyhAPItcnNTynNSbUD2VACUgQAIHcTlg==  
```
运行下面代码实现执行pyc文件：
```python
scrambled_code_string='eJxLZoACRiB2AOJifiBRyMaQ8v9/CgODu0cKI0OwBhNIghtIeKTm5OQrhOcX5aT4aYC0oRHFXCAiMbcgJ9VIr6CyhAPItcnNTynNSbUD2VACUgQAIHcTlg=='  
exec __import__('marshal').loads(scrambled_code_string.decode('base64').decode('zlib'))  
```
```
$ python descramble.py  
Hello World  
```
其中扰码算法可以自定义难度。

## Pyarmor

PyArmor 是一个用于加密和保护 Python 脚本的工具。它能够在运行时刻保护 Python脚本的二进制代码不被泄露，设置加密后 Python 源代码的有效期限，绑 定加密后的Python源代码到硬盘、网卡等硬件设备。它的保障机制主要包括

- 加密编译后的代码块，保护模块中的字符串和常量
- 在脚本运行时候动态加密和解密每一个函数（代码块）的二进制代码
- 代码块执行完成之后清空堆栈局部变量
- 通过授权文件限制加密后脚本的有效期和设备环境

PyArmor 支持 Python 2.6, 2.7 和 Python 3,pyarmor功能很强大，这里只举一个简单的加密python脚本的例子，其他高级功能可以去github上探索。

### 安装及卸载
**安装**
一键 `pip install pyarmor` 即可。

使用 pip 安装之后，有两个可用的命令：
- pyarmor 这是主要的工具，参考 使用 PyArmor.
- pyarmor-webui 用来打开网页版的可视化界面

**卸载**

下列文件可能会在 pyarmor 运行时被创建:
```
~/.pyarmor/.pyarmor_capsule.zip         (从 v6.2.0 开始)
~/.pyarmor/license.lic                  (从 v5.8.0 开始)
~/.pyarmor/platforms/

{pyarmor-folder}/license.lic            (在 v5.8.0 之前)
~/.pyarmor_capsule.zip                  (在 v6.2.0 之前)

/path/to/project/.pyarmor_config        (如果使用了工程）
```
执行下面的命令进行完全卸载:
```
pip uninstall pyarmor
rm -rf ~/.pyarmor

rm -rf {pyarmor-folder}                 (在 v5.8.0 之前)
rm -rf ~/.pyarmor_capsule.zip           (在 v6.2.0 之前)

rm /path/to/project/.pyarmor_config
```
### 加密脚本

命令 obfuscate 用来加密脚本。最常用的一种情况是切换到脚本myscript.py所在的路径，然后执行:

```bash
pyarmor obfuscate myscript.py
```
PyArmor 会加密myscript.py和相同目录下面的所有 `*.py` 文件:

- 在用户根目录下面创建 .pyarmor_capsule.zip （仅当不存在的时候创建）
- 创建输出子目录 dist
- 生成加密的主脚本myscript.py保存在输出目录 dist
- 加密相同目录下其他所有 *.py 文件，保存到输出目录 dist
- 生成运行加密脚本所需要的全部辅助文件，保存到输出目录 dist

输出目录 dist 包含运行加密脚本所需要的全部文件:
```
dist/
    myscript.py
    pytransform
        __init__.py
        _pytransform.so or _pytransform.dll or _pytransform.dylib
```
除了加密脚本之外，额外的那个目录pytransform叫做运行辅助包 ，它是运行 加密脚本不可缺少的。

通常情况下第一个脚本叫做主脚本，它加密后的内容如下:

```python
from pytransform import pyarmor_runtime
pyarmor_runtime()
__pyarmor__(__name__, __file__, b'\x06\x0f...')
```
其中前两行是引导代码, 它们只在主脚本出现，并且只能被运行一次。对于其他所有加密脚本，只有这样一行:

```python
__pyarmor__(__name__, __file__, b'\x0a\x02...')
```
运行加密脚本:

```bash
cd dist
python myscript.py
```
默认情况下，只有和主脚本相同目录的其他 `*.py` 会被同时加密。如果想递归加密 子目录下的所有 `*.py `文件，使用下面的命令:

```bash
pyarmor obfuscate --recursive myscript.py
```
### 打包加密脚本

工具还可以打包成exe/elf文件，命令参数`pack`用来打包并加密脚本
首先需要安装 PyInstaller:
```bash
pip install pyinstaller
```
然后运行下面的命令:
```bash
pyarmor pack myscript.py
```
PyArmor 通过以下的步骤将所有需要的文件打包成为一个独立可运行的安装包:

- 执行 pyarmor obfuscate 加密脚本 myscript.py 和同目录下的所有其他脚本
- 执行 pyinstaller myscipt.py 创建 myscript.spec
- 修改 myscript.spec, 把原来的脚本替换成为加密后的脚本
- 再次执行 pyinstaller myscript.spec ，生成最终的安装包

输出的文件在目录 dist/myscript ，这里面包含了脱离 Python 环境可以运行的所有文件。

运行打包好的可执行文件:`dist/myscript/myscript`

详细参考[pyarmor文档](https://pyarmor.readthedocs.io/zh/latest/)


## python脚本混淆

python代码混淆工具：
1. [pyobfuscate](https://github.com/astrand/pyobfuscate) 较老派的混淆方案
2. [Oxyry](http://pyob.oxyry.com/) 混淆成都没有pyobfuscate大
3. [pyminifier](https://github.com/liftoff/pyminifier) 程序流混淆，增加程序分支
4. pyinstaller打包成exe混淆

对于python脚本源码级的混淆，只能尽量的根据程序逻辑还原语义含义。

# 对抗方式
## 对抗扰码算法

逆向扰码算法，还原python字节码，还原程序逻辑
理论可行：通过dll注入来dump内存中pyc文件，从而直接得到python字节码

## pyd/so对抗

通过导入python库，对相应函数主动调用，可以复用一部分函数，对于关键的函数，需要逆向其算法，总体思路有两种：
1. 观察输入输出关系，主动调用进行爆破
2. 对关键函数进行逆向，api[参考](https://docs.python.org/zh-cn/3.10/c-api/object.html?)

## 对抗pyarmor

越通用约好用的工具，就会有相应的对抗工具，随着pyarmor的应用，PyArmor-Unpacker应运而生，其实他只是另一个项目[PyInjector](https://github.com/call-042PE/PyInjector)的包装，只是自己实现了code.py的注入逻辑；主要原理还是通过注入python进程来拿到内存中的pyc文件。

pyarmor被用在CTF上，[详细查看](https://github.com/Svenskithesource/FLARE-ON9-Chal11_Unpacking-Pyarmor)

### method1
注入逻辑：循环所有在进程中运行的线程，找到主线程后，注意 None 之前的帧是经过混淆的帧，继续向后一帧，直到我们找到主帧
```python
import sys, marshal

for frame in sys._current_frames().values(): # Loop all the threads running in the process
    if "frozen" in frame.f_code.co_filename: # Find the correct thread (when injecting this code it also creates a new thread so we need to find the main one)
        while frame.f_back.f_back != None: # NOTE the frame before None is the obfuscated one
            frame = frame.f_back # Keep going one frame back until we find the main frame (see NOTE above on how we identify it)
        code = frame.f_code
        break

open("dumped.marshal", "wb").write(marshal.dumps(code))
```
1. 将method1下所有文件放到要解密的文件同目录下
2. 运行你想要解密的文件
3. 用注入器（推荐[Process Hacker2](https://processhacker.sourceforge.io/)）注入[PyInjector](https://github.com/call-042PE/PyInjector)
4. 运行method1.py，dump出pyc文件
5. 运行run.py执行pyc


### method2

1. 将method2目录中的所有文件复制到与要解压缩的文件相同的目录中。
1. 运行你要解压的文件
1. 用注入器（推荐[Process Hacker2](https://processhacker.sourceforge.io/)）注入[PyInjector](https://github.com/call-042PE/PyInjector)
1. 在dumps目录中，您可以找到完全解压的.pyc文件。
1. 可使用反编译器pycdc取回 Python 源代码，目前 3.9.7 以上需要使用[pycdc](https://github.com/zrax/pycdc)

### method3

**注意**：请勿对 3.9.7 版本以下的任何内容使用静态解包器，marshal.loads审核日志仅在 3.9.7 及之后添加。

1. 将method3 目录中的所有文件复制到与要解压缩的文件相同的目录中。
1. 在终端运行`python3 bypass.py filename.py`替换filename.py为实际的文件名
1. 在dumps目录中，您可以找到完全解压的.pyc文件。
1. 可使用反编译器pycdc取回 Python 源代码，目前 3.9.7 以上需要使用[pycdc](https://github.com/zrax/pycdc)

pyarmor-unpacker的开发者还有一个项目分析pyc文件的[pySpy](https://github.com/Svenskithesource/pySpy),图形化界面，功能只是显示字节码，后续可能会有更多功能。

以method2为例演示使用方法：

1. 首先将method2所有文件放到加密后的python文件同目录：
![image-1669914477277](/upload/2022/12/image-1669914477277.png)

运行加密脚本test.py，然后使用process hacker2注入pyinjector（提前将项目中的dll下载下来，分32/64版本），操作如下：

2. 打开process hacker，搜索python相关进程
![image-1669915013317](/upload/2022/12/image-1669915013317.png)
3. 点击进程右键Miscellaneous-> Inject DLL，选择x86/64版本的dll
4. 然后会test.py脚本在同目录生成dump文件夹
![image-1669915447034](/upload/2022/12/image-1669915447034.png)
5. 使用pycdc或者在线反编译工具查看
![image-1669915529954](/upload/2022/12/image-1669915529954.png)

成功还原代码。




